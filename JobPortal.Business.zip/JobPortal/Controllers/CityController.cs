﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICityService cityService;
        private readonly ILog logger;
        public CityController(ICityService _cityService, ILog _logger)
        {
            cityService = _cityService;
            logger = _logger;
        }

        /// <summary>
        /// To Save a City
        /// </summary>
        /// <param name="saveCity"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveCity")]
        public async Task<ActionResult> SaveCity(SaveCity saveCity)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveCity", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(saveCity) };
                logger.Info(log);
                City city = new City { CityId = saveCity.CityId, CityName = saveCity.CityName, StateId = saveCity.StateId, IsActive = saveCity.IsActive };
                CreateSuccessModel result = await cityService.SaveCity(city);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveCity", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message};
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a city by Id
        /// </summary>
        /// <param name="cityId"></param>
        /// <returns></returns>
        
        [HttpGet]
        [ProducesResponseType(typeof(CityList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetCityById")]
        public async Task<ActionResult> GetCityById(int cityId)
        {
            try
            {
                CityList cityList =await cityService.GetCityById(cityId);
                   return Ok(cityList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCityById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
