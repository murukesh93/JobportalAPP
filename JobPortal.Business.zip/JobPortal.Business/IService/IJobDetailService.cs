﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IJobDetailService
    {
        Task<CreateSuccessModel> UpsertJobDetail(JobDetail jobDetail,List<int> CityId,List<int> KeySkillId);
        Task<SuccessModel> DeleteJobDetails(int jobDetailId);
        Task<getJobDetailList> GetJobDetailList(int jobDetailId,int canditateId);
        Task<JobDetailList> GetJobDetails(int count, int offset, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId);
        Task<SearchJobsList> GetJobsBySearch(int count, int offset, string searchLocations, string searchSkills,int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId);
        Task<GetCandidateHistoryList> GetCandidateHistory(int userId);
        Task<GetCandidateInterviewHistoryList> GetCandidateRoundHistory(int candidateId, int jobDetailId);
        Task<SuccessModel> UpdateJobStatus(int JobDetailId, string JobStatus);
    }
}
 