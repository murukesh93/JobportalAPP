﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Business.Service
{
    public class ZoomService : IZoomService
    {
        private JobPortalContext dbContext;
        public ZoomService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        private string GenerateToken()
        {
            try
            {
                var tokenHandler = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler();
                var now = DateTime.UtcNow;
                var apiSecret = Common.Common.GetConnectionString("ZoomCredentials", "ApiSecretKey");
                byte[] symmetricKey = Encoding.ASCII.GetBytes(apiSecret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Issuer = Common.Common.GetConnectionString("ZoomCredentials", "ApiKey"),
                    Expires = now.AddHours(6),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(symmetricKey), SecurityAlgorithms.HmacSha256),
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);
                return tokenString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<ZoomApiList> GetUserHostingDetails()
        {
            try
            {
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/users/");
                client.Timeout = -1;
                var authorization = "Bearer " + GenerateToken();
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "_zm_csp_script_nonce=kwUaj-OJRZ2D4ccasVpilg; _zm_currency=INR; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_o2nd=0a1d30301a1ec4b0bf22e21dc88b9f3f; _zm_ssid=aw1_c_0HQvSmYASJW-lmGfKy-o9w; cred=E08624A446BB2293DBC9DA8E9AE60227");
                IRestResponse response =  client.Execute(request);
                if (response.IsSuccessful == true)
                {
                    var clintResult =  JsonConvert.DeserializeObject<ZoomApiList>(response.Content);
                    return clintResult;
                }
                else
                {
                    ZoomApiList zoomApiList = new ZoomApiList();
                    return zoomApiList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       public async Task<MeetingCreatedList> CreateNewMeeting(CreateMeetingList createMeeting)
        {
            try
            {
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/users/" + createMeeting.Schedule_for + "/meetings");
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Cookie", "_zm_currency=INR; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; cred=941B872565C33AB055784A429B569A96");
                var body = $@"{{
                          ""topic"":""{createMeeting.Topic}"",
                          ""type"":""{createMeeting.Type}"",
                          ""timezone"":""{createMeeting.Timezone}"",
                          ""agenda"":""{createMeeting.Agenda}"",
                          ""duration"":""{createMeeting.Duration}"",
                          ""start_time"":""{createMeeting.Agenda}"",
                          ""schedule_for"":""{createMeeting.Schedule_for}""
                        
                            }}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                if (response.IsSuccessful == true)
                {
                    var meetingCreated = JsonConvert.DeserializeObject<MeetingCreatedList>(response.Content);
                    return meetingCreated;
                }
                else
                {
                    MeetingCreatedList meetingCreated = new MeetingCreatedList();
                    return meetingCreated;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<ScheduledMeetingList> ListScheduledMeetings(string hostId)
        {
            try
            {
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/users/" + hostId + "/meetings");
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "_zm_csp_script_nonce=MRs5aB8rRNubhhR-mRwCqA; _zm_currency=INR; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_ssid=aw1_c_N7K2IO3mSb2nXbOwT3cf9A; cred=FC3AFF5D8F7BC4A3229875431AF122DD");
                IRestResponse response = client.Execute(request);
                if (response.IsSuccessful == true)
                {
                    var scheduledMeetings = JsonConvert.DeserializeObject<ScheduledMeetingList>(response.Content);
                    return scheduledMeetings;
                }
                else
                {
                    ScheduledMeetingList scheduledMeetings = new ScheduledMeetingList();
                    return scheduledMeetings;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<MeetingCreatedList> GetMeetingById(string meetingId)
        {
            try
            {
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/meetings/" + meetingId);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "_zm_csp_script_nonce=MRs5aB8rRNubhhR-mRwCqA; _zm_currency=INR; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_ssid=aw1_c_N7K2IO3mSb2nXbOwT3cf9A; cred=50BFEB0D6F023047EBDC1590E41F859B");
                IRestResponse response = client.Execute(request);
                if (response.IsSuccessful == true)
                {
                    var meeting = JsonConvert.DeserializeObject<MeetingCreatedList>(response.Content);
                    return meeting;
                }
                else
                {
                    MeetingCreatedList meeting = new MeetingCreatedList();
                    return meeting;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> AddNewParticipants(ZoomMeetingParticipant zoomMeeting)
        {
            try
            {
            SuccessModel result;
            var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/meetings/" +zoomMeeting.MeetingId+"/registrants");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            var authorization = "Bearer " + GenerateToken();
            request.AddHeader("Authorization",authorization);
            request.AddHeader("Content-Type", "application/json");
         
            request.AddHeader("Cookie", "_zm_csp_script_nonce=MRs5aB8rRNubhhR-mRwCqA; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_ssid=aw1_c_N7K2IO3mSb2nXbOwT3cf9A; cred=FFA40F6E57A08B71EB7FC07008BA5A1F");
            var body = $@"{{
                            ""email"":""{zoomMeeting.Email}"",
                            ""first_name"":""{zoomMeeting.Name}""
                             }}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            var meeting = JsonConvert.DeserializeObject<AddParticipantsStatus>(response.Content);
            if (response.IsSuccessful==true)
            {
              await  dbContext.ZoomMeetingParticipants.AddAsync(zoomMeeting);
              await dbContext.SaveChangesAsync();
                return result = new SuccessModel { status = "Success", message = meeting.Message };
            }
            else
            {
                return result = new SuccessModel { status = "Success", message = meeting.Message };
            }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> DeleteParticipant(DeleteRegirstrantsList regirstrantsList)
        {
            try
            {
                SuccessModel result;
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/meetings/" + regirstrantsList.MeetingId + "/registrants/" + regirstrantsList.RegistrantsId);
                client.Timeout = -1;
                var request = new RestRequest(Method.DELETE);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "_zm_chtaid=905; _zm_ctaid=W-R8DYpsTweXInB_kx416A.1632987387393.b32592c6362cb7140746002a01840dfe; _zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_page_auth=aw1_c_JSLOGE0CQJWOGc8Pepz_LQ; _zm_ssid=aw1_c_EX4MXEJmRYeqIBiblY5-XQ; cred=EF8F8F2FC4FA6C03BF66061957EE8255");
                IRestResponse response = client.Execute(request);
                var meeting = JsonConvert.DeserializeObject<AddParticipantsStatus>(response.Content);
                if (response.IsSuccessful == true)
                {
                    ZoomMeetingParticipant existingUser = await dbContext.ZoomMeetingParticipants.FirstOrDefaultAsync(z => z.MeetingId == regirstrantsList.MeetingId && z.Email == regirstrantsList.Email);
                    dbContext.ZoomMeetingParticipants.Remove(existingUser);
                    await dbContext.SaveChangesAsync();
                    return result = new SuccessModel { status = "Success", message = meeting.Message };
                }
                else
                {
                    return result = new SuccessModel { status = "Error", message = meeting.Message };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> UpdateMeeting(UpdateMeetingList updateMeeting)
        {
            try
            {
                SuccessModel result;
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL")+"/meetings/" + updateMeeting.MeetingId);
                client.Timeout = -1;
                var request = new RestRequest(Method.PATCH);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Cookie", "_zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_page_auth=aw1_c_JSLOGE0CQJWOGc8Pepz_LQ; _zm_ssid=aw1_c_EX4MXEJmRYeqIBiblY5-XQ; cred=BE78FEEA4C94EA107EFBA525A2C5C0CC");
                var body = $@"{{ 
                          ""topic"":""{updateMeeting.Topic}"",
                          ""start_time"":""{updateMeeting.Start_time}"",
                          ""type"":""{updateMeeting.Type}"",
                          ""agenda"":""{updateMeeting.Agenda}"",
                          ""timezone"":""{updateMeeting.Timezone}"",
                          ""duration"":""{updateMeeting.Duration}""
                            }}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var meeting = JsonConvert.DeserializeObject<AddParticipantsStatus>(response.Content);
                if (response.IsSuccessful == true)
                {
                    return result = new SuccessModel { status = "Success", message = "Meeting UPdated Succesfully" };
                }
                else
                {
                    return result = new SuccessModel { status = "Error", message = meeting.Message };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> DeleteMeeting(string meetingId)
        {
            try
            {
                SuccessModel result;
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/meetings/" + meetingId);
                client.Timeout = -1;
                var request = new RestRequest(Method.DELETE);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "_zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_page_auth=aw1_c_JSLOGE0CQJWOGc8Pepz_LQ; _zm_ssid=aw1_c_EX4MXEJmRYeqIBiblY5-XQ; cred=D88B3056D6B95CA0FAD415C18829DC1E");
                IRestResponse response = client.Execute(request);
                var meeting = JsonConvert.DeserializeObject<AddParticipantsStatus>(response.Content);
                if (response.IsSuccessful == true)
                {
                    return result = new SuccessModel { status = "Success", message = "Meeting Deleted Succesfully" };
                }
                else
                {
                    return result = new SuccessModel { status = "Error", message = meeting.Message };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> UpdateMeetingStatus(string meetingId, string action)
        {
            try
            {
                SuccessModel result;
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL")+"/meetings/" + meetingId + "/status");
                client.Timeout = -1;
                var request = new RestRequest(Method.PUT);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Cookie", "_zm_mtk_guid=f5db92cea146463dbaae35263c05c893; _zm_page_auth=aw1_c_JSLOGE0CQJWOGc8Pepz_LQ; _zm_ssid=aw1_c_EX4MXEJmRYeqIBiblY5-XQ; cred=CD254F82E9F695395C4DE692947F73BE");
                var body = $@"{{
                          ""action"":""{action}""
                            }}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var meeting = JsonConvert.DeserializeObject<AddParticipantsStatus>(response.Content);
                if (response.IsSuccessful == true)
                {
                    return result = new SuccessModel { status = "Success", message = "Meeting Status Updated Succesfully" };
                }
                else
                {
                    return result = new SuccessModel { status = "Error", message = meeting.Message };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetParticipantList> GetParticipant(long meetingId, string registrantId)
        {
            try
            {
                var client = new RestClient(Common.Common.GetConnectionString("ZoomCredentials", "ZoomBaseURL") + "/meetings/"+meetingId+"/registrants/"+ registrantId);
                var request = new RestRequest(Method.GET);
                var authorization = "Bearer " + GenerateToken();
                request.AddHeader("Authorization", authorization);
                request.AddHeader("Cookie", "cred=0D237EE0846640DBC669F6EBDE2EC9AF");
                IRestResponse response = client.Execute(request);
                if (response.IsSuccessful == true)
                {
                    var participantList = JsonConvert.DeserializeObject<GetParticipantList>(response.Content);
                    return participantList;
                }
                else
                {
                    var participantList = JsonConvert.DeserializeObject<GetParticipantList>(response.Content);
                    return participantList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetZoomTimeList> GetZoomList()
        {
            try
            {
                GetZoomTimeList getZoomTimeList = new GetZoomTimeList();
                getZoomTimeList.zoomTimeZones = await dbContext.ZoomTimeZones.Select(z => new ZoomTimeZones { zoomId = z.ZoomId, Name = z.Name }).ToListAsync();
                return getZoomTimeList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GetCalendorList> GetCalendorView(int count, int offset,int interviewerId, string email, string fromDate, string toDate, string meetingStatus, int userId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("count", count));
                parameters.Add(new SqlParameter("offset", offset));
                parameters.Add(new SqlParameter("email", email));
                parameters.Add(new SqlParameter("fromDate", fromDate));
                parameters.Add(new SqlParameter("toDate", toDate));
                parameters.Add(new SqlParameter("meetingStatus", meetingStatus));
                parameters.Add(new SqlParameter("userId", userId));
                parameters.Add(new SqlParameter("interviewerId", interviewerId));
                DataSet ds = Common.Common.GetResultSet("getCalendorView", parameters);
                List<VwGetCalendorView> output = Common.Common.ToListof<VwGetCalendorView>(ds.Tables[1]);
                GetCalendorList getCalendorList = new GetCalendorList { Count = (int)ds.Tables[0].Rows[0][0], Data = output };
                return getCalendorList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
