﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class ZoomMeeting
    {
        public int ZoomMeetingId { get; set; }
        public string MeetingId { get; set; }
        public string Topic { get; set; }
        public string MeetingUrl { get; set; }
        public string MeetingStatus { get; set; }
    }
}
