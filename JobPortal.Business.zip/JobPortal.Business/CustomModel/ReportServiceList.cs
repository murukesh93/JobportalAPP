﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class ReportServiceList
    {
        public int Count { get; set; }
        public List<VWReportLIst> Data { get; set; }
    }
    public class RoundStatusReportList
    {
        public List<VwGetRoundStatus> Data { get; set; }
        public int Count { get; set; }
    }
    public class RecruitedDetailsList
    {
        public int Count { get; set; }
        public List<VWRecruitedDetails> Data { get; set; }
    }
}
