﻿using JobPortal.Business.CustomModel;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using static JobPortal.Business.Common.Common;


namespace JobPortal.Business.IService
{
    public interface IUploadService
    {
       Task<FileUploadModel> UploadFile(IFormFile formFile, FileAccess fileAccess);
        Task<FileUploadModel> GetUserDelegationSasBlob(string filePath);
    }
}
