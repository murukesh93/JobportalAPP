﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwGetRoundStatus
    {
        public int RoundDetailId { get; set; }
        public int? UserId { get; set; }
        public int? JobDetailId { get; set; }
        public DateTime? SubmitDate { get; set; }
        public string RoundStatus { get; set; }
        public int? ActionBy { get; set; }
        public string UserName { get; set; }
        public string Comments { get; set; }
        public string JobTitle { get; set; }
        public string JobStatus { get; set; }
        public int? CompanyId { get; set; }
        public string JobDescription { get; set; }
        public int? NumberOfresources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public int? DesignationId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
    }
}
