﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class JobPreliminaryController : ControllerBase
    {
        private readonly IJobPreliminaryService jobPreliminaryService;
        private readonly ILog logger;
        public JobPreliminaryController(IJobPreliminaryService _jobPreliminaryService, ILog _logger)
        {
            jobPreliminaryService = _jobPreliminaryService;
            logger = _logger;
        }


        /// <summary>
        /// To createt a Job Preliminary Questions
        /// </summary>
        /// <param name="jobPreliminaryLists"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveQuestions")]
        public async Task<ActionResult> SaveQuestions(List<JobPreliminaryList> jobPreliminaryLists)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveQuestions", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobPreliminaryLists) };
                logger.Info(log);
                SuccessModel result =await jobPreliminaryService.SaveQuestions(jobPreliminaryLists);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveQuestions", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message};
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a JobPreliminary Questions
        /// </summary>
        /// <param name="jobDetailId"></param>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(JobPreliminaryList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetJobPreliminaryQuestions")]
        public async Task<ActionResult> GetJobPreliminaryQuestions(int jobDetailId)
        {
            try
            {
                List<JobPreliminaryList> jobPreliminaryLists =await jobPreliminaryService.GetJobPreliminaryQuestions(jobDetailId);
                return Ok(jobPreliminaryLists);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobPreliminaryQuestions", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }


        /// <summary>
        /// Answer a Job preliminary Questions
        /// </summary>
        /// <param name="answer"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SavePreliminaryAnswers")]
        public async Task<ActionResult> SavePreliminaryAnswers(SaveAnswer answer)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SavePreliminaryAnswers", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(answer) };
                logger.Info(log);
                if (answer.JobDetailId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                if (answer.UserId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                PreliminaryRoundDetail preliminaryRound = new PreliminaryRoundDetail
                {
                    JobDetailId = answer.JobDetailId,
                    UserId = answer.UserId,
                };
                CreateSuccessModel result =await jobPreliminaryService.SaveAnswer(answer.answersLists, preliminaryRound);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SavePreliminaryAnswers", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"),Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a Preliminary round status
        /// </summary>
        /// <param name="roundDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdatePreliminaryStatus")]
        public async Task<ActionResult> UpdatePreliminaryStatus(UpdateRoundStatus up)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdatePreliminaryStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(up) };
                logger.Info(log);
                if (up.RoundDetailId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "RoundDetailId is required" }); }
                PreliminaryRoundDetail preliminaryRound = new PreliminaryRoundDetail
                {
                    RoundDetailId=up.RoundDetailId,
                    RoundStatus = up.RoundStatus,
                    ActionBy = up.ActionBy,
                    Comments = up.Comments
                };
                CreateSuccessModel result =await jobPreliminaryService .UpdatePreliminaryStatus(preliminaryRound);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {

                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdatePreliminaryStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To create a JobInterview Rounds
        /// </summary>
        /// <param name="jobInterviewRoundLists"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobInterviewRounds")]
        public async Task<ActionResult> SaveJobInterviewRounds(List<JobInterviewRoundList> jobInterviewRoundLists)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobInterviewRounds", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobInterviewRoundLists) };
                logger.Info(log);
                SuccessModel result =await jobPreliminaryService.SaveJobInterviewRounds(jobInterviewRoundLists);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobInterviewRounds", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message};
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a job Round Details
        /// </summary>
        /// <param name="inverviewRoundId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(VwGetJobInterviewRound), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetJobIntervieweRoundsById")]
        public async Task<ActionResult> GetJobIntervieweRoundsById(int inverviewRoundId)
        {
            try
            {
                if (inverviewRoundId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "InterviewRoundId is required" }); }
                VwGetJobInterviewRound result =await jobPreliminaryService.VwGetJobInterviewRound(inverviewRoundId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.NotFound, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobIntervieweRoundsById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a list of interview rounds
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(InterviewRoundList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetJobInterviewRounds")]
        public async Task<ActionResult> GetJobInterviewRounds(int count, int offset,int interviewRoundId,string roundName,string roundDescription,int roundOrder, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                if (offset == 0 || offset == null) { offset = 0; }
                if (count == 0 || count == null) { count = 10; }
                InterviewRoundList interviewRoundList =await jobPreliminaryService.interviewRoundList(count, offset,interviewRoundId,roundName,roundDescription,roundOrder, jobTitle, jobStatus, experienceFrom, experienceTo, salaryFrom, salaryTo, jobDetailId, designationId, curreyncyId);
                return Ok(interviewRoundList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobInterviewRounds", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }

        }

        /// <summary>
        /// To get a AppliedUser List
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles ="2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(AppliedUserList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetJobAppliedUserList")]
        public async Task<ActionResult> GetJobAppliedUserList(int count, int offset, int companyId, string userName, string jobTitle, string email, string keySkills, string locations,string companyName,string roundStatus,decimal experienceFrom,decimal experienceTo)
        {
            try
            {
                if (offset == 0 || offset == null) { offset = 0; }
                if (count == 0 || count == null) { count = 10; }
                AppliedUserList appliedUserList =await jobPreliminaryService.GetJobAppliedUserList(count, offset, companyId, userName, jobTitle, email, keySkills, locations, companyName,roundStatus,experienceFrom, experienceTo);
                return Ok(appliedUserList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobAppliedUserList", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(GetCandidatePreliminaryAnswerList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetCandidatePreliminaryAnswer")]
        public async Task<ActionResult> GetCandidatePreliminaryAnswer(int candidateId, int jobDetailId)
        {
            try
            {
                if (candidateId == 0 || candidateId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "candidateId is required" }); }
                if (jobDetailId == 0 || jobDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "jobDetailId is required" }); }
                GetCandidatePreliminaryAnswerList result = await jobPreliminaryService.GetCandidatePreliminaryAnswer(candidateId, jobDetailId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateHistory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
 