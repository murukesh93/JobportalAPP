﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public  interface IDesignationService
    {
        Task<CreateSuccessModel> SaveDesignation(Designation designation);
        Task<DesignationList> GetDesignationById(int DesignationId);

    }
}
