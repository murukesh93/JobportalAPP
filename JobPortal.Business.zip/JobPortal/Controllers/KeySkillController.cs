﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class KeySkillController : ControllerBase
    {
        private readonly IKeySkillService keySkillService;
        private readonly ILog logger;
        public KeySkillController (IKeySkillService _keySkillService,ILog _log)
        {
            keySkillService = _keySkillService;
            logger = _log;
        }

        /// <summary>
        /// Create a key skill category
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateKeySkillCategory")]
        public async Task<ActionResult> CreateKeySkillCategory(CreateKeySkillCategory category)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateKeySkillCategory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(category) };
                logger.Info(log);
                if (string.IsNullOrEmpty(category.CategoryName)){ return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "categoryName is Required!" }); }
                KeySkillCategory keySkillCategory = new KeySkillCategory { CategoryId = 0, CategoryName = category.CategoryName ,IsActive=true};
                CreateSuccessModel result = await keySkillService.UpsertKeySkilCategory(keySkillCategory);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateKeySkillCategory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return  StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a Keyskill category
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateKeySkillCategory")]
        public async Task<ActionResult> UpdateKeySkillCategory(UpdateKeySkillCategory category)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateKeySkillCategory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(category) };
                logger.Info(log);
                if (category.CategoryId == 0|| category.CategoryId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CategoryId is Required!" }); }
                KeySkillCategory keySkillCategory = new KeySkillCategory
                {
                    CategoryId = category.CategoryId,
                    CategoryName = category.CategoryName,
                    IsActive=category.IsActive
                };
                CreateSuccessModel result = await keySkillService.UpsertKeySkilCategory(keySkillCategory);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateKeySkillCategory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a List of Key skill categoryDetails
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(List<KeySkillCategoryList>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetKeySkillCategoryDetails")]
        public async Task<ActionResult> GetKeySkillCategoryDetails()
        {
            try
            {
                List<KeySkillCategoryList> keySkillCategoryList =await keySkillService.GetKeySkillCategoryDetails();
                return Ok(keySkillCategoryList);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetKeySkillCategoryDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To create a Key skill
        /// </summary>
        /// <param name="keyskill"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateKeySkill")]
        public async Task<ActionResult> CreateKeySkill(CreateSkill keyskill)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateKeySkill", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(keyskill) };
                logger.Info(log);
                if (keyskill.CategoryId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CategoryId is required" }); }
                if (string.IsNullOrEmpty(keyskill.Name)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Name is required" }); }
                KeySkill keySkill = new KeySkill
                {
                    KeySkillId = 0, 
                    CategoryId = keyskill.CategoryId,
                    Name = keyskill.Name,
                    IsActive = true
                };
                CreateSuccessModel result = await keySkillService.UpsertKeySkill(keySkill);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateKeySkill", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a key skill
        /// </summary>
        /// <param name="keySkill"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateKeySkill")]
        public async Task<ActionResult> UpdateKeySkill(UpdateKeySkill keySkill)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateKeySkill", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(keySkill) };
                logger.Info(log);
                if (keySkill.KeySkillId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "KeySkillId is requred" }); }
                KeySkill keySkill1 = new KeySkill
                {
                    KeySkillId = keySkill.KeySkillId,
                    CategoryId = keySkill.CategoryId,
                    Name = keySkill.Name,
                    IsActive = keySkill.IsActive
                };
                CreateSuccessModel result =await keySkillService.UpsertKeySkill(keySkill1);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateKeySkill", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
       // [Authorize(Roles = "1,2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(List<KeySkillList>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetKeySkillByCategoryId")]
        public async Task<ActionResult> GetKeySkillByCategoryId(int categoryId)
        {
            try
            {
                List<KeySkillList> keySkillLists = await keySkillService.GetKeySkillByCategoryId(categoryId);
                return Ok(keySkillLists);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetKeySkillByCategoryId", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
