﻿namespace JobPortal.Business.CustomModel
{
    public class locationList
    {
        public int? cityId { get; set; }
        public int? userId { get; set; }
        public string cityName { get; set; }
    }
}
