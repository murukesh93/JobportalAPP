﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class CompanyCategory
    {
        public int CompanyCategoryId { get; set; }
        public int? CompanyId { get; set; }
        public int? CategoryId { get; set; }

        public virtual KeySkillCategory Category { get; set; }
        public virtual CompanyDetail Company { get; set; }
    }
}
