﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using Microsoft.ApplicationBlocks.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace JobPortal.Business.Common
{
   public static class Common
    {
        public static string GetConnectionString(string key, string value)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder();
            builder.AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"));
            IConfigurationRoot configuration = builder.Build();
            var connstring = configuration.GetSection(key).GetSection(value).Value;
            return connstring;
        }
        public static List<T> ToListof<T>(this DataTable dt)
        {
            try
            {
                const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
                var columnNames = dt.Columns.Cast<DataColumn>()
                    .Select(c => char.ToUpper(c.ColumnName[0]) + c.ColumnName.Substring(1))  // to change first letter to upper case
                    .ToList();
                var objectProperties = typeof(T).GetProperties(flags);
                var targetList = dt.AsEnumerable().Select(dataRow =>
                {
                    var instanceOfT = Activator.CreateInstance<T>();
                    foreach (var properties in objectProperties.Where(properties => columnNames.Contains(properties.Name) && dataRow[properties.Name] != DBNull.Value))
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name], null);
                    }
                    return instanceOfT;
                }).ToList();
                return targetList;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public static DataSet GetResultSet(string procedureName, List<SqlParameter> parameters)
        {
            try
            {
                string connectionstring = Common.GetConnectionString("ConnectionStrings", "DefaultConnection");
                using (DataSet dt = SqlHelper.ExecuteDataset(connectionstring, CommandType.StoredProcedure, procedureName, parameters.ToArray()))
                {
                    return dt;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public
            static string GenerateJSONWebToken(ClaimModel model)  //Login userInfo
        {
            try 
            {
                var JwtKey = Common.GetConnectionString("Jwt", "Key");
                var JwtIssuer = Common.GetConnectionString("Jwt", "Issuer");
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtKey));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[] {
                new Claim(ClaimTypes.PrimarySid, model.UserId ),
                new Claim(ClaimTypes.Role, model.RoleId ),
            };
                var token = new JwtSecurityToken(JwtIssuer,
                JwtIssuer,
                claims,
                null,
                signingCredentials: credentials);
                string encryptedToken =Common.EncryptData( new JwtSecurityTokenHandler().WriteToken(token));
               
                return encryptedToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region Encryption_Decryption
        public static string EncryptData(string textToEncrypt)
        {
            try
            {
                string encryptResult = "";

                string key = Common.GetConnectionString("EncryptDecrypt", "Key");
                string iv = Common.GetConnectionString("EncryptDecrypt", "iv");

                byte[] ivByte = { };
                ivByte = System.Text.Encoding.UTF8.GetBytes(iv.Substring(0, 8));
                byte[] keybyte = { };
                keybyte = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
                MemoryStream ms = null; CryptoStream cs = null;
                byte[] inputbyteArray = System.Text.Encoding.UTF8.GetBytes(textToEncrypt);
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateEncryptor(keybyte, ivByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    encryptResult = Convert.ToBase64String(ms.ToArray());
                }
                return encryptResult;
            }
            catch (Exception ae)
            {
                throw new Exception(ae.Message, ae.InnerException);
            }
        }
        public static string DecryptData(string textToDecrypt)
        {
            try
            {
                string decryptResult = "";

                string key = Common.GetConnectionString("EncryptDecrypt", "Key");
                string iv = Common.GetConnectionString("EncryptDecrypt", "iv");

                byte[] ivByte = { };
                ivByte = System.Text.Encoding.UTF8.GetBytes(iv.Substring(0, 8));
                byte[] keyByte = { };
                keyByte = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
                MemoryStream ms = null; CryptoStream cs = null;
                byte[] inputbyteArray = new byte[textToDecrypt.Replace(" ", "+").Length];
                inputbyteArray = Convert.FromBase64String(textToDecrypt.Replace(" ", "+"));
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateDecryptor(keyByte, ivByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    Encoding encoding = Encoding.UTF8;
                    decryptResult = encoding.GetString(ms.ToArray());
                }
                return decryptResult;
            }
            catch (Exception ae)
            {
                throw new Exception(ae.Message, ae.InnerException);
            }
        }
        #endregion

        public enum FileAccess
        {
            Public = 1, Private= 2
        }
        public static async Task<string> UploadFileToAzure(IFormFile formFile, string DocumentName, FileAccess fileAccess)
        {
            string uri = "";
            try
            {
                var accountKey="" ;
                var folderName ="";
                if (FileAccess.Private == fileAccess)
                {
                    accountKey = Common.GetConnectionString("BlobStorage", "PrivateKey");
                    folderName = Common.GetConnectionString("BlobStorage", "PrivateContainer");
                }
                else
                {
                    accountKey = Common.GetConnectionString("BlobStorage", "PublicKey");
                    folderName = Common.GetConnectionString("BlobStorage", "PublicContainer");
                }
                CloudStorageAccount cloudStorageAccount =  CloudStorageAccount.Parse(accountKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(folderName);
                CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(DocumentName);
                var writeOnlyPolicy = new SharedAccessBlobPolicy()
                {
                    SharedAccessStartTime = DateTime.Now,
                    SharedAccessExpiryTime = DateTime.Now.AddHours(2),
                    Permissions = SharedAccessBlobPermissions.Write
                };
                cloudBlockBlob.GetSharedAccessSignature(writeOnlyPolicy); 
                using (var stream = formFile.OpenReadStream())
                {
                    await cloudBlockBlob.UploadFromStreamAsync(stream);
                }
                uri = Convert.ToString(cloudBlockBlob.Uri);
                return uri;
            }
            catch (Exception e)
            {  
                throw e;
            }
        }

        public static async Task<SuccessModel> SendEmail(string to,string subject,string body,string attachments)
        {
            SuccessModel result;
            var apiKey = Common.GetConnectionString("SendGrid", "ApiKey");
            var senderEmail = Common.GetConnectionString("SendGrid", "SenderEmail");
            var senderName= Common.GetConnectionString("SendGrid", "SenderName");
            var client = new SendGridClient(apiKey);
                var from = new EmailAddress(senderEmail, senderName);
                var Subject = subject;
                var To = new EmailAddress(to);
                var plainTextContent = body;
                var htmlContent = attachments;
                var msg = MailHelper.CreateSingleEmail(from, To, Subject, plainTextContent, htmlContent);
               var response= await client.SendEmailAsync(msg);
            if (response.StatusCode.ToString() == "Accepted")
            {
                 result = new SuccessModel { message = "Email Sent Succesfully", status = "Success" };
            }
            else
            {
                result= new SuccessModel { message = "Email Not Sented", status = "Error" };
            }
            return result;
        }
        public async static Task<DateTime> GetCurrentDBDateTime()
        {
           await using (var dbContext = new JobPortalContext())
            {
                DateTime currentDateTime =await dbContext.Users.Select(q => DateTime.Now).FirstOrDefaultAsync();
                return currentDateTime;
            }
        }
    }
}
