﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
   public interface ICompanyService
    {
        Task<CreateSuccessModel> UpsertCompany(CompanyDetail company, List<int> CategoryId);
        Task<SuccessModel> DeleteCompanyDetails(int companyId);
        Task<CompanyList> GetCompanyDetails(int offset, int count, int companyId, string companyName, string cityName, string stateName, string email, string phoneNumber);
        Task<VWCompanyList> GetCompanyDetailsById(int companyId);
    }
}
 