﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class PkTest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
