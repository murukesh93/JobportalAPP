﻿using System.Collections.Generic;

namespace JobPortal.SwaggerModel
{
    public class CompanySignUp
    { 
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public int? StateId { get; set; }
        public int? CreatedBy { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string CompanySiteUrl { get; set; }
        public List<int> CategoryId { get; set; }
    }
}
