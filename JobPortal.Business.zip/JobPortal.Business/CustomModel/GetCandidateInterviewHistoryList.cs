﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
     public  class GetCandidateInterviewHistoryList
    {
        public List<CandidateInterviewHistory> CandidateInterviewHistory { get; set; }
    }



    public class CandidateInterviewHistory
    {
        public int? interviewRoundId { get; set; }
        public int? jobDetailId { get; set; }
        public string roundName { get; set; }
        public string roundDescription { get; set; }
        public int? roundOrder { get; set; }
        public bool? isActive { get; set; }
        public int? scheduleId { get; set; }
        public int? userId { get; set; }
        public DateTime? interviewStartDateTime { get; set; }
        public DateTime? interviewEndDateTime { get; set; }
        public int? scheduledBy { get; set; }
        public DateTime? scheduledDate { get; set; }
        public int? interviewer { get; set; }
        public string interviewerName { get; set; }
        public string communicationChannel { get; set; }
        public string interviewStatus { get; set; }
        public string interviewResult { get; set; }
    }
}
