﻿namespace JobPortal.Business.CustomModel
{
    public class PreliminaryAnswersList
    {
        public int AnswerId { get; set; }
        public int? QuestionId { get; set; }
        public string UserAnswer { get; set; }
    }
}
