﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class CompanyList
    {
        public List<VwCompanyDetail> data { get; set; }
        public int count { get; set; }
    }
}
