﻿namespace JobPortal.SwaggerModel
{
    public class SaveState
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
        public bool? IsActive { get; set; }
    }
}
