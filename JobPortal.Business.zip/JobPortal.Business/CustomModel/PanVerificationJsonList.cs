﻿using System;

namespace JobPortal.Business.CustomModel
{
    class PanVerificationJsonList
    {
        public string id { get; set; }
        public DateTime created { get; set; }
        public string userId { get; set; }
        public int ttl { get; set; }
        public string accessToken { get; set; }
        public Error error { get; set; }
        public Response response { get; set; }
    }
    public class Error
    {
        public string message { get; set; }
    }
    public class Response
    {
        public string name { get; set; }
        public string number { get; set; }
        public Result result { get; set; }

    }
    public class Result
    {
        public string Verified { get; set; }
        public string message { get; set; }
        public string upstreamName { get; set; }
    }
}
