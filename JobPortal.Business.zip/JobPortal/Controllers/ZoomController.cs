﻿using Microsoft.AspNetCore.Mvc;
using System;
using JobPortal.Business.CustomModel;
using Microsoft.AspNetCore.Http;
using JobPortal.Business.IService;
using System.Net;
using JobPortal.SwaggerModel;
using JobPortal.Business.Model;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ZoomController : ControllerBase
    {
        private readonly IZoomService zoomService;
        private readonly ILog logger;
        public ZoomController(IZoomService _zoomService,ILog _log)
        {
            zoomService = _zoomService;
            logger = _log;
        }
        /// <summary>
        /// Get A hosting user details
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(ZoomApiList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetHostUserDetails")]
        public async Task<ActionResult> GetHostUserDetails() 
        {
            try
            {
                ZoomApiList result = await zoomService.GetUserHostingDetails();
                return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetHostUserDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// Create a New Meeting
        /// </summary>
        /// <param name="meeting"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        [ProducesResponseType(typeof(MeetingCreatedList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateNewMeeting")]
        public async Task<ActionResult> CreateNewMeeting(CreateMeeting meeting)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateNewMeeting", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(meeting) };
                logger.Info(log);
                CreateMeetingList meetingList = new CreateMeetingList
                {
                    Topic=meeting.Topic,
                    Type=meeting.Type,
                    Start_time=meeting.Start_time,
                    Duration=meeting.Duration,
                    Schedule_for=meeting.Schedule_for,
                    Timezone=meeting.Timezone,
                    Agenda=meeting.Agenda
                };
                MeetingCreatedList result = await zoomService.CreateNewMeeting(meetingList);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateNewMeeting", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// List A Scheduled of Meetings
        /// </summary>
        /// <param name="hostId"></param>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(ScheduledMeetingList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("ListScheduledMeetings")]
        public async Task<ActionResult> ListScheduledMeetings(string hostId)
        {
            try
            {
                ScheduledMeetingList result =await zoomService.ListScheduledMeetings(hostId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "ListScheduledMeetings", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Get A Meeting Information by MeetingId
        /// </summary>
        /// <param name="meetingId"></param>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(MeetingCreatedList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetMeetingById")]
        public async Task<ActionResult> GetMeetingById(string meetingId)
        {
            try
            {
                MeetingCreatedList result = await zoomService.GetMeetingById(meetingId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetMeetingById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// Add a New Participants for a meetings
        /// </summary>
        /// <param name="zoom"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("AddParticipant")]
        public async Task<ActionResult> AddNewParticipants(CreateZoomParticipants zoom)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "AddParticipant", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(zoom) };
                logger.Info(log);
                ZoomMeetingParticipant zoomMeeting = new ZoomMeetingParticipant
                {
                    Email=zoom.Email,
                    MeetingId=zoom.MeetingId,
                    Name=zoom.First_name
                };
                SuccessModel result = await zoomService.AddNewParticipants(zoomMeeting);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "AddParticipant", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To delete a meeting participants
        /// </summary>
        /// <param name="delete"></param>
        /// <returns></returns>
        [Authorize]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("DeleteParticipant")]
        public async Task<ActionResult> DeleteParticipant(DeleteRegistrants delete)
        {
            try
            {
                DeleteRegirstrantsList deleteRegirstrants = new DeleteRegirstrantsList
                {
                    MeetingId=delete.MeetingId,
                    RegistrantsId=delete.RegistrantsId,
                    Email=delete.Email
                };
                SuccessModel result = await zoomService.DeleteParticipant(deleteRegirstrants);
                return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteParticipant", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a meeting
        /// </summary>
        /// <param name="up"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPatch]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateMeeting")]
        public async Task<ActionResult> UpdateMeeting(UpdateMeeting up) 
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateMeeting", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(up) };
                logger.Info(log);
                UpdateMeetingList updateMeeting = new UpdateMeetingList
                {
                    MeetingId=up.MeetingId,
                    Topic=up.Topic,
                    Type=up.Type,
                    Start_time=up.Start_time,
                    Duration=up.Duration,
                    Timezone=up.Timezone,
                    Agenda=up.Agenda
                };
                SuccessModel result = await zoomService.UpdateMeeting(updateMeeting);
                return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateMeeting", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To delete a meeting 
        /// </summary>
        /// <param name="meetingId"></param>
        /// <returns></returns>
        [Authorize]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("DeleteMeeting")]
        public async Task<ActionResult> DeleteMeeting(string meetingId)
        {
            try
            {
                SuccessModel result =await zoomService.DeleteMeeting(meetingId);
                    return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteMeeting", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a meeting status
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateMeetingStatus")]
        public async Task<ActionResult> UpdateMeetingStatus(UpdateMeetingStatus status)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateMeetingStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(status) };
                logger.Info(log);
                SuccessModel result = await zoomService.UpdateMeetingStatus(status.MeetingId,status.Action);
                return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateMeetingStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To Get Participant
        /// </summary>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(GetParticipantList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetParticipant")]
        public async Task<ActionResult> GetParticipant(long meetingId, string registrantId)
        {
            try
            {
                GetParticipantList result = await zoomService.GetParticipant(meetingId,registrantId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetParticipant", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }

        }

        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetTimeZone")]
        public async Task<ActionResult> GetTimeZone()
        {
            try
            {
                GetZoomTimeList result = await zoomService.GetZoomList();
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel successModel = new SuccessModel { status = "Error", message = "No record found" };
                    return StatusCode((int)HttpStatusCode.Forbidden, successModel);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetTimeZone", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(GetCalendorList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetCalendorView")]
        public async Task<ActionResult> GetCalendorView(int count, int offset, int interviewerId, string email, string fromDate, string toDate, string meetingStatus,int userId)
        {
            try
            {
                if (count == null || count == 0) { count = 10; }
                if (offset == null || offset == 0) { offset = 0; }

                GetCalendorList getCalendorList = await zoomService.GetCalendorView(count, offset,interviewerId, email, fromDate, toDate,  meetingStatus,userId);
                return Ok(getCalendorList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCalendorView", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}

