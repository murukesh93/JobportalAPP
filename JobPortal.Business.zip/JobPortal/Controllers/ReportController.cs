﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportService reportService;
        private readonly ILog logger;
        public ReportController (IReportService _reportService, ILog _log)
        {
            reportService = _reportService;
            logger = _log;
        }

        /// <summary>
        /// Get Applied Jobs Report
        /// </summary>
        /// <returns></returns>
       
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(ReportServiceList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status404NotFound)]
        [Route("GetAppliedJobs")]
        public async Task<ActionResult> GetAppliedJobs(int count,int offset,int roundDetailId,int userId,string Jobtitle,string firstName,string lastName,string email,
                                            string cityName,string stateName, int jobDetailId,string jobStatus,int companyId)
        {
            try
            {
                if (count==null || count == 0) { count = 10; }
                if (offset == null || offset == 0) { offset = 0; }
                ReportServiceList reportServiceList = await reportService.GetAppliedJobs(count,offset,roundDetailId, userId, Jobtitle, firstName, lastName,
                                                                                    email, cityName, stateName, jobDetailId, jobStatus,companyId);
                return Ok(reportServiceList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetAppliedJobs", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get report for preliminary round status
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(RoundStatusReportList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetRoundsReport")] 
        public async Task<ActionResult> GetRoundsReport(int count, int offset, string userName,int roundDetailId ,string roundStatus, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                if (count == null || count == 0) { count = 10; }
                if (offset == null || offset == 0) { offset = 0; }
                RoundStatusReportList roundStatusReportList =await reportService.GetRoundsReport(count, offset, userName,roundDetailId ,roundStatus, companyId, jobTitle, jobStatus, experienceFrom, experienceTo, salaryFrom, salaryTo, jobDetailId, designationId, curreyncyId);
                return Ok(roundStatusReportList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetRoundsReport", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To get Report for RecruitedDetails
        /// </summary>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(RecruitedDetailsList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetRecruitedDetails")]
        public async Task<ActionResult> GetRecruitedDetails(int count,int offset,int userId,string selectedDate,int companyId,string company,string designation,string jobTitle,string keySkill,string userName, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo,string jobSeekerStatus)
        {
            try
            {
                if (count == null || count == 0) { count = 10; }
                if (offset == null || offset == 0) { offset = 0; }
                RecruitedDetailsList recruitedDetailsList =await reportService.GetRecruitedDetails(count, offset,userId, selectedDate,companyId, company, designation, jobTitle, keySkill, userName, experienceFrom, experienceTo, salaryFrom, salaryTo,jobSeekerStatus);
                return Ok(recruitedDetailsList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetRecruitedDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
