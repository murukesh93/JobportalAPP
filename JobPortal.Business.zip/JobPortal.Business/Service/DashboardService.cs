﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class DashboardService : IDashboardService
    {
        private JobPortalContext dbContext;
        public DashboardService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<SuperAdminDashboardList>  GetSuperAdminDashboard()
        {
            try
            {
                SuperAdminDashboardList superAdminDashboardList = new SuperAdminDashboardList();
                superAdminDashboardList.TotalCompanies = await dbContext.CompanyDetails.CountAsync(s => s.IsDeleted == false);
                superAdminDashboardList.TotalCandidates =await dbContext.Users.CountAsync(s => s.IsDeleted == false && s.RoleId == 4);
                superAdminDashboardList.PendingCandidates = await dbContext.Users.CountAsync(s => s.UserStatus == "Not Verified" && s.IsDeleted == false && s.RoleId == 4);
                superAdminDashboardList.TotalActiveCandidates = await dbContext.Users.CountAsync(s => s.UserStatus == "Verified" && s.IsDeleted == false && s.RoleId == 4);
                superAdminDashboardList.TotalRejectedCanditates = await dbContext.Users.CountAsync(s => s.UserStatus == "Rejected" && s.IsDeleted == false && s.RoleId == 4);
                DashboardTotalCandidates dashboardTotalCandidates = new DashboardTotalCandidates();
                dashboardTotalCandidates.VerifiedCandidates = superAdminDashboardList.TotalActiveCandidates;
                dashboardTotalCandidates.PendingCandidates = superAdminDashboardList.PendingCandidates;
                dashboardTotalCandidates.RejectedCandidates = superAdminDashboardList.TotalRejectedCanditates;
                superAdminDashboardList.dashboardTotalCandidates = dashboardTotalCandidates;
                superAdminDashboardList.dashboardPendingLists =await dbContext.Users.Where(s => s.IsDeleted == false && s.UserStatus == "Not Verified")
                    .OrderByDescending(s => s.CreatedDate).Select(s => new DashboardPendingList { UserId = s.UserId, FirstName = s.FirstName, LastName = s.LastName, ProfileImage = s.ProfileImage }).Take(20).ToListAsync();
                return superAdminDashboardList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<AdminDashboardList> GetAdminDashboard(int companyId) 
        {
            try
            {
                AdminDashboardList adminDashboardList = new AdminDashboardList();
                adminDashboardList.LiveJobsCount =await dbContext.JobDetails.CountAsync(j => j.JobStatus == "In Progress" && j.IsDeleted == false && j.CompanyId == companyId);
                adminDashboardList.ExpiredJobsCount =await dbContext.JobDetails.CountAsync(j => j.JobStatus == "Closed" && j.IsDeleted == false && j.CompanyId == companyId);
                adminDashboardList.DraftJobsCount =await dbContext.JobDetails.CountAsync(j => j.JobStatus == "Draft" && j.IsDeleted == false && j.CompanyId == companyId);

                adminDashboardList.TotalApplications =await (from a in dbContext.PreliminaryRoundDetails
                                                        join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                        where b.CompanyId == companyId && b.IsDeleted == false
                                                        select new PreliminaryRoundDetail
                                                        {
                                                            RoundDetailId = a.RoundDetailId
                                                        }).CountAsync();

                adminDashboardList.TodayApplicationCount =await (from a in dbContext.PreliminaryRoundDetails
                                                            join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                            where b.CompanyId == companyId && b.IsDeleted == false && a.SubmitDate.Date == (DateTime?)DateTime.Now.Date
                                                            select new PreliminaryRoundDetail
                                                            {
                                                                RoundDetailId = a.RoundDetailId
                                                            }).CountAsync();

                adminDashboardList.SelectedCanditates =await (from a in dbContext.RecruitedJobSeekerDetails
                                                         join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                         where b.CompanyId == companyId && b.IsDeleted == false && a.JobSeekerStatus != "Rejected"
                                                         select new RecruitedJobSeekerDetail
                                                         {
                                                             RecruitedDetailId = a.RecruitedDetailId
                                                         }).CountAsync();

                adminDashboardList.NewCanditatesCount =await (from a in dbContext.PreliminaryRoundDetails
                                                         join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                         where b.CompanyId == companyId && b.IsDeleted == false && a.RoundStatus != "Rejected"
                                                         select new PreliminaryRoundDetail
                                                         {
                                                             RoundDetailId = a.RoundDetailId
                                                         }).CountAsync();

                adminDashboardList.RejectedCanditatesCount =await (from a in dbContext.PreliminaryRoundDetails
                                                              join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                              where b.CompanyId == companyId && b.IsDeleted == false && a.RoundStatus == "Rejected"
                                                              select new PreliminaryRoundDetail
                                                              {
                                                                  RoundDetailId = a.RoundDetailId
                                                              }).CountAsync();

                adminDashboardList.ScheduleInterviewCount = await(from s in dbContext.ScheduleInterviews
                                                             join j in dbContext.JobInterviewRounds on s.InterviewRoundId equals j.InterviewRoundId
                                                             join b in dbContext.JobDetails on j.JobDetailId equals b.JobDetailId
                                                             where b.IsDeleted == false && s.InterviewStatus == "New" && b.CompanyId == companyId
                                                             select new ScheduleInterview
                                                             {
                                                                 ScheduleId = s.ScheduleId
                                                             }).CountAsync();

                adminDashboardList.interviewerLists =await (from a in dbContext.ScheduleInterviews
                                                       join u in dbContext.CompanyUsers on a.Interviewer equals u.UserId
                                                       join us in dbContext.Users on u.UserId equals us.UserId
                                                       join i in dbContext.JobInterviewRounds on a.InterviewRoundId equals i.InterviewRoundId
                                                       join j in dbContext.JobDetails on i.JobDetailId equals j.JobDetailId
                                                       where u.CompanyId == companyId && us.UserStatus == "Verified" && us.RoleId == 3 && us.IsDeleted == false
                                                       && j.IsDeleted == false
                                                       select new InterviewerLists
                                                       {
                                                           InterviewerName = us.FirstName + " " + us.LastName,
                                                           ProfileImage = us.ProfileImage,
                                                           Email = us.Email,
                                                           RoundName = i.RoundName,
                                                           JobTitle = j.JobTitle

                                                       }).Take(20).ToListAsync();

                adminDashboardList.todayInterviewLists = await
                   (from a in dbContext.ScheduleInterviews
                    join b in dbContext.Users on a.UserId equals b.UserId
                    join u in dbContext.Users on a.Interviewer equals u.UserId
                    join i in dbContext.JobInterviewRounds on a.InterviewRoundId equals i.InterviewRoundId
                    join j in dbContext.JobDetails on i.JobDetailId equals j.JobDetailId
                    where a.InterviewStatus == "New" && a.ScheduleDate.Date == DateTime.Now.Date && j.CompanyId == companyId
                    && j.IsDeleted == false && i.IsActive == true
                    select new TodayInterviewList
                    {
                        ScheduleId = a.ScheduleId,
                        UserName = b.FirstName + " " + b.LastName,
                        ScheduleDate = a.ScheduleDate,
                        InterviewStatus = a.InterviewStatus,
                        InterviewerName = u.FirstName + " " + u.LastName,
                        InterviewStartDateTime = a.InterviewStartDateTime,
                        InterviewEndDateTime = a.InterviewEndDateTime,
                        ScheduledBy = a.ScheduledBy,
                        CommunicationChannel = a.CommunicationChannel,
                        Feedback = a.Feedback,
                        InterviewRoundId = a.InterviewRoundId,
                        InterviewRoundName = i.RoundName,
                        JobTitle = j.JobTitle,
                        InterviewResult = a.InterviewResult

                    }).ToListAsync();
                return adminDashboardList;
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }
        public async Task<CandidateDashboardList> GetCandidateDashboard(int userId)
        {
            try
            {
                CandidateDashboardList candidateDashboardList = new CandidateDashboardList();
                candidateDashboardList.ApplicationSubmittedCount =await dbContext.PreliminaryRoundDetails.CountAsync(s => s.UserId == userId);
                candidateDashboardList.RejectedCount =await dbContext.PreliminaryRoundDetails.CountAsync(s => s.RoundStatus == "Rejected" && s.UserId == userId);
                candidateDashboardList.ShortlistedInCount =await dbContext.PreliminaryRoundDetails.CountAsync(s => s.RoundStatus != "Rejected" && s.UserId == userId);
                candidateDashboardList.ScheduledInterviewCount =await dbContext.ScheduleInterviews.CountAsync(s => s.UserId == userId && s.InterviewStatus == "New");
                candidateDashboardList.ScheduledInterviewLists =await (from s in dbContext.ScheduleInterviews
                                                                  join u in dbContext.Users on s.UserId equals u.UserId
                                                                  join i in dbContext.JobInterviewRounds on s.InterviewRoundId equals i.InterviewRoundId
                                                                  join j in dbContext.JobDetails on i.JobDetailId equals j.JobDetailId
                                                                  where u.IsDeleted == false && u.UserStatus == "Verified" && i.IsActive == true &&
                                                                  s.UserId == userId && s.ScheduleDate.Date == DateTime.Now.Date
                                                                  select new ScheduledInterviewLists
                                                                  {
                                                                      ScheduleId=s.ScheduleId,
                                                                      JobTitle=j.JobTitle,
                                                                      JobDescription=j.JobDescription,
                                                                      InterviewerName = u.FirstName + " " + u.LastName,
                                                                      profileImage = u.ProfileImage,
                                                                      InterviewStartDateTime = s.InterviewStartDateTime,
                                                                      InterviewEndDateTime = s.InterviewEndDateTime,
                                                                      RoundName = i.RoundName
                                                                  }).ToListAsync();
                return candidateDashboardList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
