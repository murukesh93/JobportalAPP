﻿using System;

namespace JobPortal.SwaggerModel
{
    public class UpdateRecruitedDetails
    {
        public int RecruitedDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public int? UserId { get; set; }
        public int? AppointedBy { get; set; }
        public DateTime JoinDate { get; set; }
        public decimal? SalaryPerMonth { get; set; }
        public int? CurrencyId { get; set; }
        public string AppoinmentCopy { get; set; }
        public string Comments { get; set; }
        public string TermsandConditions { get; set; }
        public string JobSeekerStatus { get; set; }
        public int SelectedLocationId { get; set; }
    }
}
