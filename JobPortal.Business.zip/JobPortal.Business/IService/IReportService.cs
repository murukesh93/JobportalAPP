﻿using JobPortal.Business.CustomModel;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public interface IReportService
    {
        public Task<ReportServiceList> GetAppliedJobs(int count, int offset, int roundDetailId, int userId, string Jobtitle, string firstName, string lastName, string email,
            string cityName, string stateName, int jobDetailId, string jobStatus,int companyId);
        public Task<RoundStatusReportList> GetRoundsReport(int count, int offset, string userName, int roundDetailId, string roundStatus, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId);
        public Task<RecruitedDetailsList>GetRecruitedDetails(int count, int offset, int userId, string selectedDate, int companyId, string company, string designation, string jobTitle, string keySkill
            ,string userName, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, string jobSeekerStatus);
    }                                    
}
 