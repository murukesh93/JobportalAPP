﻿using System;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class CandidateDashboardList
    {
        public int ApplicationSubmittedCount { get; set; }
        public int ShortlistedInCount { get; set; }
        public int ScheduledInterviewCount { get; set; }
        public int RejectedCount { get; set; }
        public List<ScheduledInterviewLists> ScheduledInterviewLists { get; set; }
    }
    public class ScheduledInterviewLists
    {
        public int ScheduleId { get; set; }
        public string InterviewerName { get; set; }
        public string profileImage { get; set; }
        public DateTime? InterviewStartDateTime { get; set; }
        public string JobTitle { get; set; } 
        public string JobDescription { get; set; }
        public string RoundName { get; set; }
        public DateTime ScheduleDate { get; set; } 
        public DateTime? InterviewEndDateTime { get; set; }
    }
}

