﻿namespace JobPortal.SwaggerModel
{
    public class CreateCompanyUser: EndUserSignUp
    {
        public int CompanyId { get; set; }
    }
}
