﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
   public class UpdateRecruitedDetailStatus
    {
        public int RecruitedDetailId { get; set; }
        public string JobSeekerStatus { get; set; }
        public  string Comments { get; set; }
    }
}
