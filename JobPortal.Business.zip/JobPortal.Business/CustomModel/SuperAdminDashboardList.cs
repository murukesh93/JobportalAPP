﻿using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class SuperAdminDashboardList
    {
        public int TotalCandidates { get; set; }
        public int TotalCompanies { get; set; }
        public int TotalActiveCandidates { get; set; }
        public int PendingCandidates { get; set; } 
        public int TotalRejectedCanditates { get; set; }
        public List<DashboardPendingList> dashboardPendingLists { get; set; }
        public DashboardTotalCandidates dashboardTotalCandidates { get; set; }
    }
    public class DashboardPendingList
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ProfileImage { get; set; }
    }
    public class DashboardTotalCandidates
    {
        public int VerifiedCandidates { get; set; }
        public int PendingCandidates { get; set; }
        public int RejectedCandidates { get; set; }
    }
}
