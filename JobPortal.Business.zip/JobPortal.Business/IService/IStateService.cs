﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;

namespace JobPortal.Business.IService
{
    public interface IStateService
    {
       Task<CreateSuccessModel> SaveState(State saveState);
       Task <StateList> GetStateById(int StateId);
    }
}
