﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IJobSeekerService
    {
        Task<CreateSuccessModel> SaveJobSeekerDetails(JobSeekerDetail jobSeekerDetail);
        Task<SuccessModel> SaveJobSeekerKeySkills(List<JobSeekerSkillList> jobSeekerKeySkills);
        Task<SuccessModel> SaveJobSeekerEmploymentDetails(List<JobSeekerEmploymentList> jobSeekerEmploymentLists);
        Task<SuccessModel> DeleteSeekerEmploymentDetails(int employmentDetailId);
        Task<SuccessModel> SaveJobSeekerEducationDetails(List<JobSeekerEducationList> jobSeekerEducationLists);
        Task<SuccessModel> DeleteSeekerEducationDetails(int educationDetailId);
        Task<SuccessModel> SaveJobSeekerProjectDetails(List<JobSeekerProjectList> jobSeekerProjectLists);
        Task<SuccessModel> DeleteSeekerProjectDetails(int projectDetailId);
        Task<CreateSuccessModel> UpsertRecruitedDetails(RecruitedJobSeekerDetail recruitedJob);
        Task<SuccessModel> SavePreferedLocations(List<int>cityId,int userId);
        Task<RecruitedJobSeekerList> GetRecruitedJobSeekerDetailsById(int recruitedDetailId);
        Task<CandidateList> GetCandidateDetails(int userId);
        Task<SuccessModel> DeleteRecruitedJobSeekerDetails(int recruitedDetailId);
        Task<SuccessModel> UpdateRecruitedDetailStatus(int RecruitedDetailId, string JobSeekerStatus,string Comments);
        Task<GetSignupStepStatus> GetSignupStepStatus(int userId);
    }
}
