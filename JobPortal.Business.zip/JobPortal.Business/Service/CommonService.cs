﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
   public class CommonService: ICommonService
    {
       private JobPortalContext dbContext;
        public CommonService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<List<RoleList>> GetRole()
        {
            try
            {
                List<RoleList> Role = await dbContext.Roles.Select(a => new RoleList { RoleId = a.RoleId, RoleName = a.RoleName }).ToListAsync();
                return Role;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> UpdateRole(RoleList roleList)
        {
            SuccessModel result;
            try
            {
                Role exsiistingRole =await dbContext.Roles.FirstOrDefaultAsync(a => a.RoleId == roleList.RoleId);
                if (exsiistingRole !=null)
                {
                    exsiistingRole.RoleName = roleList.RoleName;
                    dbContext.Update(exsiistingRole);
                    result = new SuccessModel { status = "Success", message = "Record Saved Successfully" };
                }
                else
                {
                    result = new SuccessModel { status = "Error", message = "Invalid RoleId" };
                }
                await dbContext.SaveChangesAsync();
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<StateList>> GetState()
        {
            try
            {
                List<StateList> State =await dbContext.States.Select(a => new StateList { StateId = a.StateId, StateName = a.StateName, IsActive = a.IsActive }).ToListAsync();
                return State;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CityList>> GetCity(int? stateId)
        {
            List<CityList> City = null;
            try
            {
                City = await (from e in dbContext.Cities
                              join a in dbContext.States on e.StateId equals a.StateId
                              where e.IsActive == true
                              select new CityList { CityId = e.CityId, CityName = e.CityName, StateId = e.StateId, StateName = a.StateName, isActive = e.IsActive }).ToListAsync();

                if (stateId > 0)
                {
                    City =City.Where(a => a.StateId == stateId).ToList();
                } 

                return City;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CurrencyList>> GetCurrency()
        {
            try
            {
                List<CurrencyList> currency =await dbContext.Currencies.Select(a => new CurrencyList { CurrencyId = a.CurrencyId, CurrencyName = a.CurrencyName, CurrencyCode = a.CurrencyCode }).ToListAsync();
                return currency;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<DesignationList>> GetDesignation()
        {
            try
            {
                List<DesignationList> designation =await dbContext.Designations.Where(a=>a.IsDeleted==false).Select(a => new DesignationList { DesignationId = a.DesignationId, Designation1 = a.DesignationName, IsDeleted = a.IsDeleted }).ToListAsync();
                return designation;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
