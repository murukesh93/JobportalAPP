﻿using System;

namespace JobPortal.Business.CustomModel
{
    public class TodayInterviewList
    {
        public int ScheduleId { get; set; }
        public int? InterviewRoundId { get; set; }
        public int UserId { get; set; }
        public DateTime? InterviewStartDateTime { get; set; }
        public DateTime? InterviewEndDateTime { get; set; }
        public int? ScheduledBy { get; set; }
        public DateTime? ScheduleDate { get; set; }
        public int Interviewer { get; set; }
        public string UserName { get; set; }
        public string InterviewerName { get; set; }
        public string CommunicationChannel { get; set; }
        public string CommunicationUrl { get; set; }
        public string InterviewStatus { get; set; }
        public string InterviewResult { get; set; }
        public string InterviewRoundName { get; set; }
        public string JobTitle { get; set; }
        public string Feedback { get; set; }
    }
    public class TodayCompletedList
    {
        public int ScheduleId { get; set; }
        public int? InterviewRoundId { get; set; }
        public int UserId { get; set; }
        public DateTime? InterviewStartDateTime { get; set; }
        public DateTime? InterviewEndDateTime { get; set; }
        public int? ScheduledBy { get; set; }
        public DateTime? ScheduleDate { get; set; }
        public int Interviewer { get; set; }
        public string UserName { get; set; }
        public string InterviewerName { get; set; }
        public string CommunicationChannel { get; set; }
        public string CommunicationUrl { get; set; }
        public string InterviewStatus { get; set; }
        public string InterviewResult { get; set; }
        public string Feedback { get; set; }
    }
    public class TodayCandidateSelectedList
    {
        public int RecruitedDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public string JobTitle { get; set; }
        public string JobDescritpion { get; set; }
        public string JobStatus { get; set; }
        public string UserName { get; set; }
        public string AppointerName { get; set; }
        public int? UserId { get; set; }
        public DateTime? SelectedDate { get; set; }
        public int? AppointedBy { get; set; }
        public DateTime? JoinDate { get; set; }
        public decimal? SalaryPerMonth { get; set; }
        public int? CurrencyId { get; set; }
        public string AppoinmentCopy { get; set; }
        public string Comments { get; set; }
        public string TermsandConditions { get; set; }
        public string JobSeekerStatus { get; set; }
        public bool? IsDeleted { get; set; }
    }
    public class InterviewerLists
    {
        public string InterviewerName { get; set; }
        public string Email { get; set; }
        public string ProfileImage { get; set; }
        public string JobTitle { get; set; }
        public string RoundName { get; set; }
    }
}
