﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class CityService : ICityService
    {
        private JobPortalContext dbContext;
        public CityService(JobPortalContext _db)
        {
            dbContext = _db;
        }

        public async Task<CreateSuccessModel> SaveCity(City city)
        {
            try
            {
                CreateSuccessModel result;
                if (city.CityId > 0)
                {
                    City existingCity = await dbContext.Cities.FirstOrDefaultAsync(c => c.CityId == city.CityId && c.IsActive == true);
                    int existingCityCount =await dbContext.Cities.CountAsync(c => c.CityName == city.CityName && c.IsActive == true && c.CityId != city.CityId);
                    if (existingCityCount > 0)
                    {
                        result = new CreateSuccessModel { Id = 0, Status = "Error", message = "CityName already Exists" };
                    }
                    else
                    {
                        existingCity.CityName = city.CityName;
                        existingCity.IsActive = city.IsActive;
                        existingCity.StateId = city.StateId;
                        dbContext.Update(existingCity);
                        await dbContext.SaveChangesAsync();

                        result = new CreateSuccessModel { Id = city.CityId, Status = "Success", message = "Record Saved Succesfully" };
                    }
                    return result;
                }
                else
                {
                    int existingCityCount =await dbContext.Cities.CountAsync(c => c.CityName == city.CityName && c.IsActive == true);
                    if (existingCityCount > 0)
                    {
                        result = new CreateSuccessModel { Id = 0, Status = "Error", message = "CityName already Exists" };
                    }
                    else
                    {
                        dbContext.Add(city);
                        await dbContext.SaveChangesAsync();
                        result = new CreateSuccessModel { Id = city.CityId, Status = "Success", message = "Record Saved Succesfully" };
                    }
                    return result;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
       public async Task<CityList> GetCityById(int cityId)
        {
            try
            {
                CityList cityList =await (from e in dbContext.Cities
                                     join a in dbContext.States on e.StateId equals a.StateId
                                     where e.IsActive == true && e.CityId == cityId
                                     select new CityList { CityId = e.CityId, CityName = e.CityName, StateId = e.StateId, StateName = a.StateName, isActive = e.IsActive }).FirstOrDefaultAsync();
                return cityList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
