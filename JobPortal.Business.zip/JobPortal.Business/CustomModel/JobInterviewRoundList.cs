﻿namespace JobPortal.Business.CustomModel
{
    public class JobInterviewRoundList
    {
        public int InterviewRoundId { get; set; }
        public int? JobDetailId { get; set; }
        public string RoundName { get; set; }
        public string RoundDescription { get; set; }
        public int? RoundOrder { get; set; }
        public bool? IsActive { get; set; }
    }
}
