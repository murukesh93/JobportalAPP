﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwGetAppliedUser
    {
        public int RoundDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public int? ActionBy { get; set; }
        public string ActionerName { get; set; }
        public DateTime SubmitDate { get; set; }
        public int? UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string RoundStatus { get; set; }
        public string Comments { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public int? CompanyId { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public string DesignationName { get; set; }
        public string CurrencyName { get; set; }
        public decimal? ExperienceTo { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public int? CurrencyId { get; set; }
        public int? DesignationId { get; set; }
        public int? NumberOfResources { get; set; }
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public string CompanySiteUrl { get; set; }
        public string KeySkills { get; set; }
        public string Locations { get; set; }
    }
}
