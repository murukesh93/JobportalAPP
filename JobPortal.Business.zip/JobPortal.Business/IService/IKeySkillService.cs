﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IKeySkillService
    {
        Task<CreateSuccessModel> UpsertKeySkilCategory(KeySkillCategory Category);
        Task<List<KeySkillCategoryList>> GetKeySkillCategoryDetails();
        Task<CreateSuccessModel> UpsertKeySkill(KeySkill keySkill);
        Task<List<KeySkillList>> GetKeySkillByCategoryId(int? categoryId);
    }
}
