﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class ScheduleInterview
    {
        public int ScheduleId { get; set; }
        public int? InterviewRoundId { get; set; }
        public int? UserId { get; set; }
        public DateTime? InterviewStartDateTime { get; set; }
        public DateTime? InterviewEndDateTime { get; set; }
        public int? ScheduledBy { get; set; }
        public DateTime ScheduleDate { get; set; }
        public int? Interviewer { get; set; }
        public string InterviewStatus { get; set; }
        public string InterviewResult { get; set; }
        public string Feedback { get; set; }
        public string MeetingId { get; set; }
        public string CommunicationChannel { get; set; }
        public string CommunicationNumber { get; set; }

        public virtual JobInterviewRound InterviewRound { get; set; }
        public virtual User InterviewerNavigation { get; set; }
        public virtual User ScheduledByNavigation { get; set; }
        public virtual User User { get; set; }
    }
}
