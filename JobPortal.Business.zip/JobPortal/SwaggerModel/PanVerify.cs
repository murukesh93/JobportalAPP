﻿namespace JobPortal.SwaggerModel
{
    public class PanVerify
    {
        public string PanNumber { get; set; }
        public string Name { get; set; }
    }
}
