﻿using JobPortal.Business.CustomModel;
using System.Collections.Generic;

namespace JobPortal.SwaggerModel
{
    public class SaveAnswer
    {
        public int? JobDetailId { get; set; }
        public int? UserId { get; set; }
        public List<PreliminaryAnswersList> answersLists { get; set; }
    }
}
