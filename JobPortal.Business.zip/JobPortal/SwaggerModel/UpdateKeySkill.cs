﻿namespace JobPortal.SwaggerModel
{
    public class UpdateKeySkill
    {
        public int KeySkillId { get; set; }
        public int? CategoryId { get; set; } 
        public string Name { get; set; }
        public bool? IsActive { get; set; }
    }
}
