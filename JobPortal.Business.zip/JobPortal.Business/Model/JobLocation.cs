﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobLocation
    {
        public int? JobDetailId { get; set; }
        public int? CityId { get; set; }
        public int JobLocationId { get; set; }

        public virtual City City { get; set; }
        public virtual JobDetail JobDetail { get; set; }
    }
}
