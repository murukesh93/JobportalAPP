﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class GetCandidateBySkillSetList
    {
        public List<VwGetCandidateBySkillSet> data { get; set; }
        public int count { get; set; }
    }
}
