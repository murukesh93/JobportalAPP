﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
   public class UpdateJobStatus
    {
       public int JobDetailId { get; set; }
            public string JobStatus { get; set; }
    }
}
