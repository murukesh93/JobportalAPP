﻿namespace JobPortal.SwaggerModel
{
    public class SaveDesignation
    {
        public int designationid { get; set; }
        public string designation { get; set; }
        public bool isDeleted { get; set; }
    }
}
