﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class UserList
    {
        public List<VwUser> data { get; set; }
        public int count { get; set; }
    }
}
