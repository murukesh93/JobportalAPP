﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class KeySkillCategory
    {
        public KeySkillCategory()
        {
            CompanyCategories = new HashSet<CompanyCategory>();
            KeySkills = new HashSet<KeySkill>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<CompanyCategory> CompanyCategories { get; set; }
        public virtual ICollection<KeySkill> KeySkills { get; set; }
    }
}
