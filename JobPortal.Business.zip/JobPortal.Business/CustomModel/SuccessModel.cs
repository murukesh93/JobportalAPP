﻿namespace JobPortal.Business.CustomModel
{
    public class SuccessModel
    {
        public string message { get; set; }
        public string status { get; set; }
    }
}
