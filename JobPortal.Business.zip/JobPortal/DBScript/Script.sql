create database JobPortal;
use JobPortal;

 Create table Role(
roleId int primary key not null identity(1,1),
roleName varchar(50) unique not null
)
go

SET IDENTITY_INSERT Role ON;
insert into Role(roleId,roleName)values(1,'Super Admin');
insert into Role(roleId,roleName)values(2,'Admin');
insert into Role(roleId,roleName)values(3,'Interviewer');
insert into Role(roleId,roleName)values(4,'Job Seeker');
SET IDENTITY_INSERT Role OFF;
go




/****** Object:  Database [devjobportal]    Script Date: 17/09/2021 21:43:42 ******/
CREATE DATABASE [devjobportal]  /*(EDITION = 'Basic', SERVICE_OBJECTIVE = 'Basic', MAXSIZE = 2 GB) WITH CATALOG_COLLATION = SQL_Latin1_General_CP1_CI_AS;*/
GO
ALTER DATABASE [devjobportal] SET COMPATIBILITY_LEVEL = 140
GO
ALTER DATABASE [devjobportal] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [devjobportal] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [devjobportal] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [devjobportal] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [devjobportal] SET ARITHABORT OFF 
GO
ALTER DATABASE [devjobportal] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [devjobportal] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [devjobportal] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [devjobportal] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [devjobportal] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [devjobportal] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [devjobportal] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [devjobportal] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [devjobportal] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [devjobportal] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [devjobportal] SET READ_COMMITTED_SNAPSHOT ON 
GO
ALTER DATABASE [devjobportal] SET  MULTI_USER 
GO
ALTER DATABASE [devjobportal] SET ENCRYPTION ON
GO
ALTER DATABASE [devjobportal] SET QUERY_STORE = ON
GO
ALTER DATABASE [devjobportal] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 100, QUERY_CAPTURE_MODE = ALL, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200 )
GO
/****** Object:  Table [dbo].[JobDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobDetails](
	[jobDetailId] [int] IDENTITY(1,1) NOT NULL,
	[jobTitle] [varchar](100) NULL,
	[jobDescription] [varchar](max) NULL,
	[createdDate] [datetime] NULL,
	[createdBy] [int] NULL,
	[jobStatus] [varchar](20) NULL,
	[numberOfResources] [int] NULL,
	[experienceFrom] [decimal](5, 2) NULL,
	[experienceTo] [decimal](5, 2) NULL,
	[designationId] [int] NULL,
	[currencyId] [int] NULL,
	[salaryFrom] [decimal](15, 2) NULL,
	[salaryTo] [decimal](15, 2) NULL,
	[isDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[jobDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobLocations]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobLocations](
	[jobDetailId] [int] NULL,
	[cityId] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[City]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[City](
	[cityId] [int] IDENTITY(1,1) NOT NULL,
	[cityName] [varchar](50) NULL,
	[stateId] [int] NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[cityId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[cityName] ASC,
	[stateId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobKeySkills]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobKeySkills](
	[jobDetailId] [int] NULL,
	[keySkillId] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[KeySkillCategory]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[KeySkillCategory](
	[categoryId] [int] IDENTITY(1,1) NOT NULL,
	[categoryName] [varchar](50) NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[categoryId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[categoryName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[KeySkill]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[KeySkill](
	[keySkillId] [int] IDENTITY(1,1) NOT NULL,
	[categoryId] [int] NULL,
	[name] [varchar](50) NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[keySkillId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[VwGetJobDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 Create view [dbo].[VwGetJobDetails]
 as
 select jd.jobDetailId,jd.jobTitle,jd.jobDescription,jd.createdDate,jd.createdBy,jd.jobStatus,jd.numberOfResources
 ,jd.experienceFrom,jd.experienceTo,jd.designationId,jd.currencyId,jd.salaryFrom,
 (select jl.jobDetailId,jl.cityId,ct.cityName from jobLocations jl inner join city ct on ct.cityId=jl.cityId 
 and jl.jobDetailId=jd.jobDetailId for json path)jobLocations,
 (select jk.jobDetailId,ks.keySkillId,ks.categoryId,kc.categoryName,ks.name,ks.isActive,
 jk.jobKeySkillId from jobKeySkills jk inner join keySkill ks on ks.keySkillId=jk.keySkillId
 inner join keySkillCategory kc on kc.categoryId=ks.categoryId where ks.isActive=1 and jk.jobDetailId=jd.jobDetailId for json path)keySkills,
 jd.salaryTo,jd.isDeleted from JobDetails jd
 where jd.isDeleted=0
GO
/****** Object:  Table [dbo].[JobInterviewRounds]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobInterviewRounds](
	[interviewRoundId] [int] IDENTITY(1,1) NOT NULL,
	[jobDetailId] [int] NULL,
	[roundName] [varchar](50) NULL,
	[roundDescription] [varchar](max) NULL,
	[roundOrder] [int] NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[interviewRoundId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[VwGetJobInterviewRounds]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create view [dbo].[VwGetJobInterviewRounds]
as
select jr.interviewRoundId,jr.jobDetailId,jr.roundName,jr.roundDescription,
jd.jobTitle,jd.jobDescription,jd.createdDate,jd.createdBy,jd.jobStatus,jd.numberOfResources,
jd.experienceFrom,jd.experienceTo,jd.designationId,jd.currencyId,jd.salaryFrom,jd.salaryTo,jd.isDeleted,
(select jl.jobDetailId,jl.cityId,ct.cityName from jobLocations jl inner join city ct on ct.cityId=jl.cityId   
 and jl.jobDetailId=jd.jobDetailId for json path)jobLocations,  
 (select jk.jobDetailId,ks.keySkillId,ks.categoryId,kc.categoryName,ks.name,ks.isActive,  
 jk.jobKeySkillId from jobKeySkills jk inner join keySkill ks on ks.keySkillId=jk.keySkillId  
 inner join keySkillCategory kc on kc.categoryId=ks.categoryId where ks.isActive=1 and jk.jobDetailId=jd.jobDetailId for json path)keySkills,
jr.roundOrder,jr.isActive from jobInterviewRounds jr
left join JobDetails jd on jd.jobDetailId=jr.jobDetailId
where jr.isActive=1 and jd.isDeleted=0
GO
/****** Object:  Table [dbo].[ScheduleInterview]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ScheduleInterview](
	[scheduleId] [int] IDENTITY(1,1) NOT NULL,
	[interviewRoundId] [int] NULL,
	[userId] [int] NULL,
	[interviewStartDateTime] [datetime] NULL,
	[interviewEndDateTime] [datetime] NULL,
	[scheduledBy] [int] NULL,
	[scheduleDate] [datetime] NULL,
	[interviewer] [int] NULL,
	[communicationChannel] [varchar](50) NULL,
	[communicationUrl] [varchar](max) NULL,
	[interviewStatus] [varchar](50) NULL,
	[interviewResult] [varchar](30) NULL,
	[feedback] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[scheduleId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[userId] [int] IDENTITY(1,1) NOT NULL,
	[firstName] [varchar](50) NULL,
	[lastName] [varchar](50) NULL,
	[email] [varchar](50) NULL,
	[password] [varchar](500) NULL,
	[address] [varchar](250) NULL,
	[cityId] [int] NULL,
	[stateId] [int] NULL,
	[createdDate] [datetime] NULL,
	[createdBy] [int] NULL,
	[roleId] [int] NOT NULL,
	[userStatus] [varchar](50) NULL,
	[isDeleted] [bit] NULL,
	[dob] [date] NULL,
	[panNumber] [varchar](30) NULL,
	[profileImage] [varchar](1000) NULL,
	[countryCode] [varchar](10) NULL,
	[phoneNumber] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[userId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[VwGetScheduleInterview]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE view [dbo].[VwGetScheduleInterview]  
as  
select sc.scheduleId,sc.interviewRoundId,sc.userId,concat_ws(' ',us.firstName,us.lastName)userName,format(sc.interviewStartDateTime,'MM/dd/yyyy')interviewStartDateTime,  
format(sc.interviewEndDateTime,'MM/dd/yyyy')interviewEndDateTime,sc.scheduledBy,concat_ws(' ',se.firstName,se.lastName)schedulerName,sc.interviewer,concat_ws(' ',er.firstName,er.lastName)interviewerName,sc.communicationChannel,sc.communicationUrl,sc.interviewStatus,  
sc.interviewResult,sc.feedback,ji.roundName,ji.roundDescription,ji.roundOrder,  
jd.jobTitle,jd.jobDescription  
from ScheduleInterview sc  
left join [User] us on us.userId=sc.userId  
left join [User] se on se.userId=sc.scheduledBy  
left join [User] er on er.userId=sc.interviewer  
left join JobInterviewRounds ji on ji.interviewRoundId=sc.interviewRoundId  
left join JobDetails jd on jd.jobDetailId=ji.jobDetailId
GO
/****** Object:  Table [dbo].[CompanyUsers]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyUsers](
	[companyUserId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[companyId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[companyUserId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Role](
	[roleId] [int] IDENTITY(1,1) NOT NULL,
	[roleName] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[roleId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[roleName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[State]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[State](
	[stateId] [int] IDENTITY(1,1) NOT NULL,
	[stateName] [varchar](50) NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[stateId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[stateName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CompanyDetail]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyDetail](
	[companyId] [int] IDENTITY(1,1) NOT NULL,
	[companyName] [varchar](100) NULL,
	[createdDate] [datetime] NULL,
	[companyLogo] [varchar](1000) NULL,
	[address] [varchar](250) NULL,
	[cityId] [int] NULL,
	[stateId] [int] NULL,
	[createdBy] [int] NULL,
	[phoneNumber] [varchar](50) NULL,
	[email] [varchar](50) NULL,
	[isDeleted] [bit] NULL,
	[companySiteUrl] [varchar](1000) NULL,
PRIMARY KEY CLUSTERED 
(
	[companyId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vwUser]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE view [dbo].[vwUser]  
as  
select us.userId,us.firstName,us.lastName,us.email,us.address,ct.cityId,ct.cityName,st.stateId,st.stateName,rl.roleId,rl.roleName,  
us.createdDate,us.createdBy, concat(cr.firstName,cr.lastName)createdName,us.userStatus,us.dob,us.panNumber,us.profileImage,us.countryCode,  
us.phoneNumber,cd.companyName,cd.companyLogo,cd.companyId  
from [User] us left join City ct on ct.cityId=us.cityId  
left join State st on st.stateId=us.stateId  
left join [User] cr on cr.createdBy=us.userId  
inner join Role rl on rl.RoleId=us.roleId  
left join CompanyUsers cu on cu.userId=us.userId
left join CompanyDetail cd on cd.companyId=cu.companyId
where us.isDeleted=0;
GO
/****** Object:  View [dbo].[VwCompanyDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create view [dbo].[VwCompanyDetails]
as
select cd.companyId,cd.companyName,cd.companyLogo,cd.createdDate,cd.address,cd.cityId,cy.cityName,cd.stateId,
st.stateName,cd.createdBy,
cd.email,cd.phoneNumber,cd.isDeleted,cd.companySiteUrl from CompanyDetail cd
left join City cy on cy.cityId=cd.cityId
left join State st on st.stateId=cd.stateId
where cd.isDeleted=0
GO
/****** Object:  Table [dbo].[Currency]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Currency](
	[currencyId] [int] IDENTITY(1,1) NOT NULL,
	[currencyName] [varchar](50) NULL,
	[currencyCode] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[currencyId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[currencyName] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Designation]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Designation](
	[designationId] [int] IDENTITY(1,1) NOT NULL,
	[designation] [varchar](50) NULL,
	[isDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[designationId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[designation] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobPreliminaryQuestions]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobPreliminaryQuestions](
	[questionId] [int] IDENTITY(1,1) NOT NULL,
	[jobDetailId] [int] NULL,
	[questionLable] [nvarchar](2000) NULL,
	[questionType] [varchar](50) NULL,
	[questionOptions] [varchar](max) NULL,
	[answer] [varchar](2000) NULL,
	[questionDescription] [varchar](max) NULL,
	[sortOrder] [int] NULL,
	[isActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[questionId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerDetail]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerDetail](
	[jobSeekerId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[workExperience] [decimal](5, 2) NULL,
	[resumeUrl] [varchar](1000) NULL,
	[resumeHeading] [varchar](100) NULL,
	[currentCTC] [decimal](15, 2) NULL,
	[currencyId] [int] NULL,
	[noticePeriod] [int] NULL,
	[expectedCTC] [decimal](15, 2) NULL,
	[personalInfo] [varchar](max) NULL,
	[payslip] [varchar](max) NULL,
	[designationId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[jobSeekerId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerEducationDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerEducationDetails](
	[educationDetailId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[course] [varchar](50) NULL,
	[specialization] [varchar](50) NULL,
	[institute] [varchar](100) NULL,
	[yearOfPassing] [int] NULL,
	[percentage] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[educationDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerEmployementDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerEmployementDetails](
	[employementDetailId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[organizationName] [varchar](50) NULL,
	[designationId] [int] NULL,
	[isCurrentCompany] [bit] NULL,
	[workingFrom] [date] NULL,
	[workingTo] [date] NULL,
	[jobDescribtion] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[employementDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerKeySkills]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerKeySkills](
	[seekerKeySkill] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[keySkillId] [int] NULL,
	[description] [varchar](max) NULL,
	[workExperience] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[seekerKeySkill] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerPreferredWorkLocation]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerPreferredWorkLocation](
	[userId] [int] NULL,
	[cityId] [int] NULL,
	[workLocationId] [int] IDENTITY(1,1) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[workLocationId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[JobSeekerProjectDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[JobSeekerProjectDetails](
	[projectDetailId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[projectName] [varchar](50) NULL,
	[projectDescription] [varchar](max) NULL,
	[duration] [decimal](5, 2) NULL,
	[yourRole] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[projectDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LoginProvider]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginProvider](
	[loginProviderId] [int] IDENTITY(1,1) NOT NULL,
	[loginProviderType] [varchar](25) NULL,
	[loginProviderKey] [varchar](250) NULL,
	[userId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[loginProviderId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PreliminaryQuestionAnswers]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PreliminaryQuestionAnswers](
	[answerId] [int] IDENTITY(1,1) NOT NULL,
	[userId] [int] NULL,
	[questionId] [int] NULL,
	[userAnswer] [varchar](2000) NULL,
PRIMARY KEY CLUSTERED 
(
	[answerId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PreliminaryRoundDetail]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PreliminaryRoundDetail](
	[roundDetailId] [int] IDENTITY(1,1) NOT NULL,
	[jobDetailId] [int] NULL,
	[userId] [int] NULL,
	[submitDate] [datetime] NULL,
	[roundStatus] [varchar](30) NULL,
	[actionBy] [int] NULL,
	[comments] [varchar](1000) NULL,
PRIMARY KEY CLUSTERED 
(
	[roundDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RecruitedJobSeekerDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RecruitedJobSeekerDetails](
	[recruitedDetailId] [int] IDENTITY(1,1) NOT NULL,
	[jobDetailId] [int] NULL,
	[userId] [int] NULL,
	[appointedBy] [int] NULL,
	[joinDate] [datetime] NULL,
	[salaryPerMonth] [decimal](15, 2) NULL,
	[currencyId] [int] NULL,
	[appoinmentCopy] [varchar](1000) NULL,
	[comments] [varchar](max) NULL,
	[termsandConditions] [varchar](max) NULL,
	[jobSeekerStatus] [varchar](50) NULL,
	[isDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[recruitedDetailId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[User] ADD  DEFAULT (getdate()) FOR [createdDate]
GO
ALTER TABLE [dbo].[User] ADD  DEFAULT ((0)) FOR [isDeleted]
GO
ALTER TABLE [dbo].[CompanyDetail]  WITH CHECK ADD FOREIGN KEY([createdBy])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[CompanyUsers]  WITH CHECK ADD FOREIGN KEY([companyId])
REFERENCES [dbo].[CompanyDetail] ([companyId])
GO
ALTER TABLE [dbo].[CompanyUsers]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobDetails]  WITH CHECK ADD FOREIGN KEY([createdBy])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobDetails]  WITH CHECK ADD FOREIGN KEY([currencyId])
REFERENCES [dbo].[Currency] ([currencyId])
GO
ALTER TABLE [dbo].[JobDetails]  WITH CHECK ADD FOREIGN KEY([designationId])
REFERENCES [dbo].[Designation] ([designationId])
GO
ALTER TABLE [dbo].[JobInterviewRounds]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[JobKeySkills]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[JobKeySkills]  WITH CHECK ADD FOREIGN KEY([keySkillId])
REFERENCES [dbo].[KeySkill] ([keySkillId])
GO
ALTER TABLE [dbo].[JobLocations]  WITH CHECK ADD FOREIGN KEY([cityId])
REFERENCES [dbo].[City] ([cityId])
GO
ALTER TABLE [dbo].[JobLocations]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[JobPreliminaryQuestions]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[JobSeekerDetail]  WITH CHECK ADD FOREIGN KEY([currencyId])
REFERENCES [dbo].[Currency] ([currencyId])
GO
ALTER TABLE [dbo].[JobSeekerDetail]  WITH CHECK ADD FOREIGN KEY([designationId])
REFERENCES [dbo].[Designation] ([designationId])
GO
ALTER TABLE [dbo].[JobSeekerDetail]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobSeekerEducationDetails]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobSeekerEmployementDetails]  WITH CHECK ADD FOREIGN KEY([designationId])
REFERENCES [dbo].[Designation] ([designationId])
GO
ALTER TABLE [dbo].[JobSeekerEmployementDetails]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobSeekerKeySkills]  WITH CHECK ADD FOREIGN KEY([keySkillId])
REFERENCES [dbo].[KeySkill] ([keySkillId])
GO
ALTER TABLE [dbo].[JobSeekerKeySkills]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobSeekerPreferredWorkLocation]  WITH CHECK ADD FOREIGN KEY([cityId])
REFERENCES [dbo].[City] ([cityId])
GO
ALTER TABLE [dbo].[JobSeekerPreferredWorkLocation]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[JobSeekerProjectDetails]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[KeySkill]  WITH CHECK ADD FOREIGN KEY([categoryId])
REFERENCES [dbo].[KeySkillCategory] ([categoryId])
GO
ALTER TABLE [dbo].[LoginProvider]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[PreliminaryQuestionAnswers]  WITH CHECK ADD FOREIGN KEY([questionId])
REFERENCES [dbo].[JobPreliminaryQuestions] ([questionId])
GO
ALTER TABLE [dbo].[PreliminaryQuestionAnswers]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[PreliminaryRoundDetail]  WITH CHECK ADD FOREIGN KEY([actionBy])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[PreliminaryRoundDetail]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[PreliminaryRoundDetail]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[RecruitedJobSeekerDetails]  WITH CHECK ADD FOREIGN KEY([appointedBy])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[RecruitedJobSeekerDetails]  WITH CHECK ADD FOREIGN KEY([currencyId])
REFERENCES [dbo].[Currency] ([currencyId])
GO
ALTER TABLE [dbo].[RecruitedJobSeekerDetails]  WITH CHECK ADD FOREIGN KEY([jobDetailId])
REFERENCES [dbo].[JobDetails] ([jobDetailId])
GO
ALTER TABLE [dbo].[RecruitedJobSeekerDetails]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[ScheduleInterview]  WITH CHECK ADD FOREIGN KEY([interviewRoundId])
REFERENCES [dbo].[JobInterviewRounds] ([interviewRoundId])
GO
ALTER TABLE [dbo].[ScheduleInterview]  WITH CHECK ADD FOREIGN KEY([interviewer])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[ScheduleInterview]  WITH CHECK ADD FOREIGN KEY([scheduledBy])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[ScheduleInterview]  WITH CHECK ADD FOREIGN KEY([userId])
REFERENCES [dbo].[User] ([userId])
GO
ALTER TABLE [dbo].[User]  WITH CHECK ADD FOREIGN KEY([cityId])
REFERENCES [dbo].[City] ([cityId])
GO
ALTER TABLE [dbo].[User]  WITH CHECK ADD FOREIGN KEY([roleId])
REFERENCES [dbo].[Role] ([roleId])
GO
ALTER TABLE [dbo].[User]  WITH CHECK ADD FOREIGN KEY([stateId])
REFERENCES [dbo].[State] ([stateId])
GO
/****** Object:  StoredProcedure [dbo].[spGetCompanyDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[spGetCompanyDetails](              
@count int=null,              
@offset int=null,              
@companyName varchar(50)=null,  
@stateName varchar(50)=null,   
@email varchar(30)=null,    
@phoneNumber varchar(30)=null ,
@cityName varchar(50)=null,  
@companyId int=null  
)              
as              
begin              
              
DECLARE @SQL NVARCHAR(max);                                  
DECLARE @SQLCount NVARCHAR(max);                                   
DECLARE @SQLFilter NVARCHAR(max);                                  
                   
SET @SQL = 'select * from VwCompanyDetails where  0=0  ';                                  
set @SQLCount= 'select count(companyId)totalCount from VwCompanyDetails where 0=0   ';                                 
SET @SQLFilter = '';                                        
                                                  
IF(@companyName<>'')                                  
 SET @SQLFilter =concat( @SQLFilter , ' and companyName like ''%' + @companyName + '%''') ;    
  
 IF(@stateName<>'')                                  
 SET @SQLFilter =concat( @SQLFilter , ' and stateName like ''%' + @stateName + '%''') ;    
    
IF(@email<>'')                                  
 SET @SQLFilter =concat( @SQLFilter , ' and email like ''%' + @email + '%''') ;                     
               
IF(@phoneNumber<>'')                                  
 SET @SQLFilter =concat( @SQLFilter , ' and phoneNumber like ''%' + @phoneNumber + '%''') ;  
                
IF(@cityName<>'')                                  
 SET @SQLFilter =concat( @SQLFilter , ' and cityName like ''%' + @cityName + '%''') ;  
                
IF(@companyId<>'')                                  
  SET @SQLFilter =concat( @SQLFilter , ' and companyId=' +CONVERT(VARCHAR(10), @companyId) + ' ') ;                        
                    
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                               
                            
 SET @SQLFilter =concat( @SQLFilter , ' order by companyId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                
                             
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                             
                              
EXEC (@SQLCount);                                
EXEC (@SQL);              
                 
end
GO
/****** Object:  StoredProcedure [dbo].[spGetJobDetails]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 CREATE procedure [dbo].[spGetJobDetails](                
@count int=null,                
@offset int=null,                
@jobTitle varchar(50)=null,    
@jobStatus varchar(50)=null,     
@experienceFrom decimal(5,2)=null,  
@experienceto decimal(5,2)=null,  
@salaryFrom decimal(15,2)=null,  
@salaryTo decimal(15,2)=null,  
@designationId int=null ,
@currencyId int=null ,
@jobDetailId int=null    
)                
as                
begin                
                
DECLARE @SQL NVARCHAR(max);                                    
DECLARE @SQLCount NVARCHAR(max);                                     
DECLARE @SQLFilter NVARCHAR(max);                                    
                     
SET @SQL = 'select * from VwGetJobDetails where  0=0  ';                                    
set @SQLCount= 'select count(jobDetailId)totalCount from VwGetJobDetails where 0=0   ';                                   
SET @SQLFilter = '';                                          
                                                    
IF(@jobTitle<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;      
    
 IF(@jobStatus<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and jobStatus like ''%' + @jobStatus + '%''') ;      
    
  IF(@experienceFrom>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and experienceFrom=' +CONVERT(VARCHAR(10), @experienceFrom) + ' ') ;  

  IF(@experienceTo>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and experienceTo=' +CONVERT(VARCHAR(10), @experienceTo) + ' ') ;  

  IF(@salaryFrom>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and salaryFrom=' +CONVERT(VARCHAR(10), @salaryFrom) + ' ') ;  
  
  IF(@salaryTo>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and salaryTo=' +CONVERT(VARCHAR(10), @salaryTo) + ' ') ;  
                      
  IF(@designationId>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and designationId=' +CONVERT(VARCHAR(10), @designationId) + ' ') ;  
  
  IF(@currencyId>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and currencyId=' +CONVERT(VARCHAR(10), @currencyId) + ' ') ;  

  IF(@jobDetailId>0)                                    
  SET @SQLFilter =concat( @SQLFilter , ' and jobDetailId=' +CONVERT(VARCHAR(10), @jobDetailId) + ' ') ;  

set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                 
                              
 SET @SQLFilter =concat( @SQLFilter , ' order by jobDetailId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                  
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                  
                               
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                               
                                
EXEC (@SQLCount);                                  
EXEC (@SQL);                
                   
end
GO
/****** Object:  StoredProcedure [dbo].[spGetJobInterviewRounds]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure spGetJobInterviewRounds(                    
@count int=null,                    
@offset int=null,                    
@jobTitle varchar(50)=null,        
@jobStatus varchar(50)=null,  
@roundName varchar(50)=null,  
@interviewRoundId int=null,  
@roundDescription varchar(max)=null,  
@roundOrder int =null,  
@experienceFrom decimal(5,2)=null,      
@experienceto decimal(5,2)=null,      
@salaryFrom decimal(15,2)=null,      
@salaryTo decimal(15,2)=null,      
@designationId int=null ,    
@currencyId int=null ,    
@jobDetailId int=null        
)                    
as                    
begin                    
                    
DECLARE @SQL NVARCHAR(max);                                        
DECLARE @SQLCount NVARCHAR(max);                                         
DECLARE @SQLFilter NVARCHAR(max);                                        
                         
SET @SQL = 'select * from VwGetJobInterviewRounds where  0=0  ';                                        
set @SQLCount= 'select count(interviewRoundId)totalCount from VwGetJobInterviewRounds where 0=0   ';                                       
SET @SQLFilter = '';                                              
                                                        
IF(@jobTitle<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;          
        
 IF(@jobStatus<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and jobStatus like ''%' + @jobStatus + '%''') ;          
        
 IF(@roundName<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and roundName like ''%' + @roundName + '%''') ;          
        
 IF(@roundDescription<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and roundDescription like ''%' + @roundDescription + '%''') ;          
        
  IF(@experienceFrom>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and experienceFrom=' +CONVERT(VARCHAR(10), @experienceFrom) + ' ') ;      
    
  IF(@experienceTo>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and experienceTo=' +CONVERT(VARCHAR(10), @experienceTo) + ' ') ;    
      
  IF(@roundOrder>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and roundOrder=' +CONVERT(VARCHAR(10), @roundOrder) + ' ') ;    
      
  IF(@interviewRoundId>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and interviewRoundId=' +CONVERT(VARCHAR(10), @interviewRoundId) + ' ') ;    
    
  IF(@salaryFrom>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and salaryFrom=' +CONVERT(VARCHAR(10), @salaryFrom) + ' ') ;      
      
  IF(@salaryTo>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and salaryTo=' +CONVERT(VARCHAR(10), @salaryTo) + ' ') ;      
                          
  IF(@designationId>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and designationId=' +CONVERT(VARCHAR(10), @designationId) + ' ') ;      
      
  IF(@currencyId>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and currencyId=' +CONVERT(VARCHAR(10), @currencyId) + ' ') ;      
    
  IF(@jobDetailId>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and jobDetailId=' +CONVERT(VARCHAR(10), @jobDetailId) + ' ') ;      
    
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                     
                                  
 SET @SQLFilter =concat( @SQLFilter , ' order by roundOrder asc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                      
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');          
 select @SQLFilter;
                                   
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);      
                                    
EXEC (@SQLCount);                                      
EXEC (@SQL);                    
                       
end
GO
/****** Object:  StoredProcedure [dbo].[spGetScheduleInterview]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 CREATE procedure [dbo].[spGetScheduleInterview](                  
@count int=null,                  
@offset int=null,                  
@jobTitle varchar(50)=null,      
@userName varchar(50)=null,       
@interviewRoundId int=null,    
@userId int=null,    
@interviewerId int=null,
@scheduleBy int=null,
@interviewStartDateTime varchar(50)=null,    
@interviewEndDateTime  varchar(50)=null,
@schedulerName varchar(50)=null,    
@interviewerName varchar(50)=null,
@interviewStatus varchar(50)=null ,  
@roundOrder int=null ,  
@roundName varchar(50)=null  ,
@interviewResult varchar(50)=null,
@communicationChannel varchar(50)=null
)                  
as                  
begin                  
                  
DECLARE @SQL NVARCHAR(max);                                      
DECLARE @SQLCount NVARCHAR(max);                                       
DECLARE @SQLFilter NVARCHAR(max);                                      
                       
SET @SQL = 'select * from VwGetScheduleInterview where  0=0  ';                                      
set @SQLCount= 'select count(scheduleId)totalCount from VwGetScheduleInterview where 0=0   ';                                     
SET @SQLFilter = '';                                            
                                                      
IF(@jobTitle<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;        
      
 IF(@userName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and userName like ''%' + @userName + '%''') ;        
 
 IF(@schedulerName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and schedulerName like ''%' + @schedulerName + '%''') ;        
      
 IF(@interviewerName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and interviewerName like ''%' + @interviewerName + '%''') ;        
 
 IF(@interviewStatus<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and interviewStatus like ''%' + @interviewStatus + '%''') ;        
      
 IF(@roundName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and roundName like ''%' + @roundName + '%''') ;        
 
  IF(@interviewResult<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and roundName like ''%' + @interviewResult + '%''') ;  
 
  IF(@communicationChannel<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and communicationChannel like ''%' + @communicationChannel + '%''') ;  
 
  IF(@interviewStartDateTime<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and interviewStartDateTime like ''%' + FORMAT(convert(datetime,@interviewStartDateTime),'MM/dd/yyyy') + '%''') ;  

  IF(@interviewEndDateTime<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and interviewEndDateTime like ''%' + format(convert(datetime,@interviewEndDateTime),'MM/dd/yyyy') + '%''') ;  

  IF(@userId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and userId=' +CONVERT(VARCHAR(10), @userId) + ' ') ;    
  
  IF(@interviewerId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and interviewer=' +CONVERT(VARCHAR(10), @interviewerId) + ' ') ;    
  
  IF(@scheduleBy>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and scheduleBy=' +CONVERT(VARCHAR(10), @scheduleBy) + ' ') ;    
    
  IF(@roundOrder>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and roundOrder=' +CONVERT(VARCHAR(10), @roundOrder) + ' ') ;    
                         
  
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                   
                                
 SET @SQLFilter =concat( @SQLFilter , ' order by scheduleId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                    
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                    
                                 
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                 
                                  
EXEC (@SQLCount);                                    
EXEC (@SQL);                  
                     
end
GO
/****** Object:  StoredProcedure [dbo].[spGetUser]    Script Date: 17/09/2021 21:43:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[spGetUser](                
@count int=null,                
@offset int=null,                
@firstName varchar(50)=null,    
@lastName varchar(50)=null,     
@email varchar(30)=null,      
@phoneNumber varchar(30)=null,    
@companyId int =null,  
@companyName varchar(50)=null,
@roleId int=null,
@roleName varchar(50)=null,
@userStatus varchar(50)=null
)                
as                
begin                
                
DECLARE @SQL NVARCHAR(max);                                    
DECLARE @SQLCount NVARCHAR(max);                                     
DECLARE @SQLFilter NVARCHAR(max);                                    
                     
SET @SQL = 'select * from vwUser where  0=0  ';                                    
set @SQLCount= 'select count(userId)totalCount from vwUser where 0=0   ';                                   
SET @SQLFilter = '';                                          
                                                    
IF(@firstName<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and firstName like ''%' + @firstName + '%''') ;      
    
 IF(@lastName<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and lastName like ''%' + @lastName + '%''') ;      
      
IF(@email<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and email like ''%' + @email + '%''') ;                       
                 
IF(@phoneNumber<>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and phoneNumber like ''%' + @phoneNumber + '%''') ;                       
  
IF(@companyName <>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and companyName like ''%' + @companyName + '%''') ;                       

IF(@roleName <>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and roleName like ''%' + @roleName + '%''') ;      
 
 IF(@userStatus <>'')                                    
 SET @SQLFilter =concat( @SQLFilter , ' and userStatus like ''%' + @userStatus + '%''') ;   
 
 if(@roleId >0)                              
  SET @SQLFilter =concat( @SQLFilter , ' and roleId=' +CONVERT(VARCHAR(10), @roleId) + ' ') ;      
  
                                  
if(@companyId >0)                              
  SET @SQLFilter =concat( @SQLFilter , ' and companyId=' +CONVERT(VARCHAR(10), @companyId) + ' ') ;      
  
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                 
                              
 SET @SQLFilter =concat( @SQLFilter , ' order by userId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                  
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                  
                               
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                               
                                
EXEC (@SQLCount);                                  
EXEC (@SQL);                
                   
end  
GO
ALTER DATABASE [devjobportal] SET  READ_WRITE 
GO

Alter table RecruitedJobSeekerDetails
add selectedDate datetime;

create table companyCategory(
companyCategoryId	int identity(1,1)	primary key,
companyId	int	FOREIGN KEY REFERENCES CompanyDetail(companyId),
categoryId	int	FOREIGN KEY REFERENCES KeySkillCategory(categoryId))
go


alter view VwCompanyDetails  
as  
select cd.companyId,cd.companyName,cd.companyLogo,cd.createdDate,cd.address,cd.cityId,cy.cityName,cd.stateId,  
st.stateName,cd.createdBy,  
cd.email,cd.phoneNumber,cd.isDeleted,cd.companySiteUrl,
(select cc.companyId,ks.name,cc.categoryId from companyCategory cc
left join KeySkill ks on ks.categoryId=cc.categoryId  where isActive=1 FOR JSON PATH)companyCategory 
from CompanyDetail cd  
left join City cy on cy.cityId=cd.cityId  
left join State st on st.stateId=cd.stateId  
where cd.isDeleted=0;
go


create view VwGetSearchJobs  
as  
select  jd.jobDetailId,jd.jobTitle,jd.jobDescription,jd.createdDate,jd.createdBy,jd.jobStatus,jd.numberOfResources,  
jd.experienceFrom,jd.experienceTo,jd.designationId,jd.currencyId,jd.salaryFrom,jd.salaryTo,
jd.companyid,
searchSkills=stuff((select ','+ ks.name+','+cp.companyName+','+jobTitle from JobKeySkills jk 
left join KeySkill ks on ks.keySkillId=jk.keySkillId
left join CompanyDetail cp on cp.companyId=jd.companyId
where jk.jobDetailId=jd.jobDetailId
FOR XML PATH ('')), 1, 1, ''),
searchLocations=stuff((select ','+ ci.cityName+','+si.stateName from JobLocations jl 
left join city ci on ci.cityId=jl.cityid
left join State si on si.stateId=ci.stateId
where jl.jobDetailId=jd.jobDetailId
FOR XML PATH ('')), 1, 1, '')
from jobDetails jd  
where jd.isDeleted=0 
go

create procedure spSearchJobs(                  
@count int=null,                  
@offset int=null,                  
@jobTitle varchar(50)=null,      
@jobStatus varchar(50)=null,       
@experienceFrom decimal(5,2)=null,    
@experienceto decimal(5,2)=null,    
@salaryFrom decimal(15,2)=null,    
@salaryTo decimal(15,2)=null,    
@designationId int=null ,  
@companyId int=null,
@currencyId int=null ,  
@jobDetailId int=null,
@searchLocations varchar(50)=null,
@searchSkills varchar(50)=null
)                  
as                  
begin                  
                  
DECLARE @SQL NVARCHAR(max);                                      
DECLARE @SQLCount NVARCHAR(max);                                       
DECLARE @SQLFilter NVARCHAR(max);                                      
                       
SET @SQL = 'select * from VwGetSearchJobs where  0=0  ';                                      
set @SQLCount= 'select count(jobDetailId)totalCount from VwGetSearchJobs where 0=0   ';                                     
SET @SQLFilter = '';                                            
                                                      
IF(@jobTitle<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;        
      
 IF(@jobStatus<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and jobStatus like ''%' + @jobStatus + '%''') ;  
 
 IF(@searchLocations<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and searchLocations like ''%' + @searchLocations + '%''') ;  

  IF(@searchSkills<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and searchSkills like ''%' + @searchSkills + '%''') ;  
      
  IF(@experienceFrom>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and experienceFrom=' +CONVERT(VARCHAR(10), @experienceFrom) + ' ') ;    
  
  IF(@experienceTo>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and experienceTo=' +CONVERT(VARCHAR(10), @experienceTo) + ' ') ;    
  
   
  IF(@companyId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and companyId=' +CONVERT(VARCHAR(10), @companyId) + ' ') ;   

  IF(@salaryFrom>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and salaryFrom=' +CONVERT(VARCHAR(10), @salaryFrom) + ' ') ;    
    
  IF(@salaryTo>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and salaryTo=' +CONVERT(VARCHAR(10), @salaryTo) + ' ') ;    
                        
  IF(@designationId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and designationId=' +CONVERT(VARCHAR(10), @designationId) + ' ') ;    
    
  IF(@currencyId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and currencyId=' +CONVERT(VARCHAR(10), @currencyId) + ' ') ;    
  
  IF(@jobDetailId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and jobDetailId=' +CONVERT(VARCHAR(10), @jobDetailId) + ' ') ;    
  
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                   
                                
 SET @SQLFilter =concat( @SQLFilter , ' order by jobDetailId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                    
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                    
                                 
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                 
                                  
EXEC (@SQLCount);                                    
EXEC (@SQL);                  
                     
end
go

go

Alter procedure spGetAppliedJobsDetails(                  
@count int=null,                  
@offset int=null,                  
@roundDetailId int=null,      
@userId int=null,               
@Jobtitle varchar(30)=null ,    
@firstName varchar(50)=null,      
@lastName varchar(50)=null,  
@email varchar(30)=null,
@cityName varchar(30)=null,  
@stateName varchar(30)=null,  
@jobDetailId int=null,  
@jobStatus varchar(30)=null  
)                  
as                  
begin                  
                  
DECLARE @SQL NVARCHAR(max);                                      
DECLARE @SQLCount NVARCHAR(max);                                       
DECLARE @SQLFilter NVARCHAR(max);                                      
                       
SET @SQL = 'select * from VWPreliminaryRound where  0=0  ';                                      
set @SQLCount= 'select count(UserId)totalCount from VWPreliminaryRound where 0=0   ';                                     
SET @SQLFilter = '';                                            
                                                      
IF(@roundDetailId<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and roundDetailId=' +CONVERT(VARCHAR(10), @roundDetailId) + ' ') ;        
      
IF(@userId<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and userId=' +CONVERT(VARCHAR(10), @userId) + ' ') ;         
  
IF(@Jobtitle<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and Jobtitle like ''%' + @Jobtitle + '%''') ;   
  
IF(@firstName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and firstName like ''%' + @firstName + '%''') ;   
  
IF(@lastName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and lastName like ''%' + @lastName + '%''') ;   
         
IF(@email<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and email like ''%' + @email + '%''') ;   
                    
IF(@cityName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and cityName like ''%' + @cityName + '%''') ;     
   
IF(@stateName<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and stateName like ''%' + @stateName + '%''') ;   
  
IF(@jobDetailId<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and jobDetailId=' +CONVERT(VARCHAR(10), @jobDetailId) + ' ') ;  
                   
IF(@jobStatus<>'')                                      
 SET @SQLFilter =concat( @SQLFilter , ' and jobStatus like ''%' + @jobStatus + '%''') ;     
                          
                        
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                   
                                
 SET @SQLFilter =concat( @SQLFilter , ' order by userId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                    
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                    
                                 
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                                              
EXEC (@SQLCount);                                    
EXEC (@SQL);                  
                     
end
go

alter view VWGetRecruitedDetails
as
select rd.recruitedDetailId,rd.jobDetailId,rd.userId,rd.appointedBy,rd.joinDate,rd.salaryPerMonth,rd.currencyId,rd.appoinmentCopy,rd.comments,
rd.termsandConditions,rd.jobSeekerStatus,FORMAT(rd.selectedDate,'MM/dd/yyyy')selectedDate,
KeySkill=stuff((select ','+ ks.name from JobKeySkills jk   
left join KeySkill ks on ks.keySkillId=jk.keySkillId  
where ks.isActive=1
FOR XML PATH ('')), 1, 1, ''),
jd.jobTitle,jd.jobDescription,jd.createdBy,jd.jobStatus,jd.numberOfResources,jd.experienceFrom,jd.experienceTo
,jd.salaryFrom,jd.salaryTo,jd.companyId,cd.companyName,cd.companyLogo,cd.address companyAddress,
cd.createdBy companyCreateby,cd.phoneNumber companyPhoneNumber,cd.email companyEmail,cd.companySiteUrl,
CONCAT(u.firstName,' ',u.lastName)userName,u.email userEmail,u.address userAddress,u.roleId,u.userStatus,u.dob,
u.panNumber,u.profileImage,CONCAT(u.countryCode,u.phoneNumber)userPhoneNumber,c.cityName,s.stateName,d.designation
from RecruitedJobSeekerDetails rd
left join JobDetails jd on jd.jobDetailId=rd.jobDetailId
left join CompanyDetail cd on cd.companyId=jd.companyId
left join [user] u on u.userId=rd.userId
left join city c on c.cityId=cd.cityId
left join state s on s.stateId=cd.stateId
left join Designation d on d.designationId=jd.designationId
where u.isDeleted=0 
--and u.userStatus='Verified' and cd.isDeleted=0 and jd.isDeleted=0
go

alter procedure spGetRecruitedDetails(                    
@count int=null,                    
@offset int=null,                    
@selectedDate varchar(30)=null,
@companyId int=null, 
@company varchar(50)=null, 
@Jobtitle varchar(30)=null ,             
@designation varchar(50)=null,   
@keyskill varchar(30)=null    
)                    
as                    
begin                    
                    
DECLARE @SQL NVARCHAR(max);                                        
DECLARE @SQLCount NVARCHAR(max);                                         
DECLARE @SQLFilter NVARCHAR(max);                                        
                         
SET @SQL = 'select * from VWGetRecruitedDetails where  0=0  ';                                        
set @SQLCount= 'select count(UserId)totalCount from VWGetRecruitedDetails where 0=0   ';                                       
SET @SQLFilter = '';                                              
        
IF(@selectedDate<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and selectedDate like ''%' + @selectedDate + '%''') ; 
 
IF(@Jobtitle<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and Jobtitle like ''%' + @Jobtitle + '%''') ;     
    
IF(@companyId<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and companyId like ''%' + CONVERT(VARCHAR(10), @companyId)  + '%''') ; 
 
IF(@company<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and company like ''%' + @company + '%''') ;     
           
IF(@designation<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and designation like ''%' + @designation + '%''') ;     
                      
IF(@keyskill<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and keyskill like ''%' + @keyskill + '%''') ;                         
                          
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                     
                                  
 SET @SQLFilter =concat( @SQLFilter , ' order by userId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                      
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                      
                                   
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                                                
EXEC (@SQLCount);                                      
EXEC (@SQL);                    
                       
end
go

create procedure spGetRoundsReport(                  
@count int=null,                  
@offset int=null,                  
@jobTitle varchar(50)=null,      
@jobStatus varchar(50)=null,       
@experienceFrom decimal(5,2)=null,    
@experienceto decimal(5,2)=null,    
@salaryFrom decimal(15,2)=null,    
@salaryTo decimal(15,2)=null,    
@roundStatus varchar(50)=null,
@userName varchar(50)=null,
@roundDetailId int=null,
@designationId int=null ,  
@companyId int=null,
@currencyId int=null ,  
@jobDetailId int=null,
@searchLocations varchar(50)=null,
@searchSkills varchar(50)=null
)                  
as                  
begin                  
                  
DECLARE @SQL NVARCHAR(max);                                      
DECLARE @SQLCount NVARCHAR(max);                                       
DECLARE @SQLFilter NVARCHAR(max);                                      
                       
SET @SQL = 'select * from VwGetRoundStatus where  0=0  ';                                      
set @SQLCount= 'select count(jobDetailId)totalCount from VwGetRoundStatus where 0=0   ';                                     
SET @SQLFilter = '';                                            
                                                      
  IF(@jobTitle<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;        
      
  IF(@jobStatus<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and jobStatus like ''%' + @jobStatus + '%''') ;  

       
  IF(@userName<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and userName like ''%' + @userName + '%''') ;  

       
  IF(@roundStatus<>'')                                      
  SET @SQLFilter =concat( @SQLFilter , ' and roundStatus like ''%' + @roundStatus + '%''') ;  
 
  IF(@roundDetailId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and roundDetailId=' +CONVERT(VARCHAR(10), @roundDetailId) + ' ') ;  
 
  IF(@experienceFrom>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and experienceFrom=' +CONVERT(VARCHAR(10), @experienceFrom) + ' ') ;    
  
  IF(@experienceTo>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and experienceTo=' +CONVERT(VARCHAR(10), @experienceTo) + ' ') ;    
  
   
  IF(@companyId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and companyId=' +CONVERT(VARCHAR(10), @companyId) + ' ') ;   

  IF(@salaryFrom>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and salaryFrom=' +CONVERT(VARCHAR(10), @salaryFrom) + ' ') ;    
    
  IF(@salaryTo>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and salaryTo=' +CONVERT(VARCHAR(10), @salaryTo) + ' ') ;    
                        
  IF(@designationId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and designationId=' +CONVERT(VARCHAR(10), @designationId) + ' ') ;    
    
  IF(@currencyId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and currencyId=' +CONVERT(VARCHAR(10), @currencyId) + ' ') ;    
  
  IF(@jobDetailId>0)                                      
  SET @SQLFilter =concat( @SQLFilter , ' and jobDetailId=' +CONVERT(VARCHAR(10), @jobDetailId) + ' ') ;    
  
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                   
                                
 SET @SQLFilter =concat( @SQLFilter , ' order by jobDetailId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                    
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                    
                                 
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                 
                                  
EXEC (@SQLCount);                                    
EXEC (@SQL);                  
                     
end
go

create view VwGetAppliedUsers
as
select pr.roundDetailId,pr.jobDetailId,pr.actionBy,CONCAT_WS(' ',ur.firstName,ur.lastName)actionerName,pr.submitDate
,pr.userId,CONCAT_WS(' ',us.firstName,us.lastName)userName,us.email,
pr.roundStatus,pr.comments,jd.jobTitle,jd.jobDescription,jd.companyId,jd.experienceFrom
,jd.experienceTo,jd.salaryFrom,jd.salaryTo,jd.currencyId,jd.designationId,jd.numberOfResources,
cp.companyName,cp.companyLogo,cp.companySiteUrl,
keySkills=stuff((select ','+ ks.name from JobKeySkills jk   
left join KeySkill ks on ks.keySkillId=jk.keySkillId  
where jk.jobDetailId=jd.jobDetailId  
FOR XML PATH ('')), 1, 1, ''),  
locations=stuff((select ','+ ci.cityName+','+si.stateName from JobLocations jl   
left join city ci on ci.cityId=jl.cityid  
left join State si on si.stateId=ci.stateId  
where jl.jobDetailId=jd.jobDetailId  
FOR XML PATH ('')), 1, 1, '')  
from PreliminaryRoundDetail pr
left join JobDetails jd on jd.jobDetailId=pr.jobDetailId
left join [User] us on us.userId=pr.userId
left join [User] ur on ur.userId=pr.actionBy
left join CompanyDetail cp on cp.companyId=jd.companyId
where pr.roundStatus='New' and jd.isDeleted=0 and us.userStatus='Verified' and us.isDeleted=0
go

CREATE procedure spGetAppliedUserList(                    
@count int=null,                    
@offset int=null,                    
@userName varchar(50)=null,
@jobTitle varchar(50)=null,
@email varchar(50)=null,
@keySkills varchar(50)=null,
@locations varchar(50)=null,
@companyId int=null,
@companyName varchar(50)=null
)                    
as                    
begin                    
                    
DECLARE @SQL NVARCHAR(max);                                        
DECLARE @SQLCount NVARCHAR(max);                                         
DECLARE @SQLFilter NVARCHAR(max);                                        
                         
SET @SQL = 'select * from VwGetAppliedUsers where  0=0  ';                                        
set @SQLCount= 'select count(roundDetailId)totalCount from VwGetAppliedUsers where 0=0   ';                                       
SET @SQLFilter = '';                                              
                                                        
IF(@jobTitle<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and jobTitle like ''%' + @jobTitle + '%''') ;          
        
 IF(@userName<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and userName like ''%' + @userName + '%''') ;    
   
 IF(@locations<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and locations like ''%' + @locations + '%''') ;    
  
  IF(@keySkills<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and keySkills like ''%' + @keySkills + '%''') ;    
        
 IF(@email<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and email like ''%' + @email + '%''') ; 

  IF(@companyName<>'')                                        
 SET @SQLFilter =concat( @SQLFilter , ' and companyName like ''%' + @companyName + '%''') ; 
     
  IF(@companyId>0)                                        
  SET @SQLFilter =concat( @SQLFilter , ' and companyId=' +CONVERT(VARCHAR(10), @companyId) + ' ') ;     

    
set @SQLCount=CONCAT(@SQLCount,' ',@SQLFilter);                                     
                                  
 SET @SQLFilter =concat( @SQLFilter , ' order by roundDetailId desc OFFSET '+ cast( @Count * @Offset as varchar(20))+' ROWS ',                                      
 ' FETCH NEXT '+Cast( @Count as varchar(20)) +' ROWS ONLY');                                      
                                   
 set @SQL=CONCAT(@SQL,' ',@SQLFilter);                                   
                                    
EXEC (@SQLCount);                                      
EXEC (@SQL);                    
                       
end
go

create table zoomMeeting(
zoomMeetingId	int primary key identity(1,1),
meetingId	varchar(30),
topic	varchar(250),
meetingUrl	varchar(1000),
meetingStatus	varchar(25))
go

alter table ScheduleInterview 
drop column communicationUrl
go
