﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.SwaggerModel
{
    public class UpdateMeetingStatus
    {
        public string MeetingId { get; set; }
        public string Action { get; set; }
    }
}
