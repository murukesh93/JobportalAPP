﻿namespace JobPortal.Business.CustomModel
{
    public class JobSeekerEducationList
    {
        public int EducationDetailId { get; set; }
        public int? UserId { get; set; }
        public string Course { get; set; }
        public bool? IsDeleted { get; set; }
        public string Specialization { get; set; }
        public string Institute { get; set; }
        public int? YearOfPassing { get; set; }
        public decimal? Percentage { get; set; }
    }
}
