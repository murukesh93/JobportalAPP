﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerKeySkill
    {
        public int SeekerKeySkill { get; set; }
        public int? UserId { get; set; }
        public int? KeySkillId { get; set; }
        public string Description { get; set; }
        public decimal? WorkExperience { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual KeySkill KeySkill { get; set; }
        public virtual User User { get; set; }
    }
}
