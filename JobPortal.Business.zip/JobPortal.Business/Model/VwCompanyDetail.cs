﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwCompanyDetail
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public string CityName { get; set; }
        public int? StateId { get; set; }
        public string StateName { get; set; }
        public int? CreatedBy { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public bool? IsDeleted { get; set; }
        public string CompanySiteUrl { get; set; }
        public string CompanyCategory { get; set; }
    }
}
