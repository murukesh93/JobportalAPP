﻿using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using Microsoft.AspNetCore.Http;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static JobPortal.Business.Common.Common;

namespace JobPortal.Business.Service
{
    public class UploadService: IUploadService
    {
       public async Task<FileUploadModel> UploadFile(IFormFile formFile , FileAccess fileAccess)                                                                                                                                                         
        {
            try
            {
                string myFileName = null;
                myFileName = formFile.FileName;
                string Exceptsymbols = Regex.Replace(myFileName, @"[^.0-9a-zA-Z]+", "");
                string[] strFilename = Exceptsymbols.Split('.');
                myFileName = strFilename[0] + "_" + DateTime.Now.ToString("dd'-'MM'-'yyyy'-'HH'-'mm'-'ss") + "." + strFilename[1];
                string fileurl = Common.Common.UploadFileToAzure(formFile, myFileName, fileAccess).Result;
                return new FileUploadModel { Status = "Success", FilePath = fileurl, Message = "File uploaded successfully" };
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
       public async Task<FileUploadModel> GetUserDelegationSasBlob(string filePath)
        {
            try
            {
                string connectionString = Common.Common.GetConnectionString("BlobStorage", "PrivateKey");
                string containerName = Common.Common.GetConnectionString("BlobStorage", "PrivateContainer");
                string accountKey = Common.Common.GetConnectionString("BlobStorage", "AccountKey");
                string[] fileName = filePath.Split('/');
                BlobClient service = new BlobClient(connectionString, containerName, fileName[fileName.Length - 1]);
                var storageSharedKeyCredential = new StorageSharedKeyCredential(service.AccountName, accountKey);
                BlobSasBuilder blobSasBuilder = new BlobSasBuilder()
                {
                    BlobContainerName = containerName,
                    BlobName = service.Name,
                    Resource = "b",
                };
                string storedPolicyName = null;
                if (storedPolicyName == null)
                {
                    blobSasBuilder.StartsOn = DateTimeOffset.UtcNow;
                    blobSasBuilder.ExpiresOn = DateTimeOffset.UtcNow.AddHours(24);
                    blobSasBuilder.SetPermissions(BlobContainerSasPermissions.Read);
                }
                else
                {
                    blobSasBuilder.Identifier = storedPolicyName;
                }
                string sasToken = blobSasBuilder.ToSasQueryParameters(storageSharedKeyCredential).ToString();
                UriBuilder fullUri = new UriBuilder()
                {
                    Scheme = "https",
                    Host = string.Format("{0}.blob.core.windows.net", service.AccountName),
                    Path = string.Format("{0}/{1}", containerName, service.Name),
                    Query = sasToken,
                };
                return new FileUploadModel { Status = "Success", Message = "File Upload Successfully !", FilePath = fullUri.Uri.ToString() };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
