﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class Designation
    {
        public Designation()
        {
            JobDetails = new HashSet<JobDetail>();
            JobSeekerDetails = new HashSet<JobSeekerDetail>();
            JobSeekerEmployementDetails = new HashSet<JobSeekerEmployementDetail>();
        }

        public int DesignationId { get; set; }
        public string DesignationName { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual ICollection<JobDetail> JobDetails { get; set; }
        public virtual ICollection<JobSeekerDetail> JobSeekerDetails { get; set; }
        public virtual ICollection<JobSeekerEmployementDetail> JobSeekerEmployementDetails { get; set; }
    }
}
