﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class KeySkillCategoryService : IKeySkillService
    {
        private JobPortalContext dbContext;
        public KeySkillCategoryService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<CreateSuccessModel> UpsertKeySkilCategory(KeySkillCategory category)
        {
            try
            {
                CreateSuccessModel result;

                if (category.CategoryId > 0)
                {
                    KeySkillCategory existingCategory = await dbContext.KeySkillCategories.FirstOrDefaultAsync(k => k.CategoryId == category.CategoryId);
                    existingCategory.CategoryName = category.CategoryName;
                    existingCategory.IsActive = category.IsActive;
                    dbContext.Update(existingCategory);
                }
                else
                {
                    int KeycategoryCount = await dbContext.KeySkillCategories.Where(k => k.CategoryName == category.CategoryName).CountAsync();
                    if (KeycategoryCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "CategoryName already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    category.IsActive = true;
                    await dbContext.KeySkillCategories.AddAsync(category);
                }
                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = category.CategoryId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<KeySkillCategoryList>> GetKeySkillCategoryDetails()
        {
            try
            {
                List<KeySkillCategoryList> keySkillCategoryList = await dbContext.KeySkillCategories.Where(k => k.IsActive == true)
                     .Select(k => new KeySkillCategoryList { CategoryId = k.CategoryId, CategoryName = k.CategoryName, IsActive = k.IsActive }).ToListAsync();
                return keySkillCategoryList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CreateSuccessModel> UpsertKeySkill(KeySkill keySkill)
        {
            try
            {
                CreateSuccessModel result;
                if (keySkill.KeySkillId > 0)
                {
                    KeySkill existingKeySkill = await dbContext.KeySkills.FirstOrDefaultAsync(k => k.KeySkillId == keySkill.KeySkillId);
                    int keySkillCount = await dbContext.KeySkills.Where(k => k.Name == keySkill.Name && k.IsActive == true && k.KeySkillId != existingKeySkill.KeySkillId).CountAsync();
                    if (keySkillCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "KeySkill Name already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    else
                    {
                        existingKeySkill.Name = keySkill.Name;
                        existingKeySkill.CategoryId = keySkill.CategoryId;
                        existingKeySkill.IsActive = keySkill.IsActive;
                        dbContext.Update(existingKeySkill);

                    }

                }
                else
                {
                    int keySkillCount = await dbContext.KeySkills.Where(k => k.Name == keySkill.Name && k.IsActive == true).CountAsync();
                    if (keySkillCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "KeySkill Name already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    keySkill.IsActive = true;
                    await dbContext.KeySkills.AddAsync(keySkill);
                }
                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = keySkill.KeySkillId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<KeySkillList>> GetKeySkillByCategoryId(int? categoryId)
        {
            List<KeySkillList> keySkillLists = null;
            try
            {
                keySkillLists = await dbContext.KeySkills.Where(k => k.IsActive == true)
       .Select(k => new KeySkillList { KeySkillId = k.KeySkillId, CategoryId = k.CategoryId, Name = k.Name, IsActive = k.IsActive }).ToListAsync();

                if (categoryId > 0)
                {
                    keySkillLists = keySkillLists.Where(a => a.CategoryId == categoryId).ToList();
                }

                return keySkillLists;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

