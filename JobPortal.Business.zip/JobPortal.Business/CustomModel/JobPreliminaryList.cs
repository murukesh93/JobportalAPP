﻿namespace JobPortal.Business.CustomModel
{
    public class JobPreliminaryList
    {
        public int QuestionId { get; set; } 
        public int? JobDetailId { get; set; }
        public string QuestionLable { get; set; }
        public string QuestionType { get; set; }
        public string QuestionOptions { get; set; }
        public string Answer { get; set; }
        public string QuestionDescription { get; set; }
        public int? SortOrder { get; set; }
        public bool? IsActive { get; set; }
    }
}
