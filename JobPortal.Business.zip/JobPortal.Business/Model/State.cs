﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class State
    {
        public State()
        {
            Users = new HashSet<User>();
        }

        public int StateId { get; set; }
        public string StateName { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}
