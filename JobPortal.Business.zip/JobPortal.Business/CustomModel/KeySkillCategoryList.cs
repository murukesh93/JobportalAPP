﻿namespace JobPortal.Business.CustomModel
{
    public class KeySkillCategoryList
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool? IsActive { get; set; }
    }
}
