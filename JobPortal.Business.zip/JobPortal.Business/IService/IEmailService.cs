﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IEmailService
    {
       Task<SuccessModel> GenerateOtp(Otpvalue otpvalueModel, string email,string otpType);
       Task<SuccessModel> UpdatePasswordByOtp(UpdatePasswordByOtp model, Otpvalue otpvalueMOdel, User userModel);
       Task<SuccessModel> PasswordByEmail(User user);
        public Task<SuccessModel> UserStatusEmail(string email, string userStatus , string comments);
        public Task<SuccessModel> ApplyJobMail(string createdBy, string jobTitle, string designationName);
    }
}
