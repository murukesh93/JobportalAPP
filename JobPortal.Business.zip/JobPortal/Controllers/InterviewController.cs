﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InterviewController : Controller
    {
        private readonly IInterviewService interviewService;
        private readonly ILog logger;
        public InterviewController(IInterviewService _interviewService, ILog _log)
        {
            interviewService = _interviewService;
            logger = _log;
        }

        /// <summary>
        /// To create a Interview schedule
        /// </summary>
        /// <param name="interview"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateInterview")]
        public async Task<ActionResult> CreateInterview(CreateInterview interview)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateInterview", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(interview) };
                logger.Info(log);
                if (interview.InterviewRoundId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "InterviewRoundId is required" }); }
                if (interview.UserId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                if (interview.Interviewer == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Interviewer is required" }); }
                if (interview.ScheduledBy == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "scheduledBy is required" }); }
                if (string.IsNullOrEmpty(interview.CommunicationChannel)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Communication Channel is required" }); }
                ScheduleInterview scheduleInterview = new ScheduleInterview
                {
                    ScheduleId = 0,
                    InterviewRoundId = interview.InterviewRoundId,
                    UserId = interview.UserId,
                    InterviewStartDateTime = interview.InterviewStartDateTime,
                    InterviewEndDateTime = interview.InterviewEndDateTime,
                    ScheduledBy = interview.ScheduledBy,
                    ScheduleDate = DateTime.Now,
                    Interviewer = interview.Interviewer,
                    CommunicationChannel = interview.CommunicationChannel,
                    InterviewStatus = "New",
                    CommunicationNumber=null,
                    InterviewResult = null,
                    Feedback = interview.Feedback,
                    MeetingId="UID"
                };

                CreateSuccessModel result =await interviewService.UpsertInterview(scheduleInterview,interview.Topic,interview.Type,interview.Schedule_For,interview.Timezone,interview.Agenda);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateInterview", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a schedule Interview 
        /// </summary>
        /// <param name="up"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateInterview")]
        public async Task<ActionResult> UpdateInterview(UpdateScheduleInterview up)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateInterview", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(up) };
                logger.Info(log);
                if (up.ScheduleId == 0) { StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "ScheduleId is required" }); }
                ScheduleInterview scheduleInterview = new ScheduleInterview
                {
                    ScheduleId = up.ScheduleId,
                    InterviewStartDateTime = up.InterviewStartDateTime,
                    InterviewEndDateTime = up.InterviewEndDateTime,
                    CommunicationChannel = up.CommunicationChannel,
                    UserId = up.UserId,
                    Interviewer=up.Interviewer,
                    ScheduledBy=up.ScheduledBy,
                    InterviewRoundId=up.InterviewRoundId,
                    //CommunicationUrl = up.CommunicationUrl,
                    InterviewStatus = up.InterviewStatus,
                    InterviewResult = up.InterviewResult,
                    Feedback = up.Feedback
                };
                CreateSuccessModel result =await interviewService.UpsertInterview(scheduleInterview,up.Topic, up.Type,up.Schedule_For, up.Timezone, up.Agenda);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateInterview", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a shceduleInterviewById
        /// </summary>
        /// <param name="scheduleId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(VwGetScheduleInterview), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetScheduleInterviewById")]
        public async Task<ActionResult> GetScheduleInterviewById(int scheduleId)
        {
            try
            {
                if (scheduleId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "ScheduleId is rerquired" }); }
                VwGetScheduleInterview result =await interviewService.GetScheduleInterviewById(scheduleId);
                if (result != null)
                {
                    return Ok(result); 
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetScheduleInterviewById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a list of interview details
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(ScheduleInterviewList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetInterviewDetails")]
        public async Task<ActionResult> GetInterviewDetails(int count,int offset,string jobTitle,int jobDetailId,string userName,int interviewRoundId,int userId,int interviewerId,int scheduleBy,string interviewStartDateTime,string interviewEndDateTime,string schedulerName,string interviewerName,string interviewStatus,int roundOrder,string roundName,string interviewResult,string communicationChannel )
        {
            try
            {
                if (offset == 0 || offset == null) { offset = 0; }
                if (count == 0 || count == null) { count = 10; }
                ScheduleInterviewList result = await interviewService.GetInterviewDetails( count,  offset, jobTitle,jobDetailId,  userName,  interviewRoundId,  userId,  interviewerId,  scheduleBy,  interviewStartDateTime,  interviewEndDateTime,  schedulerName,  interviewerName,  interviewStatus,  roundOrder,  roundName,  interviewResult,  communicationChannel);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetInterviewDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

 // [Authorize(Roles = "2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateInterviewStatus")]
        public async Task<ActionResult> UpdateInterviewStatus(UpdateInterviewStatus up)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateInterviewStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(up) };
                logger.Info(log);
                if (up.ScheduleId == 0) { StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "ScheduleId is required" }); }
                ScheduleInterview scheduleInterview = new ScheduleInterview
                {
                    ScheduleId = up.ScheduleId,
                    InterviewStatus = up.InterviewStatus,
                    InterviewResult = up.InterviewResult,
                    Feedback = up.Feedback
                };
                CreateSuccessModel result = await interviewService.UpdateInterviewStatus(scheduleInterview,up.ScheduleId,up.InterviewStatus,up.InterviewResult,up.Feedback);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateInterview", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }



    }
}
