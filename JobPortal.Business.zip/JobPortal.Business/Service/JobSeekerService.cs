﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class JobSeekerService : IJobSeekerService
    {
        private JobPortalContext dbContext;
        public JobSeekerService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<CreateSuccessModel> SaveJobSeekerDetails(JobSeekerDetail jobSeekerDetail)
        {
            try
            {
                CreateSuccessModel result = null;
                int existingUserCount = await dbContext.JobSeekerDetails.Where(j => j.UserId == jobSeekerDetail.UserId).CountAsync();
                if (existingUserCount > 0)
                {
                    JobSeekerDetail existingJobSeeker = await dbContext.JobSeekerDetails.FirstOrDefaultAsync(j => j.UserId == jobSeekerDetail.UserId);
                    existingJobSeeker.WorkExperience = jobSeekerDetail.WorkExperience;
                    existingJobSeeker.ResumeUrl = jobSeekerDetail.ResumeUrl;
                    existingJobSeeker.ResumeHeading = jobSeekerDetail.ResumeHeading;
                    existingJobSeeker.CurrentCtc = jobSeekerDetail.CurrentCtc;
                    existingJobSeeker.ExpectedCtc = jobSeekerDetail.ExpectedCtc;
                    existingJobSeeker.CurrencyId = jobSeekerDetail.CurrencyId;
                    existingJobSeeker.NoticePeriod = jobSeekerDetail.NoticePeriod;
                    existingJobSeeker.Payslip = jobSeekerDetail.Payslip;
                    existingJobSeeker.DesignationId = jobSeekerDetail.DesignationId;
                    existingJobSeeker.PersonalInfo = jobSeekerDetail.PersonalInfo;
                    dbContext.Update(existingJobSeeker);
                    jobSeekerDetail.JobSeekerId = existingJobSeeker.JobSeekerId;
                }
                else
                {
                   await dbContext.JobSeekerDetails.AddAsync(jobSeekerDetail);
                }

                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = jobSeekerDetail.JobSeekerId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> SaveJobSeekerKeySkills(List<JobSeekerSkillList> jobSeekerKeySkills)
        {
            SuccessModel result = null;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var skills in jobSeekerKeySkills)
                    {
                        if (skills.SeekerKeySkill > 0)
                        {
                            JobSeekerKeySkill existingKeySkill = await dbContext.JobSeekerKeySkills.FirstOrDefaultAsync(k => k.SeekerKeySkill == skills.SeekerKeySkill);
                            existingKeySkill.UserId = skills.UserId;
                            existingKeySkill.KeySkillId = skills.KeySkillId;
                            existingKeySkill.Description = skills.Description;
                            existingKeySkill.WorkExperience = skills.WorkExperience;
                            existingKeySkill.IsDeleted = skills.IsDeleted;
                            dbContext.Update(existingKeySkill);

                            if (skills.IsDeleted == true)
                            {
                                JobSeekerKeySkill existingRemoveKeySkill = await dbContext.JobSeekerKeySkills.FirstOrDefaultAsync(k => k.SeekerKeySkill == skills.SeekerKeySkill && k.IsDeleted==true);
                                dbContext.Remove(existingKeySkill);

                            }
                             

                        }
                        else if(skills.IsDeleted==false)
                        {
                            await dbContext.JobSeekerKeySkills.AddAsync(new JobSeekerKeySkill
                            { 
                                UserId = skills.UserId,
                                KeySkillId = skills.KeySkillId,
                                Description = skills.Description,
                                WorkExperience = skills.WorkExperience,
                                IsDeleted=skills.IsDeleted
                            });
                        }
                    }
                    transaction.Commit();
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel
                    {
                        message = "Record saved successfully",
                        status = "Success"
                    };
                    return result;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }

        public async Task<SuccessModel> SaveJobSeekerEmploymentDetails(List<JobSeekerEmploymentList> jobSeekerEmploymentLists)
        {
            SuccessModel result = null;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var emp in jobSeekerEmploymentLists)
                    {
                        if (emp.EmployementDetailId > 0)
                        {
                            JobSeekerEmployementDetail existingemploymentDetail = await dbContext.JobSeekerEmployementDetails.FirstOrDefaultAsync (e => e.EmployementDetailId == emp.EmployementDetailId);
                            existingemploymentDetail.UserId = emp.UserId;
                            existingemploymentDetail.DesignationId = emp.DesignationId;
                            existingemploymentDetail.OrganizationName = emp.OrganizationName;
                            existingemploymentDetail.IsCurrentCompany = emp.IsCurrentCompany;
                            existingemploymentDetail.WorkingFrom = emp.WorkingFrom;
                            existingemploymentDetail.WorkingTo = emp.WorkingTo;
                            existingemploymentDetail.JobDescribtion = emp.JobDescribtion;
                            existingemploymentDetail.IsDeleted = emp.IsDeleted;
                            dbContext.Update(existingemploymentDetail);
                            await dbContext.SaveChangesAsync();
                            if (existingemploymentDetail.IsDeleted == true)
                            {
                                dbContext.Remove(existingemploymentDetail);
                            }
                        }
                        else if(emp.IsDeleted==false)
                        {
                            await dbContext.JobSeekerEmployementDetails.AddAsync(new JobSeekerEmployementDetail
                            {
                                UserId = emp.UserId,
                                OrganizationName = emp.OrganizationName,
                                DesignationId = emp.DesignationId,
                                IsCurrentCompany = emp.IsCurrentCompany,
                                WorkingFrom = emp.WorkingFrom,
                                WorkingTo = emp.WorkingTo,
                                JobDescribtion = emp.JobDescribtion,
                                IsDeleted=emp.IsDeleted
                            });
                           
                        }


                    }

                    transaction.Commit();
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel
                    {
                        message = "Record saved successfully",
                        status = "Success"
                    };
                    return result;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }
        public async Task<SuccessModel> DeleteSeekerEmploymentDetails(int employmentDetailId)
        {
            try
            {
                SuccessModel result = null;
                JobSeekerEmployementDetail existingEmploymentDetail = await dbContext.JobSeekerEmployementDetails.FirstOrDefaultAsync(e => e.EmployementDetailId == employmentDetailId);
                if (existingEmploymentDetail == null)
                {
                    result = new SuccessModel { status = "Error", message = "No record Found" };
                }
                else
                {
                    dbContext.JobSeekerEmployementDetails.Update(existingEmploymentDetail);
                    result = new SuccessModel { status = "Success", message = "Record Deleted Succesfully" };
                }
               await dbContext.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> SaveJobSeekerEducationDetails(List<JobSeekerEducationList> jobSeekerEducationLists)
        {
            SuccessModel result = null;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var education in jobSeekerEducationLists)
                    {
                        if (education.EducationDetailId > 0)
                        {
                            JobSeekerEducationDetail existingEducationDetail = await dbContext.JobSeekerEducationDetails.FirstOrDefaultAsync(e => e.EducationDetailId == education.EducationDetailId);
                            existingEducationDetail.UserId = education.UserId;
                            existingEducationDetail.Course = education.Course;
                            existingEducationDetail.Specialization = education.Specialization;
                            existingEducationDetail.Institute = education.Institute;
                            existingEducationDetail.YearOfPassing = education.YearOfPassing;
                            existingEducationDetail.Percentage = education.Percentage;
                            existingEducationDetail.IsDeleted = education.IsDeleted;
                            dbContext.Update(existingEducationDetail);
                            await  dbContext.SaveChangesAsync();
                            if (existingEducationDetail.IsDeleted == true)
                            {
                                dbContext.JobSeekerEducationDetails.Remove(existingEducationDetail);
                            }
                            
                          
                        }
                        else if(education.IsDeleted==false)
                        {
                            await dbContext.JobSeekerEducationDetails.AddAsync(new JobSeekerEducationDetail
                            {
                                UserId = education.UserId,
                                Course = education.Course,
                                Specialization = education.Specialization,
                                Institute = education.Institute,
                                YearOfPassing = education.YearOfPassing,
                                Percentage = education.Percentage,
                                IsDeleted=education.IsDeleted
                            });
                        }
                    }
                    transaction.Commit();
                    await dbContext.SaveChangesAsync();
                    return result = new SuccessModel
                    {
                        message = "Record Saved Successfully",
                        status = "Success"
                    };
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }
        public async Task<SuccessModel> DeleteSeekerEducationDetails(int educationDetailId)
        {
            try
            {
                SuccessModel result = null;
                JobSeekerEducationDetail existingEducationDetail =await dbContext.JobSeekerEducationDetails.FirstOrDefaultAsync(e => e.EducationDetailId == educationDetailId);
                if (existingEducationDetail == null)
                {
                    result = new SuccessModel { status = "Error", message = "No record found" };
                }
                else
                {
                    dbContext.JobSeekerEducationDetails.Remove(existingEducationDetail);
                    result = new SuccessModel { status = "Success", message = "Record deleted successfully" };
                }
                await dbContext.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> SaveJobSeekerProjectDetails(List<JobSeekerProjectList> jobSeekerProjectLists)
        {
            SuccessModel result = null;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var project in jobSeekerProjectLists)
                    {
                        if (project.ProjectDetailId > 0)
                        {
                            JobSeekerProjectDetail existingProjects =await dbContext.JobSeekerProjectDetails.FirstOrDefaultAsync(p => p.ProjectDetailId == project.ProjectDetailId);
                            existingProjects.UserId = project.UserId;
                            existingProjects.ProjectName = project.ProjectName;
                            existingProjects.ProjectDescription = project.ProjectDescription;
                            existingProjects.Duration = project.Duration;
                            existingProjects.YourRole = project.YourRole;
                            existingProjects.IsDeleted = project.IsDeleted;
                            dbContext.Update(existingProjects);
                            await dbContext.SaveChangesAsync();
                            if (existingProjects.IsDeleted == true)
                            {
                                dbContext.Remove(existingProjects);
                            }
                        }
                        else if(project.IsDeleted==false)
                        {
                            await dbContext.JobSeekerProjectDetails.AddAsync(new JobSeekerProjectDetail
                            {
                                UserId = project.UserId,
                                ProjectName = project.ProjectName,
                                ProjectDescription = project.ProjectDescription,
                                Duration = project.Duration,
                                YourRole = project.YourRole,
                                IsDeleted=project.IsDeleted
                            });
                        }
                    }
                    transaction.Commit();
                    await dbContext.SaveChangesAsync();
                    return result = new SuccessModel
                    {
                        status = "Success",
                        message = "Record Saved Succesfully"
                    };
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }
        public async Task<SuccessModel> DeleteSeekerProjectDetails(int projectDetailId)
        {
            try
            {
                SuccessModel result = null;
                JobSeekerProjectDetail existingProjectDetail = await dbContext.JobSeekerProjectDetails.FirstOrDefaultAsync(e => e.ProjectDetailId == projectDetailId);
                if (existingProjectDetail == null)
                {
                    result = new SuccessModel { status = "Error", message = "No record found" };
                }
                else
                {
                    dbContext.JobSeekerProjectDetails.Remove(existingProjectDetail);
                    result = new SuccessModel { status = "Success", message = "Record deleted successfully" };
                }
                await dbContext.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> SavePreferedLocations(List<int> cityId, int userId)
        {
            SuccessModel result = null;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    List<JobSeekerPreferredWorkLocation> jobSeekerPreferredWorkLocation = await dbContext.JobSeekerPreferredWorkLocations.Where(a => a.UserId == userId).ToListAsync();
                    dbContext.RemoveRange(jobSeekerPreferredWorkLocation);
                    foreach (var city in cityId)
                    {
                       await dbContext.JobSeekerPreferredWorkLocations.AddAsync(new JobSeekerPreferredWorkLocation { CityId = city, UserId = userId });
                       await dbContext.SaveChangesAsync();
                    }
                    transaction.Commit();
                    await dbContext.SaveChangesAsync();
                    return result = new SuccessModel
                    {
                        status = "Success",
                        message = "Record Saved Succesfully"
                    };
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }
        public async Task<CandidateList> GetCandidateDetails(int userId)
        {
            try
            {
                CandidateList candidateLists = new CandidateList();
                UserDataList user = await dbContext.VwUsers.Select(u => new UserDataList
                {
                    UserId = u.UserId,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    Address = u.Address,
                    CityId = u.CityId,
                    StateId = u.StateId,
                    CreatedDate = u.CreatedDate,
                    CreatedBy = u.CreatedBy,
                    RoleId = u.RoleId,
                    UserStatus = u.UserStatus,
                    Gender=u.Gender,
                    Dob = u.Dob,
                    PanNumber = u.PanNumber,
                    ProfileImage = u.ProfileImage,
                    CountryCode = u.CountryCode,
                    PhoneNumber = u.PhoneNumber,
                    CityName = u.CityName,
                    RoleName = u.RoleName,
                    CreatedName = u.CreatedName,
                    StateName = u.StateName
                }).FirstOrDefaultAsync(u => u.UserId == userId);
                JobSeekerList jobSeekerDetails = await (from a in dbContext.JobSeekerDetails 
                                                    join b in dbContext.Currencies on a.CurrencyId equals b.CurrencyId
                                                    join c in dbContext.Designations on a.DesignationId equals c.DesignationId

                    select  new JobSeekerList
                    {
                       JobSeekerId = a.JobSeekerId,
                        UserId = a.UserId,
                        WorkExperience = a.WorkExperience,
                        ResumeUrl = a.ResumeUrl,
                        ResumeHeading = a.ResumeHeading,
                        CurrencyId = a.CurrencyId,
                        CurrentCtc = a.CurrentCtc,
                        ExpectedCtc = a.ExpectedCtc,
                        NoticePeriod = a.NoticePeriod,
                        PersonalInfo = a.PersonalInfo,
                        Payslip = a.Payslip,
                        DesignationId = a.DesignationId,
                        CurrencyName=b.CurrencyName,
                        DesignationName=c.DesignationName
                        
                    }).
                    FirstOrDefaultAsync(j => j.UserId == userId);

                List<locationList> locationLists = await (from a in dbContext.JobSeekerPreferredWorkLocations
                                                    join b in dbContext.Cities on a.CityId equals b.CityId
                                                    where a.UserId == userId
                                                    select new locationList
                                                    {
                                                        cityId = a.CityId,
                                                        userId = a.UserId,
                                                        cityName = b.CityName
                                                    }).ToListAsync();

                List<JobSeekerSkillList> jobSeekerSkillLists = await (from a in dbContext.JobSeekerKeySkills
                                                                join b in dbContext.KeySkills on a.KeySkillId equals b.KeySkillId
                                                                where a.UserId == userId
                                                                select new JobSeekerSkillList
                                                                {
                                                                    SeekerKeySkill = a.SeekerKeySkill,
                                                                    UserId = a.UserId,
                                                                    KeySkillId = a.KeySkillId,
                                                                    KeySkillName=b.Name,
                                                                    Description = a.Description,
                                                                    WorkExperience = a.WorkExperience,
                                                                    name = b.Name,
                                                                    IsDeleted=a.IsDeleted
                                                                    
                                                                }).ToListAsync();

                List<JobSeekerEducationList> jobSeekerEducationList =await (from a in dbContext.JobSeekerEducationDetails
                                                                       where a.UserId == userId
                                                                       select new JobSeekerEducationList
                                                                       {
                                                                           UserId = a.UserId,
                                                                           EducationDetailId = a.EducationDetailId,
                                                                           Course = a.Course,
                                                                           Specialization = a.Specialization,
                                                                           Institute = a.Institute,
                                                                           YearOfPassing = a.YearOfPassing,
                                                                           Percentage = a.Percentage,
                                                                           IsDeleted=a.IsDeleted
                                                                       }).ToListAsync();

                List<JobSeekerProjectList> jobSeekerProjectList = await(from p in dbContext.JobSeekerProjectDetails
                                                                   where p.UserId == userId
                                                                   select new JobSeekerProjectList
                                                                   {
                                                                       ProjectDetailId = p.ProjectDetailId,
                                                                       ProjectName = p.ProjectName,
                                                                       ProjectDescription = p.ProjectDescription,
                                                                       Duration = p.Duration,
                                                                       YourRole = p.YourRole,
                                                                       UserId = p.UserId,
                                                                       IsDeleted=p.IsDeleted
                                                                       

                                                                   }).ToListAsync();

                List<JobSeekerEmploymentList> jobSeekerEmploymentList = await(from e in dbContext.JobSeekerEmployementDetails
                                                                              join d in dbContext.Designations on  e.DesignationId equals d.DesignationId
                                                                         where e.UserId == userId
                                                                         select new JobSeekerEmploymentList
                                                                         {
                                                                             EmployementDetailId = e.EmployementDetailId,
                                                                             UserId = e.UserId,
                                                                             OrganizationName = e.OrganizationName,
                                                                             DesignationId = e.DesignationId,
                                                                             DesignationName=d.DesignationName,
                                                                             IsCurrentCompany = e.IsCurrentCompany,
                                                                             WorkingFrom = e.WorkingFrom,
                                                                             WorkingTo = e.WorkingTo,
                                                                             JobDescribtion = e.JobDescribtion,
                                                                             IsDeleted=e.IsDeleted
                                                                         }).ToListAsync();

                candidateLists.userDataList = user;
                candidateLists.jobSeekerDetails = jobSeekerDetails;
                candidateLists.jobSeekerEducationLists = jobSeekerEducationList;
                candidateLists.jobSeekerEmploymentLists = jobSeekerEmploymentList;
                candidateLists.jobSeekerProjectLists = jobSeekerProjectList;
                candidateLists.jobSeekerPreferredWorkLocations = locationLists;
                candidateLists.jobSeekerSkillList = jobSeekerSkillLists;
                return candidateLists;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CreateSuccessModel> UpsertRecruitedDetails(RecruitedJobSeekerDetail recruitedJob)
        {
            try
            {
                CreateSuccessModel result;
                if (recruitedJob.RecruitedDetailId > 0)
                {
                    RecruitedJobSeekerDetail existingRecruitedDetails =await dbContext.RecruitedJobSeekerDetails.FirstOrDefaultAsync(r => r.RecruitedDetailId == recruitedJob.RecruitedDetailId);
                    existingRecruitedDetails.JobDetailId = recruitedJob.JobDetailId;
                    existingRecruitedDetails.UserId = recruitedJob.UserId;
                    existingRecruitedDetails.JoinDate = recruitedJob.JoinDate;
                    existingRecruitedDetails.AppoinmentCopy = recruitedJob.AppoinmentCopy;
                    existingRecruitedDetails.AppointedBy = recruitedJob.AppointedBy;
                    existingRecruitedDetails.SalaryPerMonth = recruitedJob.SalaryPerMonth;
                    existingRecruitedDetails.CurrencyId = recruitedJob.CurrencyId;
                    existingRecruitedDetails.Comments = recruitedJob.Comments;
                    existingRecruitedDetails.TermsandConditions = recruitedJob.TermsandConditions;
                    existingRecruitedDetails.JobSeekerStatus = recruitedJob.JobSeekerStatus;
                    existingRecruitedDetails.SelectedLocationId = recruitedJob.SelectedLocationId;
                    dbContext.Update(existingRecruitedDetails);
                    await dbContext.SaveChangesAsync();
                }
                else
                {
                    int existingRecruitedDetailsCount =await dbContext.RecruitedJobSeekerDetails.CountAsync(r =>r.UserId==recruitedJob.UserId && r.JobDetailId==recruitedJob.JobDetailId);
                    if (existingRecruitedDetailsCount>0)
                    {
                        return new CreateSuccessModel { Id = (int)recruitedJob.UserId, Status = "Error", message = "You alredy offered this job" };
                    }
                    await dbContext.RecruitedJobSeekerDetails.AddAsync(recruitedJob);
                    await dbContext.SaveChangesAsync();
                }
                result = new CreateSuccessModel
                {
                    Id = recruitedJob.RecruitedDetailId,
                    Status = "Success",
                    message = "Record Saved Successfully"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<RecruitedJobSeekerList> GetRecruitedJobSeekerDetailsById(int recruitedDetailId)
        {
            try
            {
                RecruitedJobSeekerList result = await dbContext.RecruitedJobSeekerDetails.Select(r => new RecruitedJobSeekerList
                {
                    RecruitedDetailId = r.RecruitedDetailId,
                    UserId = r.UserId,
                    JobDetailId = r.JobDetailId,
                    AppoinmentCopy = r.AppoinmentCopy,
                    SelectedDate = r.SelectedDate,
                    AppointedBy = r.AppointedBy,
                    CurrencyId = r.CurrencyId,
                    JobSeekerStatus = r.JobSeekerStatus,
                    SalaryPerMonth = r.SalaryPerMonth,
                    JoinDate = r.JoinDate,
                    Comments = r.Comments,
                    TermsandConditions = r.TermsandConditions,
                    SelectedLocationId = r.SelectedLocationId,
                    IsDeleted = r.IsDeleted
                }).FirstOrDefaultAsync(r => r.RecruitedDetailId == recruitedDetailId && r.IsDeleted == false);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> DeleteRecruitedJobSeekerDetails(int recruitedDetailId)
        {
            try
            {
                SuccessModel result;
                RecruitedJobSeekerDetail existingRecruitedDetail =await dbContext.RecruitedJobSeekerDetails
                    .FirstOrDefaultAsync(r => r.RecruitedDetailId == recruitedDetailId && r.IsDeleted == false);
                if (existingRecruitedDetail != null)
                {
                    existingRecruitedDetail.IsDeleted = true;
                    result = new SuccessModel
                    {
                        status = "Success",
                        message = "Record Deleted Succesfully"
                    };
                }
                else
                {
                    result = new SuccessModel
                    {
                        status = "Error",
                        message = "No record Found"
                    };
                }
                await dbContext.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> UpdateRecruitedDetailStatus(int RecruitedDetailId, string JobSeekerStatus, string Comments)
        {
            try
            {
                SuccessModel result;
                RecruitedJobSeekerDetail existingRecruitedJobSeekerDetail = dbContext.RecruitedJobSeekerDetails.FirstOrDefault(c => c.RecruitedDetailId == RecruitedDetailId);
                if (existingRecruitedJobSeekerDetail != null)
                {
                    existingRecruitedJobSeekerDetail.JobSeekerStatus = JobSeekerStatus;
                    existingRecruitedJobSeekerDetail.Comments = Comments;
                    dbContext.Update(existingRecruitedJobSeekerDetail);
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel
                    {
                        message = "Record Saved Successfully",
                        status = "Success"
                    };
                    return result;
                }
                else
                {
                    result = new SuccessModel
                    {
                        message = "No record found",
                        status = "Error"
                    };
                    return result;
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetSignupStepStatus> GetSignupStepStatus(int userId)
        {
            try
            {
                GetSignupStepStatus getSignupStepStatus = new GetSignupStepStatus();
                getSignupStepStatus.ProfileInfo  = await dbContext.JobSeekerPreferredWorkLocations.CountAsync(a => a.UserId == userId)>0 &&
                                                   await dbContext.JobSeekerKeySkills.CountAsync(a => a.UserId == userId) > 0;
                getSignupStepStatus.EmployementInfo = await dbContext.JobSeekerEmployementDetails.CountAsync(a => a.UserId == userId) > 0;
                getSignupStepStatus.EducationInfo = await dbContext.JobSeekerEducationDetails.CountAsync(a => a.UserId == userId) > 0;
                getSignupStepStatus.ProjectInfo = await dbContext.JobSeekerProjectDetails.CountAsync(a => a.UserId == userId) > 0;
                getSignupStepStatus.JobInfo = await dbContext.JobSeekerDetails.CountAsync(a => a.UserId == userId) > 0;

                return getSignupStepStatus;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
