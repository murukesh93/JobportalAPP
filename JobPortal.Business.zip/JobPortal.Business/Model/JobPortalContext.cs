﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobPortalContext : DbContext
    {
        public JobPortalContext()
        {
        }

        public JobPortalContext(DbContextOptions<JobPortalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<CompanyCategory> CompanyCategories { get; set; }
        public virtual DbSet<CompanyDetail> CompanyDetails { get; set; }
        public virtual DbSet<CompanyUser> CompanyUsers { get; set; }
        public virtual DbSet<Currency> Currencies { get; set; }
        public virtual DbSet<Designation> Designations { get; set; }
        public virtual DbSet<JobDetail> JobDetails { get; set; }
        public virtual DbSet<JobInterviewRound> JobInterviewRounds { get; set; }
        public virtual DbSet<JobKeySkill> JobKeySkills { get; set; }
        public virtual DbSet<JobLocation> JobLocations { get; set; }
        public virtual DbSet<JobPreliminaryQuestion> JobPreliminaryQuestions { get; set; }
        public virtual DbSet<JobSeekerDetail> JobSeekerDetails { get; set; }
        public virtual DbSet<JobSeekerEducationDetail> JobSeekerEducationDetails { get; set; }
        public virtual DbSet<JobSeekerEmployementDetail> JobSeekerEmployementDetails { get; set; }
        public virtual DbSet<JobSeekerKeySkill> JobSeekerKeySkills { get; set; }
        public virtual DbSet<JobSeekerPreferredWorkLocation> JobSeekerPreferredWorkLocations { get; set; }
        public virtual DbSet<JobSeekerProjectDetail> JobSeekerProjectDetails { get; set; }
        public virtual DbSet<KeySkill> KeySkills { get; set; }
        public virtual DbSet<KeySkillCategory> KeySkillCategories { get; set; }
        public virtual DbSet<LoginProvider> LoginProviders { get; set; }
        public virtual DbSet<Otpvalue> Otpvalues { get; set; }
        public virtual DbSet<PkTest> PkTests { get; set; }
        public virtual DbSet<PreliminaryQuestionAnswer> PreliminaryQuestionAnswers { get; set; }
        public virtual DbSet<PreliminaryRoundDetail> PreliminaryRoundDetails { get; set; }
        public virtual DbSet<RecruitedJobSeekerDetail> RecruitedJobSeekerDetails { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<ScheduleInterview> ScheduleInterviews { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<VwCompanyDetail> VwCompanyDetails { get; set; }
        public virtual DbSet<VwGetAppliedUser> VwGetAppliedUsers { get; set; }
        public virtual DbSet<VwGetCalendorView> VwGetCalendorViews { get; set; }
        public virtual DbSet<VwGetCandidateBySkillSet> VwGetCandidateBySkillSets { get; set; }
        public virtual DbSet<VwGetJobDetail> VwGetJobDetails { get; set; }
        public virtual DbSet<VwGetJobInterviewRound> VwGetJobInterviewRounds { get; set; }
        public virtual DbSet<VwGetRoundStatus> VwGetRoundStatuses { get; set; }
        public virtual DbSet<VwGetScheduleInterview> VwGetScheduleInterviews { get; set; }
        public virtual DbSet<VwGetSearchJob> VwGetSearchJobs { get; set; }
        public virtual DbSet<VwUser> VwUsers { get; set; }
        public virtual DbSet<VwgetRecruitedDetail> VwgetRecruitedDetails { get; set; }
        public virtual DbSet<VwpreliminaryRound> VwpreliminaryRounds { get; set; }
        public virtual DbSet<ZoomMeeting> ZoomMeetings { get; set; }
        public virtual DbSet<ZoomMeetingParticipant> ZoomMeetingParticipants { get; set; }
        public virtual DbSet<ZoomTimeZone> ZoomTimeZones { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=jobportalapp.database.windows.net,1433;Initial Catalog=devjobportal;Persist Security Info=False;User ID=portaladmin;Password=Borntowin$123!#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("City");

                entity.HasIndex(e => new { e.CityName, e.StateId }, "UQ__City__A48ED64FA43B3B4D")
                    .IsUnique();

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.StateId).HasColumnName("stateId");
            });

            modelBuilder.Entity<CompanyCategory>(entity =>
            {
                entity.ToTable("companyCategory");

                entity.Property(e => e.CompanyCategoryId).HasColumnName("companyCategoryId");

                entity.Property(e => e.CategoryId).HasColumnName("categoryId");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.CompanyCategories)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("FK__companyCa__categ__625A9A57");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.CompanyCategories)
                    .HasForeignKey(d => d.CompanyId)
                    .HasConstraintName("FK__companyCa__compa__6166761E");
            });

            modelBuilder.Entity<CompanyDetail>(entity =>
            {
                entity.HasKey(e => e.CompanyId)
                    .HasName("PK__CompanyD__AD545990233B5260");

                entity.ToTable("CompanyDetail");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CompanyLogo)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companyLogo");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CompanySiteUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companySiteUrl");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phoneNumber");

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.CompanyDetails)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("FK__CompanyDe__creat__778AC167");
            });

            modelBuilder.Entity<CompanyUser>(entity =>
            {
                entity.Property(e => e.CompanyUserId).HasColumnName("companyUserId");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.CompanyUsers)
                    .HasForeignKey(d => d.CompanyId)
                    .HasConstraintName("FK__CompanyUs__compa__07C12930");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.CompanyUsers)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__CompanyUs__userI__06CD04F7");
            });

            modelBuilder.Entity<Currency>(entity =>
            {
                entity.ToTable("Currency");

                entity.HasIndex(e => e.CurrencyName, "UQ__Currency__FE869A395D2ED866")
                    .IsUnique();

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrencyCode)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("currencyCode");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("currencyName");
            });

            modelBuilder.Entity<Designation>(entity =>
            {
                entity.ToTable("Designation");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");
            });

            modelBuilder.Entity<JobDetail>(entity =>
            {
                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.JobDetails)
                    .HasForeignKey(d => d.CompanyId)
                    .HasConstraintName("FK__JobDetail__compa__671F4F74");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.JobDetails)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("FK__JobDetail__creat__0A9D95DB");

                entity.HasOne(d => d.Currency)
                    .WithMany(p => p.JobDetails)
                    .HasForeignKey(d => d.CurrencyId)
                    .HasConstraintName("FK__JobDetail__curre__0C85DE4D");

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.JobDetails)
                    .HasForeignKey(d => d.DesignationId)
                    .HasConstraintName("FK__JobDetail__desig__0B91BA14");
            });

            modelBuilder.Entity<JobInterviewRound>(entity =>
            {
                entity.HasKey(e => e.InterviewRoundId)
                    .HasName("PK__JobInter__8F5D8F0C572955F1");

                entity.Property(e => e.InterviewRoundId).HasColumnName("interviewRoundId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.RoundDescription)
                    .IsUnicode(false)
                    .HasColumnName("roundDescription");

                entity.Property(e => e.RoundName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roundName");

                entity.Property(e => e.RoundOrder).HasColumnName("roundOrder");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.JobInterviewRounds)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__JobInterv__jobDe__2EDAF651");
            });

            modelBuilder.Entity<JobKeySkill>(entity =>
            {
                entity.Property(e => e.JobKeySkillId).HasColumnName("jobKeySkillId");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.KeySkillId).HasColumnName("keySkillId");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.JobKeySkills)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__JobKeySki__jobDe__5D95E53A");

                entity.HasOne(d => d.KeySkill)
                    .WithMany(p => p.JobKeySkills)
                    .HasForeignKey(d => d.KeySkillId)
                    .HasConstraintName("FK__JobKeySki__keySk__5E8A0973");
            });

            modelBuilder.Entity<JobLocation>(entity =>
            {
                entity.Property(e => e.JobLocationId).HasColumnName("jobLocationId");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.JobLocations)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK__JobLocati__cityI__5BAD9CC8");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.JobLocations)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__JobLocati__jobDe__5AB9788F");
            });

            modelBuilder.Entity<JobPreliminaryQuestion>(entity =>
            {
                entity.HasKey(e => e.QuestionId)
                    .HasName("PK__JobPreli__6238D4B213065E15");

                entity.Property(e => e.QuestionId).HasColumnName("questionId");

                entity.Property(e => e.Answer)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("answer");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.QuestionDescription)
                    .IsUnicode(false)
                    .HasColumnName("questionDescription");

                entity.Property(e => e.QuestionLable)
                    .HasMaxLength(2000)
                    .HasColumnName("questionLable");

                entity.Property(e => e.QuestionOptions)
                    .IsUnicode(false)
                    .HasColumnName("questionOptions");

                entity.Property(e => e.QuestionType)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("questionType");

                entity.Property(e => e.SortOrder).HasColumnName("sortOrder");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.JobPreliminaryQuestions)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__JobPrelim__jobDe__18EBB532");
            });

            modelBuilder.Entity<JobSeekerDetail>(entity =>
            {
                entity.HasKey(e => e.JobSeekerId)
                    .HasName("PK__JobSeeke__6998C744CFDE9CAD");

                entity.ToTable("JobSeekerDetail");

                entity.Property(e => e.JobSeekerId).HasColumnName("jobSeekerId");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrentCtc)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("currentCTC");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.ExpectedCtc)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("expectedCTC");

                entity.Property(e => e.NoticePeriod).HasColumnName("noticePeriod");

                entity.Property(e => e.Payslip)
                    .IsUnicode(false)
                    .HasColumnName("payslip");

                entity.Property(e => e.PersonalInfo)
                    .IsUnicode(false)
                    .HasColumnName("personalInfo");

                entity.Property(e => e.ResumeHeading)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("resumeHeading");

                entity.Property(e => e.ResumeUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("resumeUrl");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.WorkExperience)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("workExperience");

                entity.HasOne(d => d.Currency)
                    .WithMany(p => p.JobSeekerDetails)
                    .HasForeignKey(d => d.CurrencyId)
                    .HasConstraintName("FK__JobSeeker__curre__3D2915A8");

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.JobSeekerDetails)
                    .HasForeignKey(d => d.DesignationId)
                    .HasConstraintName("FK__JobSeeker__desig__3E1D39E1");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerDetails)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__3C34F16F");
            });

            modelBuilder.Entity<JobSeekerEducationDetail>(entity =>
            {
                entity.HasKey(e => e.EducationDetailId)
                    .HasName("PK__JobSeeke__A6130362CC8E61ED");

                entity.Property(e => e.EducationDetailId).HasColumnName("educationDetailId");

                entity.Property(e => e.Course)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("course");

                entity.Property(e => e.Institute)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("institute");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.Percentage)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("percentage");

                entity.Property(e => e.Specialization)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("specialization");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.YearOfPassing).HasColumnName("yearOfPassing");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerEducationDetails)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__489AC854");
            });

            modelBuilder.Entity<JobSeekerEmployementDetail>(entity =>
            {
                entity.HasKey(e => e.EmployementDetailId)
                    .HasName("PK__JobSeeke__0C4646FA48124361");

                entity.Property(e => e.EmployementDetailId).HasColumnName("employementDetailId");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.IsCurrentCompany).HasColumnName("isCurrentCompany");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.JobDescribtion)
                    .IsUnicode(false)
                    .HasColumnName("jobDescribtion");

                entity.Property(e => e.OrganizationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("organizationName");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.WorkingFrom)
                    .HasColumnType("date")
                    .HasColumnName("workingFrom");

                entity.Property(e => e.WorkingTo)
                    .HasColumnType("date")
                    .HasColumnName("workingTo");

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.JobSeekerEmployementDetails)
                    .HasForeignKey(d => d.DesignationId)
                    .HasConstraintName("FK__JobSeeker__desig__45BE5BA9");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerEmployementDetails)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__44CA3770");
            });

            modelBuilder.Entity<JobSeekerKeySkill>(entity =>
            {
                entity.HasKey(e => e.SeekerKeySkill)
                    .HasName("PK__JobSeeke__14CCD8E4A21D8CE6");

                entity.Property(e => e.SeekerKeySkill).HasColumnName("seekerKeySkill");

                entity.Property(e => e.Description)
                    .IsUnicode(false)
                    .HasColumnName("description");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.KeySkillId).HasColumnName("keySkillId");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.WorkExperience)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("workExperience");

                entity.HasOne(d => d.KeySkill)
                    .WithMany(p => p.JobSeekerKeySkills)
                    .HasForeignKey(d => d.KeySkillId)
                    .HasConstraintName("FK__JobSeeker__keySk__41EDCAC5");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerKeySkills)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__40F9A68C");
            });

            modelBuilder.Entity<JobSeekerPreferredWorkLocation>(entity =>
            {
                entity.HasKey(e => e.WorkLocationId)
                    .HasName("PK__JobSeeke__B3F55D1069465DA2");

                entity.ToTable("JobSeekerPreferredWorkLocation");

                entity.Property(e => e.WorkLocationId).HasColumnName("workLocationId");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.JobSeekerPreferredWorkLocations)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK__JobSeeker__cityI__4E53A1AA");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerPreferredWorkLocations)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__4D5F7D71");
            });

            modelBuilder.Entity<JobSeekerProjectDetail>(entity =>
            {
                entity.HasKey(e => e.ProjectDetailId)
                    .HasName("PK__JobSeeke__7A64795B1101DDF2");

                entity.Property(e => e.ProjectDetailId).HasColumnName("projectDetailId");

                entity.Property(e => e.Duration)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("duration");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.ProjectDescription)
                    .IsUnicode(false)
                    .HasColumnName("projectDescription");

                entity.Property(e => e.ProjectName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("projectName");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.YourRole)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("yourRole");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.JobSeekerProjectDetails)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__JobSeeker__userI__4B7734FF");
            });

            modelBuilder.Entity<KeySkill>(entity =>
            {
                entity.ToTable("KeySkill");

                entity.HasIndex(e => e.Name, "UQ__KeySkill__72E12F1B4174F656")
                    .IsUnique();

                entity.Property(e => e.KeySkillId).HasColumnName("keySkillId");

                entity.Property(e => e.CategoryId).HasColumnName("categoryId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.KeySkills)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("FK__KeySkill__catego__00200768");
            });

            modelBuilder.Entity<KeySkillCategory>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("PK__KeySkill__23CAF1D81B5B7900");

                entity.ToTable("KeySkillCategory");

                entity.HasIndex(e => e.CategoryName, "UQ__KeySkill__37077ABD0C57DCF2")
                    .IsUnique();

                entity.Property(e => e.CategoryId).HasColumnName("categoryId");

                entity.Property(e => e.CategoryName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("categoryName");

                entity.Property(e => e.IsActive).HasColumnName("isActive");
            });

            modelBuilder.Entity<LoginProvider>(entity =>
            {
                entity.ToTable("LoginProvider");

                entity.Property(e => e.LoginProviderId).HasColumnName("loginProviderId");

                entity.Property(e => e.LoginProviderKey)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("loginProviderKey");

                entity.Property(e => e.LoginProviderType)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("loginProviderType");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.LoginProviders)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__LoginProv__userI__5224328E");
            });

            modelBuilder.Entity<Otpvalue>(entity =>
            {
                entity.HasKey(e => e.OtpId)
                    .HasName("PK__OTPValue__122D946A8D32EC7A");

                entity.ToTable("OTPValue");

                entity.Property(e => e.OtpId).HasColumnName("otpId");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.OtpText)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("otpText");

                entity.Property(e => e.OtpType)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("otpType");

                entity.Property(e => e.Source)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("source");

                entity.Property(e => e.Status)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("status");
            });

            modelBuilder.Entity<PkTest>(entity =>
            {
                entity.ToTable("pkTest");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<PreliminaryQuestionAnswer>(entity =>
            {
                entity.HasKey(e => e.AnswerId)
                    .HasName("PK__Prelimin__6836B974F5542CA3");

                entity.Property(e => e.AnswerId).HasColumnName("answerId");

                entity.Property(e => e.QuestionId).HasColumnName("questionId");

                entity.Property(e => e.UserAnswer)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("userAnswer");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.PreliminaryQuestionAnswers)
                    .HasForeignKey(d => d.QuestionId)
                    .HasConstraintName("FK__Prelimina__quest__2180FB33");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.PreliminaryQuestionAnswers)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Prelimina__userI__208CD6FA");
            });

            modelBuilder.Entity<PreliminaryRoundDetail>(entity =>
            {
                entity.HasKey(e => e.RoundDetailId)
                    .HasName("PK__Prelimin__81ABF50ABDAAAD84");

                entity.ToTable("PreliminaryRoundDetail");

                entity.Property(e => e.RoundDetailId).HasColumnName("roundDetailId");

                entity.Property(e => e.ActionBy).HasColumnName("actionBy");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.RoundStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("roundStatus");

                entity.Property(e => e.SubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("submitDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.ActionByNavigation)
                    .WithMany(p => p.PreliminaryRoundDetailActionByNavigations)
                    .HasForeignKey(d => d.ActionBy)
                    .HasConstraintName("FK__Prelimina__actio__29221CFB");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.PreliminaryRoundDetails)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__Prelimina__jobDe__2739D489");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.PreliminaryRoundDetailUsers)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Prelimina__userI__282DF8C2");
            });

            modelBuilder.Entity<RecruitedJobSeekerDetail>(entity =>
            {
                entity.HasKey(e => e.RecruitedDetailId)
                    .HasName("PK__Recruite__39D3DED645B2387E");

                entity.Property(e => e.RecruitedDetailId).HasColumnName("recruitedDetailId");

                entity.Property(e => e.AppoinmentCopy)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("appoinmentCopy");

                entity.Property(e => e.AppointedBy).HasColumnName("appointedBy");

                entity.Property(e => e.Comments)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobSeekerStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("jobSeekerStatus");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("joinDate");

                entity.Property(e => e.SalaryPerMonth)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryPerMonth");

                entity.Property(e => e.SelectedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("selectedDate");

                entity.Property(e => e.SelectedLocationId).HasColumnName("selectedLocationId");

                entity.Property(e => e.TermsandConditions)
                    .IsUnicode(false)
                    .HasColumnName("termsandConditions");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.AppointedByNavigation)
                    .WithMany(p => p.RecruitedJobSeekerDetailAppointedByNavigations)
                    .HasForeignKey(d => d.AppointedBy)
                    .HasConstraintName("FK__Recruited__appoi__56E8E7AB");

                entity.HasOne(d => d.Currency)
                    .WithMany(p => p.RecruitedJobSeekerDetails)
                    .HasForeignKey(d => d.CurrencyId)
                    .HasConstraintName("FK__Recruited__curre__57DD0BE4");

                entity.HasOne(d => d.JobDetail)
                    .WithMany(p => p.RecruitedJobSeekerDetails)
                    .HasForeignKey(d => d.JobDetailId)
                    .HasConstraintName("FK__Recruited__jobDe__55009F39");

                entity.HasOne(d => d.SelectedLocation)
                    .WithMany(p => p.RecruitedJobSeekerDetails)
                    .HasForeignKey(d => d.SelectedLocationId)
                    .HasConstraintName("FK__Recruited__selec__11158940");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.RecruitedJobSeekerDetailUsers)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Recruited__userI__55F4C372");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");

                entity.HasIndex(e => e.RoleName, "UQ__Role__B1947861FED68967")
                    .IsUnique();

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roleName");
            });

            modelBuilder.Entity<ScheduleInterview>(entity =>
            {
                entity.HasKey(e => e.ScheduleId)
                    .HasName("PK__Schedule__A532EDD460E2DB8C");

                entity.ToTable("ScheduleInterview");

                entity.Property(e => e.ScheduleId).HasColumnName("scheduleId");

                entity.Property(e => e.CommunicationChannel)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("communicationChannel");

                entity.Property(e => e.CommunicationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("communicationNumber");

                entity.Property(e => e.Feedback)
                    .IsUnicode(false)
                    .HasColumnName("feedback");

                entity.Property(e => e.InterviewEndDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewEndDateTime");

                entity.Property(e => e.InterviewResult)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("interviewResult");

                entity.Property(e => e.InterviewRoundId).HasColumnName("interviewRoundId");

                entity.Property(e => e.InterviewStartDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewStartDateTime");

                entity.Property(e => e.InterviewStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("interviewStatus");

                entity.Property(e => e.Interviewer).HasColumnName("interviewer");

                entity.Property(e => e.MeetingId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("meetingId");

                entity.Property(e => e.ScheduleDate)
                    .HasColumnType("datetime")
                    .HasColumnName("scheduleDate");

                entity.Property(e => e.ScheduledBy).HasColumnName("scheduledBy");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.InterviewRound)
                    .WithMany(p => p.ScheduleInterviews)
                    .HasForeignKey(d => d.InterviewRoundId)
                    .HasConstraintName("FK__ScheduleI__inter__3493CFA7");

                entity.HasOne(d => d.InterviewerNavigation)
                    .WithMany(p => p.ScheduleInterviewInterviewerNavigations)
                    .HasForeignKey(d => d.Interviewer)
                    .HasConstraintName("FK__ScheduleI__inter__37703C52");

                entity.HasOne(d => d.ScheduledByNavigation)
                    .WithMany(p => p.ScheduleInterviewScheduledByNavigations)
                    .HasForeignKey(d => d.ScheduledBy)
                    .HasConstraintName("FK__ScheduleI__sched__367C1819");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.ScheduleInterviewUsers)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__ScheduleI__userI__3587F3E0");
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.ToTable("State");

                entity.HasIndex(e => e.StateName, "UQ__State__8B97A960E6254491")
                    .IsUnique();

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.StateName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("stateName");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("countryCode");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("dob");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("firstName");

                entity.Property(e => e.Gender)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("gender");

                entity.Property(e => e.IsDeleted)
                    .HasColumnName("isDeleted")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lastName");

                entity.Property(e => e.PanNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("panNumber");

                entity.Property(e => e.Password)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("phoneNumber");

                entity.Property(e => e.ProfileImage)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("profileImage");

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.Property(e => e.StatusComment)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("statusComment");

                entity.Property(e => e.UserStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userStatus");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK__User__cityId__693CA210");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__User__roleId__68487DD7");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.StateId)
                    .HasConstraintName("FK__User__stateId__6A30C649");
            });

            modelBuilder.Entity<VwCompanyDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwCompanyDetails");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.CompanyCategory).HasColumnName("companyCategory");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyLogo)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companyLogo");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CompanySiteUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companySiteUrl");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("phoneNumber");

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.Property(e => e.StateName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("stateName");
            });

            modelBuilder.Entity<VwGetAppliedUser>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetAppliedUsers");

                entity.Property(e => e.ActionBy).HasColumnName("actionBy");

                entity.Property(e => e.ActionerName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("actionerName");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyLogo)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companyLogo");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CompanySiteUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companySiteUrl");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("currencyName");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.KeySkills).HasColumnName("keySkills");

                entity.Property(e => e.Locations).HasColumnName("locations");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.RoundDetailId).HasColumnName("roundDetailId");

                entity.Property(e => e.RoundStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("roundStatus");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.Property(e => e.SubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("submitDate");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("userName");
            });

            modelBuilder.Entity<VwGetCalendorView>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetCalendorView");

                entity.Property(e => e.CommunicationChannel)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("communicationChannel");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.Feedback)
                    .IsUnicode(false)
                    .HasColumnName("feedback");

                entity.Property(e => e.InterviewEndDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewEndDateTime");

                entity.Property(e => e.InterviewResult)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("interviewResult");

                entity.Property(e => e.InterviewRoundId).HasColumnName("interviewRoundId");

                entity.Property(e => e.InterviewStartDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewStartDateTime");

                entity.Property(e => e.InterviewStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("interviewStatus");

                entity.Property(e => e.Interviewer).HasColumnName("interviewer");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.MeetingId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("meetingId");

                entity.Property(e => e.MeetingStatus)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("meetingStatus");

                entity.Property(e => e.MeetingUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("meetingUrl");

                entity.Property(e => e.RoundName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roundName");

                entity.Property(e => e.ScheduleDate)
                    .HasColumnType("datetime")
                    .HasColumnName("scheduleDate");

                entity.Property(e => e.ScheduleId).HasColumnName("scheduleId");

                entity.Property(e => e.ScheduledBy).HasColumnName("scheduledBy");

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<VwGetCandidateBySkillSet>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetCandidateBySkillSet");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("currencyName");

                entity.Property(e => e.CurrentCtc)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("currentCTC");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.EducationDetails).HasColumnName("educationDetails");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.EmployementDetails).HasColumnName("employementDetails");

                entity.Property(e => e.ExpectedCtc)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("expectedCTC");

                entity.Property(e => e.Gender)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("gender");

                entity.Property(e => e.JobSeekerId).HasColumnName("jobSeekerId");

                entity.Property(e => e.KeySkills).HasColumnName("keySkills");

                entity.Property(e => e.NoticePeriod).HasColumnName("noticePeriod");

                entity.Property(e => e.Payslip)
                    .IsUnicode(false)
                    .HasColumnName("payslip");

                entity.Property(e => e.PersonalInfo)
                    .IsUnicode(false)
                    .HasColumnName("personalInfo");

                entity.Property(e => e.PreferedLocations).HasColumnName("preferedLocations");

                entity.Property(e => e.ProjectDetails).HasColumnName("projectDetails");

                entity.Property(e => e.ResumeHeading)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("resumeHeading");

                entity.Property(e => e.ResumeUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("resumeUrl");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("userName");

                entity.Property(e => e.UserStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userStatus");

                entity.Property(e => e.WorkExperience)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("workExperience");
            });

            modelBuilder.Entity<VwGetJobDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetJobDetails");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("currencyName");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobLocations).HasColumnName("jobLocations");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.KeySkills).HasColumnName("keySkills");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");
            });

            modelBuilder.Entity<VwGetJobInterviewRound>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetJobInterviewRounds");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.InterviewRoundId).HasColumnName("interviewRoundId");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobLocations).HasColumnName("jobLocations");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.KeySkills).HasColumnName("keySkills");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.RoundDescription)
                    .IsUnicode(false)
                    .HasColumnName("roundDescription");

                entity.Property(e => e.RoundName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roundName");

                entity.Property(e => e.RoundOrder).HasColumnName("roundOrder");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");
            });

            modelBuilder.Entity<VwGetRoundStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetRoundStatus");

                entity.Property(e => e.ActionBy).HasColumnName("actionBy");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.NumberOfresources).HasColumnName("numberOfresources");

                entity.Property(e => e.RoundDetailId).HasColumnName("roundDetailId");

                entity.Property(e => e.RoundStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("roundStatus");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.Property(e => e.SubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("submitDate");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("userName");
            });

            modelBuilder.Entity<VwGetScheduleInterview>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetScheduleInterview");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.CommunicationChannel)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("communicationChannel");

                entity.Property(e => e.CommunicationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("communicationNumber");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.Feedback)
                    .IsUnicode(false)
                    .HasColumnName("feedback");

                entity.Property(e => e.InterviewEndDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewEndDateTime");

                entity.Property(e => e.InterviewResult)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("interviewResult");

                entity.Property(e => e.InterviewRoundId).HasColumnName("interviewRoundId");

                entity.Property(e => e.InterviewStartDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("interviewStartDateTime");

                entity.Property(e => e.InterviewStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("interviewStatus");

                entity.Property(e => e.Interviewer).HasColumnName("interviewer");

                entity.Property(e => e.InterviewerName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("interviewerName");

                entity.Property(e => e.IsSelected).HasColumnName("isSelected");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.MeetingId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("meetingId");

                entity.Property(e => e.MeetingStatus)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("meetingStatus");

                entity.Property(e => e.MeetingUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("meetingUrl");

                entity.Property(e => e.RoundDescription)
                    .IsUnicode(false)
                    .HasColumnName("roundDescription");

                entity.Property(e => e.RoundName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roundName");

                entity.Property(e => e.RoundOrder).HasColumnName("roundOrder");

                entity.Property(e => e.ScheduleId).HasColumnName("scheduleId");

                entity.Property(e => e.ScheduledBy).HasColumnName("scheduledBy");

                entity.Property(e => e.SchedulerName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("schedulerName");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("userName");

                entity.Property(e => e.ZoomMeetingId).HasColumnName("zoomMeetingId");
            });

            modelBuilder.Entity<VwGetSearchJob>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VwGetSearchJobs");

                entity.Property(e => e.Companyid).HasColumnName("companyid");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.CurrencyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("currencyName");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.Property(e => e.SearchLocations).HasColumnName("searchLocations");

                entity.Property(e => e.SearchSkills).HasColumnName("searchSkills");
            });

            modelBuilder.Entity<VwUser>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vwUser");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyLogo)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companyLogo");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("countryCode");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.CreatedName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("createdName");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("dob");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("firstName");

                entity.Property(e => e.Gender)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("gender");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lastName");

                entity.Property(e => e.PanNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("panNumber");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("phoneNumber");

                entity.Property(e => e.ProfileImage)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("profileImage");

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("roleName");

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.Property(e => e.StateName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("stateName");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userStatus");
            });

            modelBuilder.Entity<VwgetRecruitedDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VWGetRecruitedDetails");

                entity.Property(e => e.AppoinmentCopy)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("appoinmentCopy");

                entity.Property(e => e.AppointedBy).HasColumnName("appointedBy");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.Comments)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.CompanyAddress)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("companyAddress");

                entity.Property(e => e.CompanyCreateby).HasColumnName("companyCreateby");

                entity.Property(e => e.CompanyEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("companyEmail");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyLogo)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companyLogo");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CompanyPhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("companyPhoneNumber");

                entity.Property(e => e.CompanySiteUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("companySiteUrl");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.DesignationName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designationName");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("dob");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobSeekerStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("jobSeekerStatus");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.JoinDate)
                    .HasColumnType("datetime")
                    .HasColumnName("joinDate");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.PanNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("panNumber");

                entity.Property(e => e.ProfileImage)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("profileImage");

                entity.Property(e => e.RecruitedDetailId).HasColumnName("recruitedDetailId");

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryPerMonth)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryPerMonth");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.Property(e => e.SelectedDate)
                    .HasMaxLength(4000)
                    .HasColumnName("selectedDate");

                entity.Property(e => e.StateName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("stateName");

                entity.Property(e => e.TermsandConditions)
                    .IsUnicode(false)
                    .HasColumnName("termsandConditions");

                entity.Property(e => e.UserAddress)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("userAddress");

                entity.Property(e => e.UserEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userEmail");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(101)
                    .IsUnicode(false)
                    .HasColumnName("userName");

                entity.Property(e => e.UserPhoneNumber)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("userPhoneNumber");

                entity.Property(e => e.UserStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userStatus");
            });

            modelBuilder.Entity<VwpreliminaryRound>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VWPreliminaryRound");

                entity.Property(e => e.ActionBy).HasColumnName("actionBy");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.CityId).HasColumnName("cityId");

                entity.Property(e => e.CityName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cityName");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.CompanyId).HasColumnName("companyId");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companyName");

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("countryCode");

                entity.Property(e => e.CreatedBy).HasColumnName("createdBy");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate");

                entity.Property(e => e.CurrencyId).HasColumnName("currencyId");

                entity.Property(e => e.DesignationId).HasColumnName("designationId");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("dob");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.ExperienceFrom)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceFrom");

                entity.Property(e => e.ExperienceTo)
                    .HasColumnType("decimal(5, 2)")
                    .HasColumnName("experienceTo");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("firstName");

                entity.Property(e => e.JobDescription)
                    .IsUnicode(false)
                    .HasColumnName("jobDescription");

                entity.Property(e => e.JobDetailId).HasColumnName("jobDetailId");

                entity.Property(e => e.JobStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("jobStatus");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("jobTitle");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lastName");

                entity.Property(e => e.NumberOfResources).HasColumnName("numberOfResources");

                entity.Property(e => e.PanNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("panNumber");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("phoneNumber");

                entity.Property(e => e.ProfileImage)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("profileImage");

                entity.Property(e => e.RoleId).HasColumnName("roleId");

                entity.Property(e => e.RoundDetailId).HasColumnName("roundDetailId");

                entity.Property(e => e.RoundStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("roundStatus");

                entity.Property(e => e.SalaryFrom)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryFrom");

                entity.Property(e => e.SalaryTo)
                    .HasColumnType("decimal(15, 2)")
                    .HasColumnName("salaryTo");

                entity.Property(e => e.StateId).HasColumnName("stateId");

                entity.Property(e => e.StateName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("stateName");

                entity.Property(e => e.SubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("submitDate");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.Property(e => e.UserStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userStatus");
            });

            modelBuilder.Entity<ZoomMeeting>(entity =>
            {
                entity.ToTable("zoomMeeting");

                entity.Property(e => e.ZoomMeetingId).HasColumnName("zoomMeetingId");

                entity.Property(e => e.MeetingId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("meetingId");

                entity.Property(e => e.MeetingStatus)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("meetingStatus");

                entity.Property(e => e.MeetingUrl)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("meetingUrl");

                entity.Property(e => e.Topic)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("topic");
            });

            modelBuilder.Entity<ZoomMeetingParticipant>(entity =>
            {
                entity.HasKey(e => e.ParticipantId)
                    .HasName("PK__zoomMeet__4EE79210162FB9A8");

                entity.ToTable("zoomMeetingParticipants");

                entity.Property(e => e.ParticipantId).HasColumnName("participantId");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.MeetingId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("meetingId");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<ZoomTimeZone>(entity =>
            {
                entity.HasKey(e => e.ZoneId)
                    .HasName("PK__ZoomTime__2F75DF797FA45653");

                entity.ToTable("ZoomTimeZone");

                entity.Property(e => e.ZoneId).HasColumnName("zoneId");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ZoomId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("zoomId");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
