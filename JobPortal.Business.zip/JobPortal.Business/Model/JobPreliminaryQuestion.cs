﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobPreliminaryQuestion
    {
        public JobPreliminaryQuestion()
        {
            PreliminaryQuestionAnswers = new HashSet<PreliminaryQuestionAnswer>();
        }

        public int QuestionId { get; set; }
        public int? JobDetailId { get; set; }
        public string QuestionLable { get; set; }
        public string QuestionType { get; set; }
        public string QuestionOptions { get; set; }
        public string Answer { get; set; }
        public string QuestionDescription { get; set; }
        public int? SortOrder { get; set; }
        public bool? IsActive { get; set; }

        public virtual JobDetail JobDetail { get; set; }
        public virtual ICollection<PreliminaryQuestionAnswer> PreliminaryQuestionAnswers { get; set; }
    }
}
