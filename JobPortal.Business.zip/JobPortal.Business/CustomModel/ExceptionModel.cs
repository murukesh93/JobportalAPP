﻿namespace JobPortal.Business.CustomModel
{
    public class ExceptionModel
    {
        public string message { get; set; }
        public string status { get; set; }
    }
}
