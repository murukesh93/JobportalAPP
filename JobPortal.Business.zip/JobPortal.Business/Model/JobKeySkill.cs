﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobKeySkill
    {
        public int? JobDetailId { get; set; }
        public int? KeySkillId { get; set; }
        public int JobKeySkillId { get; set; }

        public virtual JobDetail JobDetail { get; set; }
        public virtual KeySkill KeySkill { get; set; }
    }
}
