﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IJobPreliminaryService
    {
        Task<SuccessModel> SaveQuestions(List<JobPreliminaryList> jobPreliminaryLists);
        Task<List<JobPreliminaryList>> GetJobPreliminaryQuestions(int jobDetailId);
        Task<CreateSuccessModel> SaveAnswer(List<PreliminaryAnswersList> answersLists, PreliminaryRoundDetail preliminaryRound);
        Task<SuccessModel> SaveJobInterviewRounds(List<JobInterviewRoundList> jobInterviewRoundLists);
        Task<VwGetJobInterviewRound> VwGetJobInterviewRound(int inverviewRoundId);
        Task<CreateSuccessModel> UpdatePreliminaryStatus(PreliminaryRoundDetail preliminaryRound);
        Task<AppliedUserList> GetJobAppliedUserList(int count, int offset, int companyId, string userName, string jobTitle, string email, string keySkills, string locations, string companyName, string roundStatus, decimal experienceFrom, decimal experienceTo);
        Task<InterviewRoundList> interviewRoundList(int count, int offset, int interviewRoundId, string roundName, string roundDescription, int roundOrder, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId);
        Task<GetCandidateBySkillSetList> GetCandidateBySkillSet(int count, int offset, string userName, string preferedLocation, string keySkill, string designation);
        Task<GetCandidatePreliminaryAnswerList> GetCandidatePreliminaryAnswer(int candidateId, int jobDetailId);
    } 
}  
  