﻿namespace JobPortal.Business.CustomModel
{
    public  class StateList
    {
        public int? StateId { get; set; }
        public string StateName { get; set; }
        public bool? IsActive { get; set; }
    }
}
