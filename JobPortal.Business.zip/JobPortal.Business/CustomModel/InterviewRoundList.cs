﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class InterviewRoundList
    {
        public List<VwGetJobInterviewRound> data { get; set; }
        public int count { get; set; }
    }
    public class AppliedUserList
    {
        public List<VwGetAppliedUser> data { get; set; }
        public int count { get; set; }
    }
}
