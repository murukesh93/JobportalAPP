﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.SwaggerModel
{
    public class UpdateUserStatus
    {
        public int userId { get; set; }
        public string userStatus { get; set; }
        public string comments { get; set; }

    }
}
