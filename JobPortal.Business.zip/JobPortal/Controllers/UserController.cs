﻿using System;
using System.Net;
using System.Threading.Tasks;
using JobPortal.Business.Common;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;
        private readonly IEmailService emailService;
        private readonly ILog logger;
        public UserController(IUserService _userService, IEmailService _emailService, ILog _log)
        {
            userService = _userService;
            emailService = _emailService;
            logger = _log;
        }

        /// <summary>
        /// 
        /// To get user list
        /// </summary> 
        
        [Authorize(Roles = "1,2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(UserList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetUserList")]
        public async Task<ActionResult> GetUserList(int count, int offset, string firstName, string lastName, string email, string phoneNumber,
             int companyId, string companyName,int roleId,string roleName,string userStatus)
        {
            try
            {
                if (count == 0 || count == null) { count = 10; }
                if (offset == 0 || offset == null) { offset = 0; }
                UserList userList =await userService.GetUserList(count, offset, firstName, lastName, email, phoneNumber, companyId, companyName,roleId,roleName,userStatus);               
                return Ok(userList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetUserList", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        
        /// <summary>
        /// 
        /// To sign up a new user
        /// </summary> 
        
        [AllowAnonymous]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("EndUserSignUp")]
        public async Task<ActionResult> EndUserSignUp(EndUserSignUp user)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "EndUserSignUp", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(user) };
                logger.Info(log);
                // Validation  
                if (string.IsNullOrEmpty(user.FirstName)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "firstName is required" }); }
                if (string.IsNullOrEmpty(user.Email)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "email is required" }); }
                if (string.IsNullOrEmpty(user.Password)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "password is required" }); }
                if (string.IsNullOrEmpty(user.PanNumber)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "panNumber is required" }); }
                if (user.RoleId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "RoleId is required" }); }
                User userModel = new User
                {
                    UserId = 0,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    Password = Common.EncryptData(user.Password),
                    Address = user.Address,
                    CityId = user.CityId,
                    StateId = user.StateId,
                    CreatedBy = user.CreatedBy,
                    RoleId = user.RoleId,
                    UserStatus = "Not Verified",
                    IsDeleted = false,
                    Dob = user.Dob,
                    Gender=user.Gender,
                    PanNumber = user.PanNumber,
                    ProfileImage = user.ProfileImage,
                    CountryCode = user.CountryCode,
                    PhoneNumber = user.PhoneNumber
                };
                CreateSuccessModel result =await userService.UpsertUser(userModel, 0);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {             
                    
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }


        /// <summary>
        /// To update a existing user
        /// </summary> 
        [AllowAnonymous]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateUser")]
        public async Task<ActionResult> UpdateUser(UpdateUser user)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(user) };
                logger.Info(log);
                // Validation  
                if (string.IsNullOrEmpty(user.FirstName)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "firstName is required" }); }
                User userModel = new User
                {
                    UserId = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Address = user.Address,
                    CityId = user.CityId,
                    StateId = user.StateId,
                    UserStatus = user.UserStatus,
                    Gender=user.Gender,
                    Dob = user.Dob,
                    ProfileImage = user.ProfileImage,
                    PhoneNumber=user.PhoneNumber,
                    PanNumber=user.PanNumber,
                    CountryCode=user.CountryCode
                };
                CreateSuccessModel result =await userService.UpsertUser(userModel, 0);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// 
        /// To delete a user object
        /// </summary>
        [Authorize(Roles = "1")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [Route("DeleteUser")]
        public async Task<ActionResult> DeleteUser(int userId)
        {
            try
            {
                if (userId == 0 || userId == null)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new SuccessModel { status = "Error", message = "userId is required" });
                }
                SuccessModel result = await userService.DeleteUser(userId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a user object
        /// </summary> 
        [Authorize(Roles = "1,2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(VwUser), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [Route("GetUser")]
        public async Task<ActionResult> GetUser(int userId)
        {
            try
            {
                if (userId == 0 || userId == null)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new SuccessModel { status = "Error", message = "userId is required" });
                }
                VwUser result = await userService.GetUser(userId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To sign up a new user
        /// </summary> 
        [Authorize(Roles = "1,2")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateCompanyUser")]
        public async Task<ActionResult> CreateCompanyUser(CreateCompanyUser user)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateCompanyUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(user) };
                logger.Info(log);
                // Validation  
                if (string.IsNullOrEmpty(user.FirstName)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "firstName is required" }); }
                if (string.IsNullOrEmpty(user.Email)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "email is required" }); }
                if (string.IsNullOrEmpty(user.Password)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "password is required" }); }
                if (user.CompanyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "companyId is required" }); }
                if (user.RoleId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "RoleId is required" }); }
                User userModel = new User
                {
                    UserId = 0,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    Password = Common.EncryptData(user.Password),
                    Address = user.Address,
                    CityId = user.CityId,
                    StateId = user.StateId,
                    CreatedBy = user.CreatedBy,
                    RoleId = user.RoleId,
                    UserStatus = "Verified",
                    IsDeleted = false,
                    Gender = user.Gender,
                    Dob = user.Dob,
                    PanNumber = user.PanNumber,
                    ProfileImage = user.ProfileImage,
                    CountryCode = user.CountryCode,
                    PhoneNumber = user.PhoneNumber
                };
                CreateSuccessModel result = await userService.UpsertUser(userModel, user.CompanyId);
                if (result.Status == "Success")
                {
                    await emailService.PasswordByEmail(userModel);
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateCompanyUser", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update the user status
        /// </summary> 
        [Authorize(Roles = "1")]
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [Route("UpdateUserStatus")]
        public async Task<ActionResult> UpdateUserStatus(UpdateUserStatus model)
        {
            try
            {

                LogStatus log = new LogStatus { FunctionName = "UpdateUserStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(model) };
                logger.Info(log);
                if (model.userId == 0 || model.userId == null)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new SuccessModel { status = "Error", message = "userId is required" });
                }
                else if (string.IsNullOrEmpty(model.userStatus))
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new SuccessModel { status = "Error", message = "userStatus is required" });
                }
                SuccessModel result = await userService.UpdateUserStatus(model.userId, model.userStatus , model.comments);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateUserStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }


        /// <summary>
        /// To delete a user object
        /// </summary> 
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [Route("UpdatePassword")]
        public async Task<ActionResult> UpdatePassword(UpdatePassword model)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdatePassword", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"),Data = JsonConvert.SerializeObject(model) };
                logger.Info(log);
                if (model.UserId == 0 || model.UserId == null)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new SuccessModel { status = "Error", message = "userId is required" });
                }
                if (string.IsNullOrEmpty(model.OldPassword)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "oldPassword is required" }); }
                if (string.IsNullOrEmpty(model.NewPassword)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "newPassword is required" }); }
                SuccessModel result = await userService.UpdatePassword(model);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdatePassword", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a email OTP
        /// </summary> 
        [AllowAnonymous]
        [HttpGet]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GenerateOtp")]
        public async Task<ActionResult> GenerateOtp(string email,string otpType)
        {
            try
            {
                if (string.IsNullOrEmpty(email)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Email is required" }); }
                if (string.IsNullOrEmpty(otpType)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "otpType is required" }); }
                Otpvalue otpvalueModel = new Otpvalue
                {
                    Status = "Sent",
                    Source = email,
                    OtpType = otpType,
                    OtpText=""
                };
                SuccessModel result = await emailService.GenerateOtp(otpvalueModel,email,otpType);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GenerateOtp", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Update Password Using OTP
        /// </summary>
        [AllowAnonymous]
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [Route("UpdatePasswordByOtp")]
        public async Task<ActionResult> UpdatePasswordByOtp(UpdatePasswordByOtp model)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdatePasswordByOtp", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(model) };
                logger.Info(log);
                if (string.IsNullOrEmpty(model.Email)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Email is required" }); }
                if (string.IsNullOrEmpty(model.OTP)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "OTP is required" }); }
                if (string.IsNullOrEmpty(model.NewPassword)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "newPassword is required" }); }
                Otpvalue otpvalueModel = new Otpvalue
                {
                    Status= "Verified"
                };
                User userModel = new User
                {
                    Password = model.NewPassword
                };
                SuccessModel result =await emailService.UpdatePasswordByOtp(model,otpvalueModel,userModel);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdatePasswordByOtp", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ExceptionModel { status = "Error", message = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("VerifyPAN")]
        public async Task<ActionResult> VerifyPAN(PanVerify panModel)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "VerifyPAN", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(panModel) };
                logger.Info(log);
                // Validation  
                if (string.IsNullOrEmpty(panModel.PanNumber)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Pan Number is required" }); }
                if (string.IsNullOrEmpty(panModel.Name)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Pan Name is required" }); }
                SuccessModel result = await userService.verifyPAN(panModel.PanNumber,panModel.Name);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "VerifyPAN", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
