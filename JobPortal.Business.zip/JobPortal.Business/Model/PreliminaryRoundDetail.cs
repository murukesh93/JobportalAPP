﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class PreliminaryRoundDetail
    {
        public int RoundDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public int? UserId { get; set; }
        public DateTime SubmitDate { get; set; }
        public string RoundStatus { get; set; }
        public int? ActionBy { get; set; }
        public string Comments { get; set; }

        public virtual User ActionByNavigation { get; set; }
        public virtual JobDetail JobDetail { get; set; }
        public virtual User User { get; set; }
    }
}
