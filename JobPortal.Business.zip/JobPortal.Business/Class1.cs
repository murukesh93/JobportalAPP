﻿using System;

namespace JobPortal.Business
{
    public class Class1
    {
    }
}
