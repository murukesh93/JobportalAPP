﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class Currency
    {
        public Currency()
        {
            JobDetails = new HashSet<JobDetail>();
            JobSeekerDetails = new HashSet<JobSeekerDetail>();
            RecruitedJobSeekerDetails = new HashSet<RecruitedJobSeekerDetail>();
        }

        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public string CurrencyCode { get; set; }

        public virtual ICollection<JobDetail> JobDetails { get; set; }
        public virtual ICollection<JobSeekerDetail> JobSeekerDetails { get; set; }
        public virtual ICollection<RecruitedJobSeekerDetail> RecruitedJobSeekerDetails { get; set; }
    }
}
