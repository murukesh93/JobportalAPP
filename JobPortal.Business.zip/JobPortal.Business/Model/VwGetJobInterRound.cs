﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwGetJobInterRound
    {
        public int InterviewRoundId { get; set; }
        public int? JobDetailId { get; set; }
        public string RoundName { get; set; }
        public string RoundDescription { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public string JobStatus { get; set; }
        public int? NumberOfResources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public int? DesignationId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public bool? IsDeleted { get; set; }
        public string JobLocations { get; set; }
        public string KeySkills { get; set; }
        public int? RoundOrder { get; set; }
        public bool? IsActive { get; set; }
    }
}
