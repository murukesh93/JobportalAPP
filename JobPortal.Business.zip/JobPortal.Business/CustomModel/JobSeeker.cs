﻿namespace JobPortal.Business.CustomModel
{
    public class JobSeeker
    {
        public int JobSeekerId { get; set; }
        public int? UserId { get; set; }
        public decimal? WorkExperience { get; set; }
        public string ResumeUrl { get; set; }
        public string ResumeHeading { get; set; }
        public decimal? CurrentCtc { get; set; }
        public int? CurrencyId { get; set; }
        public int? NoticePeriod { get; set; }
        public decimal? ExpectedCtc { get; set; }
        public string PersonalInfo { get; set; }
        public string Payslip { get; set; }
        public int? DesignationId { get; set; }
    }
}
