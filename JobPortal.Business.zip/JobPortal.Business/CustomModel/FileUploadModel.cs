﻿namespace JobPortal.Business.CustomModel
{
    public class FileUploadModel
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public string FilePath { get; set; }
    }
}
