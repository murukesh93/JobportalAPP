﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class ZoomTimeZone
    {
        public int ZoneId { get; set; }
        public string ZoomId { get; set; }
        public string Name { get; set; }
    }
}
