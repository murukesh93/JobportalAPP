﻿namespace JobPortal.SwaggerModel
{
    public class UpdateRoundStatus
    {
        public int RoundDetailId { get; set; }
        public string RoundStatus { get; set; }
        public int? ActionBy { get; set; }
        public string Comments { get; set; }
    }
}
