﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class CompanyDetail
    {
        public CompanyDetail()
        {
            CompanyCategories = new HashSet<CompanyCategory>();
            CompanyUsers = new HashSet<CompanyUser>();
            JobDetails = new HashSet<JobDetail>();
        }

        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CompanyLogo { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public int? StateId { get; set; }
        public int? CreatedBy { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public bool? IsDeleted { get; set; }
        public string CompanySiteUrl { get; set; }

        public virtual User CreatedByNavigation { get; set; }
        public virtual ICollection<CompanyCategory> CompanyCategories { get; set; }
        public virtual ICollection<CompanyUser> CompanyUsers { get; set; }
        public virtual ICollection<JobDetail> JobDetails { get; set; }
    }
}
