﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerEmployementDetail
    {
        public int EmployementDetailId { get; set; }
        public int? UserId { get; set; }
        public string OrganizationName { get; set; }
        public int? DesignationId { get; set; }
        public bool? IsCurrentCompany { get; set; }
        public DateTime? WorkingFrom { get; set; }
        public DateTime? WorkingTo { get; set; }
        public string JobDescribtion { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual Designation Designation { get; set; }
        public virtual User User { get; set; }
    }
}
