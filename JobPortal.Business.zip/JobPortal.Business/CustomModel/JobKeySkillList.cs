﻿namespace JobPortal.Business.CustomModel
{
    public class JobKeySkillList
    {
        public int? JobDetailId { get; set; }
        public int? KeySkillId { get; set; }
        public int JobKeySkillId { get; set; }
    }
}
