﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class UserService : IUserService
    {
        private JobPortalContext dbContext;
        private readonly IEmailService emailService;
        public UserService(JobPortalContext _db , IEmailService _emailService)
        {
            dbContext = _db;
            emailService = _emailService;
        }
        public async Task<UserList> GetUserList(int count, int offset, string firstName, string lastName, string email, string phoneNumber, int companyId, string companyName, int roleId, string roleName, string userStatus)
        {
            try
            {
                List<System.Data.SqlClient.SqlParameter> parameters = new List<System.Data.SqlClient.SqlParameter>();
                parameters.Add(new System.Data.SqlClient.SqlParameter("@count", count));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@offset", offset));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@firstName", firstName));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@lastName", lastName));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@email", email));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@phoneNumber", phoneNumber));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@companyId", companyId));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@companyName", companyName));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@roleId", roleId));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@roleName", roleName));
                parameters.Add(new System.Data.SqlClient.SqlParameter("@userStatus", userStatus));
                DataSet ds = Common.Common.GetResultSet("spGetUser", parameters);
                List<VwUser> output = Common.Common.ToListof<VwUser>(ds.Tables[1]);
                UserList userList = new UserList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return userList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CreateSuccessModel> UpsertUser(User user, int companyId)
        {
            try
            {
                CreateSuccessModel result;
                if (user.UserId > 0) // Update 
                {
                    User existingUser = await dbContext.Users.FirstOrDefaultAsync(u => u.UserId == user.UserId);
                    existingUser.FirstName = user.FirstName;
                    existingUser.LastName = user.LastName;
                    existingUser.Address = user.Address;
                    existingUser.CityId = user.CityId;
                    existingUser.StateId = user.StateId;
                    existingUser.UserStatus = user.UserStatus;
                    existingUser.Gender = user.Gender;
                    existingUser.Dob = user.Dob;
                    existingUser.ProfileImage = user.ProfileImage;
                    existingUser.PhoneNumber = user.PhoneNumber;
                    existingUser.PanNumber = user.PanNumber;
                    existingUser.CountryCode = user.CountryCode;
                    dbContext.Update(existingUser);
                }
                else // Insert
                {
                    if (!string.IsNullOrEmpty(user.PhoneNumber))
                    {
                        int phoneNumberCount = await dbContext.Users.Where(u => u.PhoneNumber == user.PhoneNumber && u.IsDeleted == false).CountAsync();
                        if (phoneNumberCount > 0)
                        {
                            result = new CreateSuccessModel
                            {
                                Id = 0,
                                message = "PhoneNumber already exist",
                                Status = "Error"
                            };
                            return result;
                        }
                    }
                    if (!string.IsNullOrEmpty(user.PanNumber))
                    {
                        int panNumberCount = await dbContext.Users.Where(u => u.PanNumber == user.PanNumber && u.IsDeleted == false).CountAsync();
                        if (panNumberCount > 0)
                        {
                            result = new CreateSuccessModel
                            {
                                Id = 0,
                                message = "PAN Number already exist",
                                Status = "Error"
                            };
                            return result;
                        }
                    }
                    int emailCount = await dbContext.Users.Where(u => u.Email == user.Email && u.IsDeleted == false).CountAsync();
                    if (emailCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "Email already exist",
                            Status = "Error"
                        };
                        return result;

                    }
                    user.IsDeleted = false;
                    await dbContext.Users.AddAsync(user);
                }
                 await dbContext.SaveChangesAsync();
                // create company User
                if (companyId > 0)
                {
                    CompanyUser companyUser = new CompanyUser { CompanyId = companyId, UserId = user.UserId };
                    await dbContext.CompanyUsers.AddAsync(companyUser);
                    await dbContext.SaveChangesAsync();
                }
                result = new CreateSuccessModel
                {
                    Id = user.UserId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> DeleteUser(int userId)
        {
            try
            {
                SuccessModel result;
                User existingUser = await dbContext.Users.FirstOrDefaultAsync(a => a.UserId == userId);
                if (existingUser == null)
                {
                    result = new SuccessModel { message = "No record found", status = "Error" };
                }
                else
                {
                    existingUser.IsDeleted = true;
                    dbContext.Update(existingUser);
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel { message = "Record deleted successfully", status = "Success" };

                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
        public async Task<VwUser> GetUser(int userId)
        {
            try
            {
                VwUser existingUser = await dbContext.VwUsers.FirstOrDefaultAsync(a => a.UserId == userId);
                return existingUser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> UpdateUserStatus(int userId, string userStatus, string comments)
        {
            try
            {
                SuccessModel result;
                User existingUser =await  dbContext.Users.FirstOrDefaultAsync(a => a.UserId == userId);
                if (existingUser == null)
                {
                    result = new SuccessModel { message = "No record found", status = "Error" };
                }
                else
                {
                    var email = existingUser.Email;
                    existingUser.UserStatus = userStatus;
                    existingUser.StatusComment = comments;
                    dbContext.Update(existingUser);
                    await dbContext.SaveChangesAsync();
                    await emailService.UserStatusEmail(email, userStatus, comments);
                    result = new SuccessModel { message = "Status updated successfully", status = "Success" };
                }
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> UpdatePassword(UpdatePassword model)
        {
            try
            {
                SuccessModel result;
                User existingUser = await dbContext.Users.FirstOrDefaultAsync(a => a.UserId == model.UserId);
                if (existingUser == null)
                {
                    return result = new SuccessModel { message = "No record found", status = "Error" };
                }
                if (existingUser.Password != Common.Common.EncryptData(model.OldPassword))
                {
                    return result = new SuccessModel { message = "Invalid Password", status = "Error" };
                }
                existingUser.Password = Common.Common.EncryptData(model.NewPassword);
                dbContext.Update(existingUser);
                await dbContext.SaveChangesAsync();
                result = new SuccessModel { message = "Password updated successfully", status = "Success" };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> verifyPAN(string panNumber, string name)
        {
            try
            {
                SuccessModel result;
                var authorizationClient = new RestClient(Common.Common.GetConnectionString("signZy", "authorizationClient"));
                var authorizationRequest = new RestRequest(Method.POST);
                authorizationRequest.AddHeader("Content-Type", "application/json");
                var authorizationBody = $@"{{
                        ""username"":""{Common.Common.GetConnectionString("Signzy", "UserName")}"",
                         ""password"":""{Common.Common.GetConnectionString("Signzy", "Password")}""
                           }}";
                authorizationRequest.AddParameter("application/json", authorizationBody, ParameterType.RequestBody);
                IRestResponse authorizationResponse = authorizationClient.Execute(authorizationRequest);
                var authorizationResult = JsonConvert.DeserializeObject<PanVerificationJsonList>(authorizationResponse.Content);

                var identityClient = new RestClient(Common.Common.GetConnectionString("signzy", "identityClient") + $"{authorizationResult.userId}/identities");
                var identityRequest = new RestRequest(Method.POST);
                identityRequest.AddHeader("Authorization", authorizationResult.id);
                identityRequest.AddHeader("Content-Type", "application/json");
                var identityBody = $@"{{
                        ""type"": ""individualPan"",
                        ""email"": ""admin@signzy.com"",
                        ""callbackUrl"": ""{Common.Common.GetConnectionString("signzy", "callbackUrl")}""
                           }}";
                identityRequest.AddParameter("application/json", identityBody, ParameterType.RequestBody);
                IRestResponse identityResponse = identityClient.Execute(identityRequest);
                var identityResult = JsonConvert.DeserializeObject<PanVerificationJsonList>(identityResponse.Content);

                var client = new RestClient(Common.Common.GetConnectionString("signzy", "client"));
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/json");
                var body = $@"{{
                        ""service"": ""Identity"",
                        ""itemId"":""{identityResult.id}"",
                        ""task"":""verification"",
                        ""accessToken"":""{identityResult.accessToken}"",
                         ""essentials"": {{
                                           ""number"": ""{panNumber}"",
                                           ""name"": ""{name}"",
                                           ""fuzzy"":""true""
                                        }}
                           }}";
                request.AddParameter("application/json", body, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                var clintResult = JsonConvert.DeserializeObject<PanVerificationJsonList>(response.Content);
                if (clintResult.response == null)
                {
                    if (identityResponse.IsSuccessful == false)
                    {
                        result = new SuccessModel { message = identityResult.error.message, status = "Error" };
                        return result;
                    }
                    if (response.IsSuccessful == false)
                    {
                        result = new SuccessModel { message = clintResult.error.message, status = "Error" };
                        return result;
                    }
                    result = new SuccessModel { message = clintResult.response.result.message, status = "Error" };
                }
                else
                {
                    result = new SuccessModel { status = "Success", message = clintResult.response.result.message };
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
