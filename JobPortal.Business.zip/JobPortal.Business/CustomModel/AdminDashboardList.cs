﻿using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class AdminDashboardList
    {
        public int TotalApplications { get; set; }
        public int TodayApplicationCount { get; set; }
        public int NewCanditatesCount { get; set; }
        public int SelectedCanditates { get; set; }
        public int ScheduleInterviewCount { get; set; }
        public int RejectedCanditatesCount { get; set; }
        public int LiveJobsCount { get; set; }
        public int ExpiredJobsCount { get; set; }
        public int DraftJobsCount { get; set; }
        public List<TodayInterviewList> todayInterviewLists { get; set; }
        public List<InterviewerLists> interviewerLists { get; set; }
        public List<TodayCompletedList> todayCompletedLists { get; set; }
        public List<TodayCandidateSelectedList> todayCandidateSelectedLists { get; set; }
    }
}
