﻿using JobPortal.Business.CustomModel;
using System.Collections.Generic;

namespace JobPortal.SwaggerModel
{
    public class SaveInterviewRounds
    {
       public List<JobInterviewRoundList> jobInterviewRoundLists;
    }
}
