﻿namespace JobPortal.SwaggerModel
{
    public class CreateZoomParticipants
    {
          public string Email{get;set;}        
          public string First_name {get;set;}
          public string MeetingId { get; set; }
    }   
}
