﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class InterviewService : IInterviewService
    {
        private JobPortalContext dbContext;
        private readonly IZoomService zoomService;
        public InterviewService(JobPortalContext _db,IZoomService _zoomService)
        {
            dbContext = _db;
            zoomService = _zoomService;
        }
        public async Task<CreateSuccessModel> UpsertInterview(ScheduleInterview scheduleInterview, string topic, int type, string schedule_For, string timezone, string agenda)
        {
            try
            {
                CreateSuccessModel result = null;
                if (scheduleInterview.ScheduleId > 0)
                {
                    ScheduleInterview existingInterview = await dbContext.ScheduleInterviews.FirstOrDefaultAsync(s => s.ScheduleId == scheduleInterview.ScheduleId);
                    TimeSpan? diff;

                    if (existingInterview.ScheduleId > 0)
                    {
                        if (scheduleInterview.InterviewStatus == "Cancelled")
                        {
                           await  zoomService.DeleteMeeting(existingInterview.MeetingId); // delete a meeting
                        }
                        if (scheduleInterview.InterviewStatus == "Completed")
                        {
                            await zoomService.UpdateMeetingStatus(existingInterview.MeetingId, "end");
                        }
                        

                        diff = scheduleInterview.InterviewEndDateTime - scheduleInterview.InterviewStartDateTime;
                     
                        UpdateMeetingList updateMeeting = new UpdateMeetingList
                        {
                            MeetingId=existingInterview.MeetingId, 
                            Topic = topic,
                            Timezone = timezone,
                            Start_time = Convert.ToString(scheduleInterview.InterviewStartDateTime),
                            Duration = diff.Value.Hours,
                            Agenda = agenda,
                            Schedule_for = schedule_For,
                            Type = type
                        };
                        await zoomService.UpdateMeeting(updateMeeting);

                        existingInterview.InterviewStartDateTime = scheduleInterview.InterviewStartDateTime;
                        existingInterview.InterviewRoundId = scheduleInterview.InterviewRoundId;
                        existingInterview.UserId = scheduleInterview.UserId;
                        existingInterview.ScheduledBy = scheduleInterview.ScheduledBy;
                        existingInterview.CommunicationNumber = scheduleInterview.CommunicationNumber;
                        existingInterview.InterviewEndDateTime = scheduleInterview.InterviewEndDateTime;
                        existingInterview.CommunicationChannel = scheduleInterview.CommunicationChannel;
                        existingInterview.InterviewStatus = scheduleInterview.InterviewStatus;
                        existingInterview.InterviewResult = scheduleInterview.InterviewResult;
                        existingInterview.Feedback = scheduleInterview.Feedback;
                        existingInterview.Interviewer = scheduleInterview.Interviewer;
                        dbContext.Update(existingInterview);
                        await dbContext.SaveChangesAsync();
                    }
                    else
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "Invalid ScheduleId",
                            Status = "Error"
                        };
                        return result;
                    }
                }
                else
                {
                    //Validation
                    /*JobInterviewRound jobId = await dbContext.JobInterviewRounds.FirstOrDefaultAsync(x => x.InterviewRoundId == scheduleInterview.InterviewRoundId);
                    var interviewOrder = await (from a in dbContext.JobInterviewRounds.Where(x=>x.JobDetailId == jobId.JobDetailId)
                                                join b in dbContext.ScheduleInterviews.Where(y=>y.UserId==scheduleInterview.UserId) on a.InterviewRoundId equals b.InterviewRoundId into gj
                                                from x in gj.DefaultIfEmpty()
                                                where a.IsActive == true && a.JobDetailId == jobId.JobDetailId && x.InterviewStatus == null
                                                orderby a.RoundOrder ascending
                                                select new
                                                {
                                                    InterviewRoundId = a.InterviewRoundId
                                                }
                                              ).ToListAsync();
                    if (interviewOrder[0].InterviewRoundId != scheduleInterview.InterviewRoundId)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = scheduleInterview.ScheduleId,
                            message = "We Can't Shedule Interview,Please follow our interview rules",
                            Status = "Error"
                        };
                        return result;
                    }*/

                    ScheduleInterview existingRoundStatus = await dbContext.ScheduleInterviews.FirstOrDefaultAsync(s => s.InterviewRoundId == scheduleInterview.InterviewRoundId && s.InterviewStatus != "Cancelled");
                    if (existingRoundStatus != null)
                        {

                            if (existingRoundStatus.InterviewStatus == "New")
                            {
                                result = new CreateSuccessModel
                                {
                                    Id = 0,
                                    message = "Interview already Newly applied",
                                    Status = "Error"
                                };
                                return result;
                            }
                            else if (existingRoundStatus.InterviewStatus == "Approved")
                            {
                                result = new CreateSuccessModel
                                {
                                    Id = 0,
                                    message = "Interview already Completed",
                                    Status = "Error"
                                };
                                return result;
                            }
                        }

                    if (scheduleInterview.CommunicationChannel == "Zoom")
                    {
                        TimeSpan? diff = scheduleInterview.InterviewEndDateTime - scheduleInterview.InterviewStartDateTime;
                        var startTime = Convert.ToString(scheduleInterview.InterviewStartDateTime);
                        CreateMeetingList createMeeting = new CreateMeetingList
                        {
                            Topic = topic,
                            Timezone = timezone,
                            Start_time = startTime,
                            Duration = diff.Value.Hours,
                            Agenda = agenda,
                            Schedule_for = schedule_For,
                            Type = type
                        };
                        MeetingCreatedList meetingCreatedList = await zoomService.CreateNewMeeting(createMeeting);
                        scheduleInterview.MeetingId = meetingCreatedList.Id;
                        ZoomMeeting zoomMeeting = new ZoomMeeting
                        {
                            MeetingId = meetingCreatedList.Id,
                            Topic = meetingCreatedList.Topic,
                            MeetingUrl = meetingCreatedList.Join_url,
                            MeetingStatus = "New",

                        };

                        await dbContext.ZoomMeetings.AddAsync(zoomMeeting);
                    }


                    User existingUser = await dbContext.Users.FirstOrDefaultAsync(a => a.UserId == scheduleInterview.UserId);
                    scheduleInterview.CommunicationNumber = existingUser.PhoneNumber;
                    await dbContext.ScheduleInterviews.AddAsync(scheduleInterview);
                }
                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = scheduleInterview.ScheduleId,
                    message = "Record Save Succesfully",
                    Status = "Success"
                };


                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
        public async Task<VwGetScheduleInterview> GetScheduleInterviewById(int scheduleId)
        {
            try
            {
                VwGetScheduleInterview result = await dbContext.VwGetScheduleInterviews.FirstOrDefaultAsync(s => s.ScheduleId == scheduleId);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<ScheduleInterviewList> GetInterviewDetails(int count, int offset, string jobTitle, int jobDetailId,string userName, int interviewRoundId, int userId, int interviewerId, int scheduleBy, string interviewStartDateTime, string interviewEndDateTime, string schedulerName, string interviewerName, string interviewStatus, int roundOrder, string roundName, string interviewResult, string communicationChannel)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@userName", userName));
                parameters.Add(new SqlParameter("@interviewRoundId", interviewRoundId));
                parameters.Add(new SqlParameter("@jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("@userId", userId));
                parameters.Add(new SqlParameter("@interviewerId", interviewerId));
                parameters.Add(new SqlParameter("@scheduleBy", scheduleBy));
                parameters.Add(new SqlParameter("@interviewStartDateTime", interviewStartDateTime));
                parameters.Add(new SqlParameter("@interviewEndDateTime", interviewEndDateTime));
                parameters.Add(new SqlParameter("@schedulerName", schedulerName));
                parameters.Add(new SqlParameter("@interviewerName", interviewerName));
                parameters.Add(new SqlParameter("@interviewStatus", interviewStatus));
                parameters.Add(new SqlParameter("@roundOrder", roundOrder));
                parameters.Add(new SqlParameter("@roundName", roundName));
                parameters.Add(new SqlParameter("@interviewResult", interviewResult));
                parameters.Add(new SqlParameter("@communicationChannel", communicationChannel));
                DataSet ds = Common.Common.GetResultSet("spGetScheduleInterview", parameters);
                List<VwGetScheduleInterview> output =  Common.Common.ToListof<VwGetScheduleInterview>(ds.Tables[2]);
                ScheduleInterviewList scheduleInterviewList = new ScheduleInterviewList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0,isSelected=(ds.Tables[1].Rows[0][0]==DBNull.Value ? false :(bool)ds.Tables[1].Rows[0][0])};
                return scheduleInterviewList;
            } 
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<CreateSuccessModel> UpdateInterviewStatus(ScheduleInterview scheduleInterview, int ScheduleId, string InterviewStatus, string InterviewResult, string Feedback)
        {
            CreateSuccessModel result;
            ScheduleInterview existingInterview = await dbContext.ScheduleInterviews.FirstOrDefaultAsync(s => s.ScheduleId == scheduleInterview.ScheduleId);
            if (existingInterview.ScheduleId > 0)
            {
                if (scheduleInterview.InterviewStatus == "Cancelled" && string.IsNullOrEmpty(existingInterview.MeetingId)==false)
                {
                    await zoomService.DeleteMeeting(existingInterview.MeetingId); // delete a meeting
                }
                if (scheduleInterview.InterviewStatus == "Completed" && string.IsNullOrEmpty(existingInterview.MeetingId) == false)
                {
                    await zoomService.UpdateMeetingStatus(existingInterview.MeetingId, "end");
                }

                existingInterview.InterviewStatus = scheduleInterview.InterviewStatus;
                existingInterview.InterviewResult = scheduleInterview.InterviewResult;
                existingInterview.Feedback = scheduleInterview.Feedback;
                dbContext.Update(existingInterview);
                await dbContext.SaveChangesAsync();

                if (scheduleInterview.InterviewResult == "Fail")
                {
                    JobInterviewRound existingRound =await (from a in dbContext.JobInterviewRounds
                                                       join b in dbContext.ScheduleInterviews on a.InterviewRoundId equals b.InterviewRoundId
                                                       where b.ScheduleId == scheduleInterview.ScheduleId
                                                       select new JobInterviewRound
                                                       {
                                                           JobDetailId = a.JobDetailId
                                                       }).FirstOrDefaultAsync();
                    PreliminaryRoundDetail existingRoundDetail = await dbContext.PreliminaryRoundDetails.FirstOrDefaultAsync(a => a.UserId == existingInterview.UserId
                                                                 && a.JobDetailId == existingRound.JobDetailId);
                    existingRoundDetail.RoundStatus = "Rejected";
                    dbContext.Update(existingRoundDetail);
                    await dbContext.SaveChangesAsync();
                }
                result = new CreateSuccessModel
                {
                    Id = existingInterview.ScheduleId,
                    message = "Record Updated Successfully",
                    Status = "Success"
                };
                return result;
            }
            else
            {
                result = new CreateSuccessModel
                {
                    Id = 0,
                    message = "Invalid ScheduleId",
                    Status = "Error"
                };
                return result;

            }

        }
    }
}
