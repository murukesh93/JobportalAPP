﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class ZoomMeetingParticipant
    {
        public int ParticipantId { get; set; }
        public string MeetingId { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
    }
}
