﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerProjectDetail
    {
        public int ProjectDetailId { get; set; }
        public int? UserId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public decimal? Duration { get; set; }
        public string YourRole { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual User User { get; set; }
    }
}
