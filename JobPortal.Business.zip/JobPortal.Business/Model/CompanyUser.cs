﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class CompanyUser
    {
        public int CompanyUserId { get; set; }
        public int? UserId { get; set; }
        public int? CompanyId { get; set; }

        public virtual CompanyDetail Company { get; set; }
        public virtual User User { get; set; }
    }
}
