﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class CommonController : ControllerBase
    {
        private readonly ICommonService commonService;
        private readonly ILog logger;
        public CommonController(ICommonService _commonService,ILog _logger)
        {
            commonService = _commonService;
            logger = _logger;
        }

        /// <summary>
        /// 
        /// To get role list
        /// </summary> 
        [HttpGet]
        [ProducesResponseType(typeof(RoleList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetRole")]
        public async Task<ActionResult> GetRole()
        {
            try
            {
                List<RoleList> role=await commonService.GetRole();
                return Ok(role);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetRole", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }

        }
        /// <summary>
        /// To Update Role
        /// </summary>
        /// <returns></returns>
        [Authorize (Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateRole")]
        public async Task<IActionResult> UpdateRole(RoleList roleList)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateRole", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm"),Data= JsonConvert.SerializeObject(roleList) };
                logger.Info(log);
                SuccessModel result =await commonService.UpdateRole(roleList);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateRole", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm"), Error =ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// 
        /// To get state list
        /// </summary> 
        /// 

        [HttpGet]
        [ProducesResponseType(typeof(StateList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetStates")]
        public async Task<ActionResult> GetState()
        {
            try
            {
                List<StateList> state =await commonService.GetState();
                return Ok(state);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetStates", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }


        /// <summary>
        /// 
        /// To get cityList
        /// 
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [ProducesResponseType(typeof(List<CityList>),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetCity")]
        public async Task<ActionResult> GetCity(int? stateId)
        {
            try
            {
                List<CityList> city =await commonService.GetCity(stateId);
                return Ok(city);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCity", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

       /// <summary>
       /// To get CurrencyList
       /// </summary
       /// <returns></returns>

        [HttpGet]
        [ProducesResponseType(typeof(List<CurrencyList>),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetCurrency")]
        public async Task<ActionResult> GetCurrency()
        {
            try
            {
                List<CurrencyList> currency =await commonService.GetCurrency();
                return Ok(currency);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCurrency", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a Designation
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [ProducesResponseType(typeof(List<DesignationList>),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetDesignation")]
        public async Task<ActionResult> GetDesignation()
        {
            try
            {
                List<DesignationList> designation =await commonService.GetDesignation();
                return Ok(designation);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetDesignation", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        } 
    }
}
