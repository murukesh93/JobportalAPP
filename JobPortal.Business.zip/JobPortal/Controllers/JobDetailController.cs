﻿using System;
using System.Net;
using System.Threading.Tasks;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobDetailController : ControllerBase
    {
        public readonly IJobDetailService jobDetailService;
        private readonly ILog logger;
        public JobDetailController(IJobDetailService _jobDetailService, ILog _log)
        {
            jobDetailService = _jobDetailService;
            logger = _log;
        }

        /// <summary>
        /// To create a job
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        [Authorize(Roles = "2")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status404NotFound)]
        [Route("CreateJob")]
        public async Task<ActionResult> CreateJob(CreateJob job)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateJob", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(job) };
                logger.Info(log);
                if (string.IsNullOrEmpty(job.JobTitle)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobTitle is Required!" }); }
                if (job.CreatedBy == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CreatedBy is Required!" }); }
                if (job.CurrencyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CurrencyId is Required!" }); }
                if (string.IsNullOrEmpty(job.JobDescription)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDescription is Required!" }); }
                if (string.IsNullOrEmpty(job.JobStatus)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobStatus is Required!" }); }
                if (job.SalaryFrom == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "SalaryFrom is Required!" }); }
                if (job.SalaryTo == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "SalaryTo is Required!" }); }
                if (job.NumberOfResources == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "NumberOfResources is Required!" }); }
                if (job.CityId.Count == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CityId is Required!" }); }
                if (job.KeySkillId.Count == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "KeySkillId is Required!" }); }
                if (job.CompanyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CompanyId is Required!" }); }
                JobDetail jobDetail = new JobDetail
                {
                    JobDetailId = 0,
                    JobTitle = job.JobTitle,
                    JobDescription = job.JobDescription,
                    CreatedBy = job.CreatedBy,
                    JobStatus = job.JobStatus,
                    NumberOfResources = job.NumberOfResources,
                    ExperienceFrom = job.ExperienceFrom,
                    ExperienceTo = job.ExperienceTo,
                    DesignationId = job.DesignationId,
                    CurrencyId = job.CurrencyId,
                    SalaryFrom = job.SalaryFrom,
                    SalaryTo = job.SalaryTo,
                    CompanyId=job.CompanyId,
                    IsDeleted = false
                };
                CreateSuccessModel result =await jobDetailService.UpsertJobDetail(jobDetail, job.CityId, job.KeySkillId);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateJob", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To update a job details
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        [Authorize(Roles = "2")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status404NotFound)]
        [Route("UpdateJobDetails")]
        public async Task<ActionResult> UpdateJobDetails(UpdateJob job)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateJobDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(job) };
                logger.Info(log);
                if (job.JobDetailId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                JobDetail jobDetail = new JobDetail
                {
                    JobDetailId = job.JobDetailId,
                    JobTitle = job.JobTitle,
                    JobDescription = job.JobDescription,
                    CreatedBy = job.CreatedBy,
                    JobStatus = job.JobStatus,
                    NumberOfResources = job.NumberOfResources,
                    ExperienceFrom = job.ExperienceFrom,
                    ExperienceTo = job.ExperienceTo,
                    DesignationId = job.DesignationId,
                    CurrencyId = job.CurrencyId,
                    SalaryFrom = job.SalaryFrom,
                    SalaryTo = job.SalaryTo
                };
                CreateSuccessModel result =await jobDetailService.UpsertJobDetail(jobDetail, job.CityId, job.KeySkillId);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateJobDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To get a jobDetails by Id
        /// </summary>
        /// <param name="jobDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(getJobDetailList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetJobDetailsById")]
        public async Task<ActionResult> GetJobDetailsById(int jobDetailId,int candidateId)
        {
            try
            {
                if (jobDetailId == 0 || jobDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                getJobDetailList result =await jobDetailService.GetJobDetailList(jobDetailId,candidateId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {    
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobDetailsById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To list a Job details
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(JobDetailList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetJobDetails")]
        public async Task<ActionResult> GetJobDetails(int count,int offset, int companyId,string jobTitle,string jobStatus,decimal experienceFrom,decimal experienceTo,decimal salaryFrom,decimal salaryTo,int jobDetailId,int designationId,int curreyncyId)
        {
            try
            {
                if (offset == 0 || offset == null) { offset = 0; }
                if (count == 0 || count == null) { count = 10; }

                JobDetailList jobDetailList =await jobDetailService.GetJobDetails(count, offset,companyId, jobTitle, jobStatus, experienceFrom, experienceTo, salaryFrom, salaryTo, jobDetailId, designationId, curreyncyId);
                return Ok(jobDetailList);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }

        }
        /// <summary>
        /// To delete a job details
        /// </summary>
        /// <param name="jobDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("DeleteJobDetails")]
        public async Task<ActionResult> DeleteJobDetails(int jobDetailId)
        {
            try
            {
                if (jobDetailId == 0 || jobDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                SuccessModel result =await jobDetailService.DeleteJobDetails(jobDetailId);
                if (result.status =="Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteJobDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To get a jobs by search
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(JobDetailList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetJobsBySearch")]
        public async Task<ActionResult> GetJobsBySearch(int count, int offset,string searchLocations,string searchSkills, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            { 
                if (offset == 0 || offset == null) { offset = 0; }
                if (count == 0 || count == null) { count = 10; }
                SearchJobsList jobDetailList =await jobDetailService.GetJobsBySearch(count, offset,searchLocations,searchSkills, companyId, jobTitle, jobStatus, experienceFrom, experienceTo, salaryFrom, salaryTo, jobDetailId, designationId, curreyncyId);
                return Ok(jobDetailList);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetJobsBySearch", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To Get Candidate History
        /// </summary>
        [Authorize(Roles = "2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(GetCandidateHistoryList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetCandidateHistory")]
        public async Task<ActionResult> GetCandidateHistory(int userId)
        {
            try
            {
                if (userId == 0 || userId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "userId is required" }); }
                GetCandidateHistoryList result =await jobDetailService.GetCandidateHistory(userId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateHistory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(GetCandidateInterviewHistoryList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetCandidateRoundHistory")]
        public async Task<ActionResult> GetCandidateRoundHistory(int candidateId, int jobDetailId)
        {
            try
            {
                if (candidateId == 0 || candidateId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "userId is required" }); }
                if (jobDetailId == 0 || jobDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "userId is required" }); }
                GetCandidateInterviewHistoryList result = await jobDetailService.GetCandidateRoundHistory(candidateId, jobDetailId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateHistory", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a job status
        /// </summary>
        /// <param name="jobDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("UpdateJobStatus")]
        public async Task<ActionResult> UpdateJobStatus(UpdateJobStatus up)
        {
            try
            {
                if (up.JobDetailId == 0 || up.JobDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                if (string.IsNullOrEmpty(up.JobStatus)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobStatus is required" }); }
                 SuccessModel result = await jobDetailService.UpdateJobStatus(up.JobDetailId,up.JobStatus);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateJobStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
