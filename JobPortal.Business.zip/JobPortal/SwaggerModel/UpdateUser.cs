﻿using System;

namespace JobPortal.SwaggerModel
{
    public class UpdateUser
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; } 
        public string Address { get; set; }
        public int? CityId { get; set;}
        public int? StateId { get; set;}  
        public string UserStatus { get; set; }
        public string Gender { get; set; }
        public DateTime? Dob { get; set; }
        public string ProfileImage { get; set; }
        public string PanNumber { get; set; }  
        public string CountryCode { get; set; } 
        public string PhoneNumber { get; set; }
    }
}
