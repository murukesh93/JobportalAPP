﻿using JobPortal.Business.Model;

namespace JobPortal.Business.CustomModel
{
    public class LoginSuccess:ExceptionModel
    {
        public VwUser User { get; set; }
        public string Token { get; set; }
    }
}
