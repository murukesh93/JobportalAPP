﻿namespace JobPortal.SwaggerModel
{
    public class CreateMeeting
    {
        public string Topic { get; set ; }
        public int Type { get; set; }
        public string Start_time { get; set; }
        public int Duration { get; set; }
        public string Schedule_for { get; set; }
        public string Timezone     { get; set; }
        public string Agenda { get; set; }
    }
}
