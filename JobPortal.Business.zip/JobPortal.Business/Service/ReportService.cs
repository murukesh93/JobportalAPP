﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class ReportService : IReportService
    { 
        public async Task<ReportServiceList> GetAppliedJobs(int count, int offset, int roundDetailId, int userId, string Jobtitle, string firstName, string lastName,
             string email, string cityName, string stateName, int jobDetailId, string jobStatus, int companyId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("count", count));
                parameters.Add(new SqlParameter("offset", offset));
                parameters.Add(new SqlParameter("roundDetailId", roundDetailId));
                parameters.Add(new SqlParameter("userId", userId));
                parameters.Add(new SqlParameter("Jobtitle", Jobtitle));
                parameters.Add(new SqlParameter("firstName", firstName));
                parameters.Add(new SqlParameter("lastName", lastName));
                parameters.Add(new SqlParameter("email", email));
                parameters.Add(new SqlParameter("cityName", cityName));
                parameters.Add(new SqlParameter("stateName", stateName));
                parameters.Add(new SqlParameter("jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("companyId", companyId));
                parameters.Add(new SqlParameter("jobStatus", jobStatus));
                DataSet ds = Common.Common.GetResultSet("spGetAppliedJobsDetails", parameters);
                List<VWReportLIst> output = Common.Common.ToListof<VWReportLIst>(ds.Tables[1]);
                ReportServiceList reportServiceList = new ReportServiceList { Count = (int)ds.Tables[0].Rows[0][0], Data = output };
                return reportServiceList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<RoundStatusReportList> GetRoundsReport(int count, int offset, string userName, int roundDetailId, string roundStatus, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@jobStatus", jobStatus));
                parameters.Add(new SqlParameter("@experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("@companyId", companyId));
                parameters.Add(new SqlParameter("@experienceTo", experienceTo));
                parameters.Add(new SqlParameter("@userName", userName));
                parameters.Add(new SqlParameter("@roundStatus", roundStatus));
                parameters.Add(new SqlParameter("@roundDetailId", roundDetailId));
                parameters.Add(new SqlParameter("@salaryFrom", salaryFrom));
                parameters.Add(new SqlParameter("@salaryTo", salaryTo));
                parameters.Add(new SqlParameter("@jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("@currencyId", curreyncyId));
                parameters.Add(new SqlParameter("@designationId", designationId));
                DataSet ds = Common.Common.GetResultSet("spGetRoundsReport", parameters);
                List<VwGetRoundStatus> output = Common.Common.ToListof<VwGetRoundStatus>(ds.Tables[1]);
                RoundStatusReportList reportServiceList = new RoundStatusReportList { Count = (int)ds.Tables[0].Rows[0][0], Data = output };
                return reportServiceList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<RecruitedDetailsList> GetRecruitedDetails(int count, int offset,int userId, string selectedDate, int companyId, string company, string designation, string jobTitle, string keySkill, string userName, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, string jobSeekerStatus)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("count", count));
                parameters.Add(new SqlParameter("offset", offset));
                parameters.Add(new SqlParameter("selectedDate", selectedDate));
                parameters.Add(new SqlParameter("companyId", companyId));
                parameters.Add(new SqlParameter("company", company));
                parameters.Add(new SqlParameter("designationName", designation));
                parameters.Add(new SqlParameter("jobTitle", jobTitle));
                parameters.Add(new SqlParameter("keySkill", keySkill));
                parameters.Add(new SqlParameter("userName", userName));
                parameters.Add(new SqlParameter("salaryTo", salaryTo));
                parameters.Add(new SqlParameter("userId", userId));
                parameters.Add(new SqlParameter("salaryFrom", salaryFrom));
                parameters.Add(new SqlParameter("experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("experienceto", experienceTo));
                parameters.Add(new SqlParameter("jobSeekerStatus", jobSeekerStatus));
                DataSet ds = Common.Common.GetResultSet("spGetRecruitedDetails", parameters);
                List<VWRecruitedDetails> output = Common.Common.ToListof<VWRecruitedDetails>(ds.Tables[1]);
                RecruitedDetailsList recruitedDetailsList = new RecruitedDetailsList { Count = (int)ds.Tables[0].Rows[0][0], Data = output };
                return recruitedDetailsList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
