﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class UpdateMeetingList
    {
        public string MeetingId { get; set; }
        public string Topic { get; set; }
        public int Type { get; set; }
        public string Start_time { get; set; }
        public int Duration { get; set; }
        public string Schedule_for { get; set; }
        public string Timezone { get; set; }
        public string Password { get; set; }
        public string Agenda { get; set; }
    }
}
