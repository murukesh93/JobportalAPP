﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerDetail
    {
        public int JobSeekerId { get; set; }
        public int? UserId { get; set; }
        public decimal? WorkExperience { get; set; }
        public string ResumeUrl { get; set; }
        public string ResumeHeading { get; set; }
        public decimal? CurrentCtc { get; set; }
        public int? CurrencyId { get; set; }
        public int? NoticePeriod { get; set; }
        public decimal? ExpectedCtc { get; set; }
        public string PersonalInfo { get; set; }
        public string Payslip { get; set; }
        public int? DesignationId { get; set; }

        public virtual Currency Currency { get; set; }
        public virtual Designation Designation { get; set; }
        public virtual User User { get; set; }
    }
}
