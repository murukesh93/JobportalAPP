﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class ApplyJobMailList
    {
        public string createdBy { get; set; }
        public string jobTitle { get; set; }
        public string designationName { get; set; }


    }
}
