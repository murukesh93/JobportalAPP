﻿using System.Collections.Generic;

namespace JobPortal.SwaggerModel
{
    public class CreateJob
    {
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public int? CreatedBy { get; set; }
        public int? CompanyId { get; set; }
        public string JobStatus { get; set; }
        public int? NumberOfResources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public int? DesignationId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public List<int> CityId { get; set; }
        public List<int> KeySkillId { get; set; }
    }
}
