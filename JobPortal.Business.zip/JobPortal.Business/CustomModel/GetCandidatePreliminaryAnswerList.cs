﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class GetCandidatePreliminaryAnswerList
    {
        public List<GetCandidateAnswer> getCandidateAnswer { get; set; }
    }

    public class GetCandidateAnswer
    {
        public int? questionId { get; set; }
        public int? jobDetailId { get; set; }
        public string questionLable { get; set; } 
        public string questionType { get; set; }
        public string questionOptions { get; set; }
        public string answer { get; set; }
        public string questionDescription { get; set; }
        public int? sortOrder { get; set; }
        public bool? isActive { get; set; }
        public int? answerId { get; set; }
        public int? userId { get; set; }
        public string userAnswer { get; set; }


    }
}
