﻿namespace JobPortal.Business.CustomModel
{
    public class RoleList
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
