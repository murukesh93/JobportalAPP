﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
   public class JobPreliminaryService : IJobPreliminaryService
    {

        private readonly IEmailService emailService;
        private JobPortalContext dbContext;
        public JobPreliminaryService(JobPortalContext _db, IEmailService _emailService)
        { 
            dbContext = _db;
            emailService = _emailService;
        }

        public async Task<SuccessModel> SaveQuestions(List<JobPreliminaryList> jobPreliminaryLists)
        {
            SuccessModel result;
            await using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var e in jobPreliminaryLists)
                    {
                        if (e.QuestionId == 0)
                        {
                           await dbContext.JobPreliminaryQuestions.AddAsync(new JobPreliminaryQuestion
                            {
                                JobDetailId = e.JobDetailId,
                                QuestionLable = e.QuestionLable,
                                QuestionType = e.QuestionType,
                                QuestionOptions = e.QuestionOptions,
                                Answer = e.Answer,
                                QuestionDescription = e.QuestionDescription,
                                SortOrder = e.SortOrder,
                                IsActive = e.IsActive
                            });
                        }
                       else if (e.QuestionId > 0)
                        {
                            JobPreliminaryQuestion existingQuestion =await  dbContext.JobPreliminaryQuestions.FirstOrDefaultAsync(q => q.QuestionId == e.QuestionId);
                            existingQuestion.JobDetailId = e.JobDetailId;
                            existingQuestion.QuestionLable = e.QuestionLable;
                            existingQuestion.QuestionType = e.QuestionType;
                            existingQuestion.QuestionOptions = e.QuestionOptions;
                            existingQuestion.Answer = e.Answer;
                            existingQuestion.QuestionDescription = e.QuestionDescription;
                            existingQuestion.SortOrder = e.SortOrder;
                            existingQuestion.IsActive = e.IsActive;
                            dbContext.Update(existingQuestion);
                        }
                    }
                   await transaction.CommitAsync();
                   await dbContext.SaveChangesAsync();
                    result = new SuccessModel
                    {
                        message = "Record saved successfully",
                        status = "Success"
                    };
                    return result;
                }
                catch (Exception ex)
                {
                   await transaction.RollbackAsync();
                    result = new SuccessModel
                    {
                        message = ex.Message,
                        status = "Error"
                    };
                    return result;
                }
            }
        }
        public async Task<List<JobPreliminaryList>> GetJobPreliminaryQuestions(int jobDetailId)
        {
            try
            {
                List<JobPreliminaryList> jobPreliminaryLists =await dbContext.JobPreliminaryQuestions.Where(j => j.IsActive == true && j.JobDetailId == jobDetailId)
               .Select(j => new JobPreliminaryList
               {
                   QuestionId = j.QuestionId,
                   JobDetailId = j.JobDetailId,
                   QuestionLable = j.QuestionLable,
                   QuestionType = j.QuestionType,
                   QuestionOptions = j.QuestionOptions,
                   Answer = j.Answer,
                   QuestionDescription = j.QuestionDescription,
                   SortOrder = j.SortOrder,
                   IsActive = j.IsActive
               }).ToListAsync();
                return jobPreliminaryLists;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CreateSuccessModel> SaveAnswer(List<PreliminaryAnswersList> preliminaryAnswersLists, PreliminaryRoundDetail preliminaryRound)
        {
            CreateSuccessModel result = null;
            await using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var answer in preliminaryAnswersLists)
                    {
                        int answerCount =await dbContext.PreliminaryQuestionAnswers.Where(a => a.UserId == preliminaryRound.UserId && a.QuestionId == answer.QuestionId).CountAsync();

                        if (answerCount == 0)
                        {
                           await dbContext.PreliminaryQuestionAnswers.AddAsync(new PreliminaryQuestionAnswer
                            {
                                UserId = preliminaryRound.UserId,
                                QuestionId = answer.QuestionId,
                                AnswerId = answer.AnswerId,
                                UserAnswer = answer.UserAnswer
                            });
                            await dbContext.SaveChangesAsync();
                        }
                        else
                        {
                            PreliminaryQuestionAnswer existingPreliminaryQuestion =await dbContext.PreliminaryQuestionAnswers
                                .FirstOrDefaultAsync(a => a.QuestionId == answer.QuestionId && a.UserId == preliminaryRound.UserId);
                            existingPreliminaryQuestion.UserAnswer = answer.UserAnswer;
                        }
                    }
                    int roundDetailCount =await dbContext.PreliminaryRoundDetails
                        .Where(r => r.JobDetailId == preliminaryRound.JobDetailId && r.UserId == preliminaryRound.UserId).CountAsync();
                    if (roundDetailCount > 0)
                    {
                        PreliminaryRoundDetail existingPreliminaryRound =await dbContext.PreliminaryRoundDetails
                              .FirstOrDefaultAsync(r => r.JobDetailId == preliminaryRound.JobDetailId && r.UserId == preliminaryRound.UserId);
                        existingPreliminaryRound.RoundStatus = preliminaryRound.RoundStatus;
                        existingPreliminaryRound.ActionBy = preliminaryRound.ActionBy;
                        existingPreliminaryRound.Comments = preliminaryRound.Comments;
                        dbContext.Update(existingPreliminaryRound);
                    }
                    else
                    {
                        preliminaryRound.RoundStatus = "New";
                        preliminaryRound.ActionBy = null;
                        preliminaryRound.Comments = null;
                        await dbContext.PreliminaryRoundDetails.AddAsync(preliminaryRound);
                    }

                    ApplyJobMailList applyJobMailList =await (from a in dbContext.PreliminaryQuestionAnswers
                                                         join u in dbContext.JobPreliminaryQuestions on a.QuestionId equals u.QuestionId
                                                         join us in dbContext.JobDetails on u.JobDetailId equals us.JobDetailId
                                                         join i in dbContext.Designations on us.DesignationId equals i.DesignationId
                                                         join cb in dbContext.Users on us.CreatedBy equals cb.CreatedBy
                                                         where u.IsActive == true && cb.IsDeleted == false && us.IsDeleted == false
                                                         && i.IsDeleted == false
                                                         select new ApplyJobMailList
                                                        {
                                                            createdBy = cb.Email,
                                                            jobTitle = us.JobTitle,
                                                            designationName = i.DesignationName
                                                        }).FirstOrDefaultAsync();
                    if (applyJobMailList != null)
                    {
                        await emailService.ApplyJobMail(applyJobMailList.createdBy, applyJobMailList.jobTitle, applyJobMailList.designationName);
                    }
                   
                    await dbContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    result = new CreateSuccessModel
                    {
                        Id=preliminaryRound.RoundDetailId,
                        message = "Record Saved Successfully",
                        Status = "Success"
                    };
                    return result;
                }
                catch(Exception ex)
                {
                    await transaction.RollbackAsync();
                    result = new CreateSuccessModel
                    {
                        Id = preliminaryRound.RoundDetailId,
                        message = ex.InnerException.Message,
                        Status = "Error"
                    };
                    return result;
                }
            }
        }
        public async Task<CreateSuccessModel> UpdatePreliminaryStatus(PreliminaryRoundDetail preliminaryRound)
        {
            try
            {
                CreateSuccessModel result = null;
                PreliminaryRoundDetail existingpreliminaryRound =await dbContext.PreliminaryRoundDetails.FirstOrDefaultAsync(r => r.RoundDetailId == preliminaryRound.RoundDetailId);
                if (existingpreliminaryRound != null)
                {
                    existingpreliminaryRound.RoundStatus = preliminaryRound.RoundStatus;
                    existingpreliminaryRound.ActionBy = preliminaryRound.ActionBy;
                    existingpreliminaryRound.Comments = preliminaryRound.Comments;
                    dbContext.Update(existingpreliminaryRound);
                    var mailDetails =await (from a in dbContext.PreliminaryRoundDetails
                                       join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                       join c in dbContext.Users on a.UserId equals c.UserId
                                       where a.RoundDetailId == preliminaryRound.RoundDetailId
                                       select new
                                       {
                                           Email = c.Email,
                                           JobTitle = b.JobTitle
                                       }).ToArrayAsync();
                    string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\PreliminaryStatus.html";
                    StreamReader str = new StreamReader(FilePath);
                    string MailText = str.ReadToEnd();
                    str.Close();
                    if (preliminaryRound.RoundStatus == "Approved")
                    {
                        MailText = MailText.Replace("[Content]", $"Your profile successfully shortlisted the {mailDetails[0].JobTitle} and you are selected for the next round. Further information will be communicated. Stay connected and prepared. All the best");
                    }
                    else if (preliminaryRound.RoundStatus == "Rejected")
                    {
                        MailText = MailText.Replace("[Content]", $"Unfortunately, we are sorry to say you that you are rejected for the {mailDetails[0].JobTitle} you applied for. All the best for the next interviews.");
                    }
                    var sendEmail = Common.Common.SendEmail(mailDetails[0].Email, "Preliminary Round- Result", "Plain Text", MailText);
                    if (sendEmail.Result.status == "Success")
                    {
                        result = new CreateSuccessModel
                        {
                            Id = preliminaryRound.RoundDetailId,
                            Status = "Success",
                            message = "Record Updated Succesfully"
                        };
                    }
                    else
                    {
                        return new CreateSuccessModel { Status = "Error", message = sendEmail.Result.message };
                    }
                }
                else
                {
                    result = new CreateSuccessModel
                    {
                        Id = preliminaryRound.RoundDetailId,
                        Status = "Error",
                        message = "Invalid RoundDetailId"
                    };
                }
                 await  dbContext.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> SaveJobInterviewRounds(List<JobInterviewRoundList> jobInterviewRoundLists)
        {
            SuccessModel result = null;
            await using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    foreach (var rounds in jobInterviewRoundLists)
                    {
                        if (rounds.InterviewRoundId == 0)
                        {
                           await dbContext.JobInterviewRounds.AddAsync(new JobInterviewRound
                            {
                                JobDetailId = rounds.JobDetailId,
                                RoundName = rounds.RoundName,
                                RoundDescription = rounds.RoundDescription,
                                RoundOrder = rounds.RoundOrder,
                                IsActive = rounds.IsActive
                            });

                          await  dbContext.SaveChangesAsync();
                        }
                        else
                        {
                            JobInterviewRound existingInterviewRound =await dbContext.JobInterviewRounds
                                .FirstOrDefaultAsync(r => r.InterviewRoundId == rounds.InterviewRoundId && r.IsActive == true);
                            existingInterviewRound.RoundName = rounds.RoundName;
                            existingInterviewRound.JobDetailId = rounds.JobDetailId;
                            existingInterviewRound.RoundDescription = rounds.RoundDescription;
                            existingInterviewRound.RoundOrder = rounds.RoundOrder;
                            existingInterviewRound.IsActive = rounds.IsActive;
                            dbContext.Update(existingInterviewRound);
                        }
                    }
                    await transaction.CommitAsync();
                    await dbContext.SaveChangesAsync();
                    return result = new SuccessModel
                    {
                        status = "Success",
                        message = "Record Saved Succesfully"
                    };
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    return result = new SuccessModel
                    {
                        status = "Error",
                        message = ex.Message,
                    };
                }
            }
        }
        public async Task<VwGetJobInterviewRound> VwGetJobInterviewRound(int inverviewRoundId) 
        {
            try
            {
                VwGetJobInterviewRound result =await dbContext.VwGetJobInterviewRounds.FirstOrDefaultAsync(j => j.InterviewRoundId == inverviewRoundId);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<InterviewRoundList> interviewRoundList(int count, int offset, int interviewRoundId, string roundName, string roundDescription, int roundOrder, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@jobStatus", jobStatus));
                parameters.Add(new SqlParameter("@roundName", roundName));
                parameters.Add(new SqlParameter("@interviewRoundId", interviewRoundId));
                parameters.Add(new SqlParameter("@roundDescription", roundDescription));
                parameters.Add(new SqlParameter("@roundOrder", roundOrder));
                parameters.Add(new SqlParameter("@experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("@experienceTo", experienceTo));
                parameters.Add(new SqlParameter("@salaryFrom", salaryFrom));
                parameters.Add(new SqlParameter("@salaryTo", salaryTo));
                parameters.Add(new SqlParameter("@jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("@currencyId", curreyncyId));
                parameters.Add(new SqlParameter("@designationId", designationId));
                DataSet ds = Common.Common.GetResultSet("spGetJobInterviewRounds", parameters);
                List<VwGetJobInterviewRound> output = Common.Common.ToListof<VwGetJobInterviewRound>(ds.Tables[1]);
                InterviewRoundList interviewRoundList = new InterviewRoundList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return interviewRoundList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<AppliedUserList> GetJobAppliedUserList(int count, int offset, int companyId, string userName, string jobTitle, string email, string keySkills, string locations, string companyName, string roundStatus, decimal experienceFrom, decimal experienceTo)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@companyId", companyId));
                parameters.Add(new SqlParameter("@userName", userName));
                parameters.Add(new SqlParameter("@email", email));
                parameters.Add(new SqlParameter("@keySkills", keySkills));
                parameters.Add(new SqlParameter("@locations", locations));
                parameters.Add(new SqlParameter("@companyName", companyName));
                parameters.Add(new SqlParameter("@roundStatus", roundStatus));
                parameters.Add(new SqlParameter("@experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("@experienceTo", experienceTo));
                DataSet ds = Common.Common.GetResultSet("spGetAppliedUserList", parameters);
                List<VwGetAppliedUser> output = Common.Common.ToListof<VwGetAppliedUser>(ds.Tables[1]);
                AppliedUserList appliedUserList = new AppliedUserList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return appliedUserList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GetCandidateBySkillSetList> GetCandidateBySkillSet(int count, int offset,string userName, string preferedLocation, string keySkill, string designation)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@userName", userName));
                parameters.Add(new SqlParameter("@preferedLocation", preferedLocation));
                parameters.Add(new SqlParameter("@keySkill", keySkill));
                parameters.Add(new SqlParameter("@designation", designation));
                DataSet ds = Common.Common.GetResultSet("getCandidateBySkillset", parameters);
                List<VwGetCandidateBySkillSet> output = Common.Common.ToListof<VwGetCandidateBySkillSet>(ds.Tables[1]);
                GetCandidateBySkillSetList getCandidateBySkillSet = new GetCandidateBySkillSetList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return getCandidateBySkillSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetCandidatePreliminaryAnswerList> GetCandidatePreliminaryAnswer(int candidateId, int jobDetailId)
        {
            try
            {
                GetCandidatePreliminaryAnswerList candidatePreliminaryAnswerList = new GetCandidatePreliminaryAnswerList();
                candidatePreliminaryAnswerList.getCandidateAnswer = await (from a in dbContext.JobPreliminaryQuestions
                                                                           join b in dbContext.PreliminaryQuestionAnswers.Where(a => a.UserId == candidateId) on a.QuestionId equals b.QuestionId
                                                                           into gx
                                                                           from x in gx.DefaultIfEmpty()
                                                                           where a.JobDetailId == jobDetailId && a.IsActive==true
                                                                           select new GetCandidateAnswer
                                                                                 {
                                                                                     jobDetailId = a.JobDetailId,
                                                                                     questionId = a.QuestionId,
                                                                                     questionLable = a.QuestionLable,
                                                                                     questionType = a.QuestionType,
                                                                                     questionOptions = a.QuestionOptions,
                                                                                     answer = a.Answer,
                                                                                     questionDescription = a.QuestionDescription,
                                                                                     sortOrder = a.SortOrder,
                                                                                     isActive = a.IsActive,
                                                                                     answerId = x.AnswerId,
                                                                                     userId = x.UserId, 
                                                                                     userAnswer = x.UserAnswer ,
                                                                                 }).ToListAsync();
                return candidatePreliminaryAnswerList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
