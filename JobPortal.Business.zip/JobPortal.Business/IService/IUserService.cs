﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IUserService
    {
        Task<UserList> GetUserList(int count, int offset, string firstName, string lastName, string email, string phoneNumber, int companyId,string companyName, int roleId, string roleName, string userStatus);
        Task<CreateSuccessModel> UpsertUser(User user,int companyId);
        Task<SuccessModel> DeleteUser(int userId);
        Task<VwUser> GetUser(int userId);
        Task<SuccessModel> UpdateUserStatus(int userId, string userStatus , string comments);
        Task<SuccessModel> UpdatePassword(UpdatePassword model);
        Task<SuccessModel> verifyPAN(string panNumber, string name);
    }
}
