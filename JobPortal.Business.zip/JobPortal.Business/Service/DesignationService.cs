﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class DesignationService : IDesignationService
    {
        private JobPortalContext dbContext;
        public DesignationService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<CreateSuccessModel> SaveDesignation(Designation designation)
        {
            try
            {
                CreateSuccessModel result;
                Designation existingDesignation =await dbContext.Designations.FirstOrDefaultAsync(c => c.DesignationId == designation.DesignationId);

                if (existingDesignation != null)
                {
                    int designationCount =await dbContext.Designations.Where(c => c.DesignationName == designation.DesignationName && c.IsDeleted == false && c.DesignationId!=existingDesignation.DesignationId).CountAsync();
                    if (designationCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = designation.DesignationId,
                            message = "Designation already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    else
                    {
                        existingDesignation.DesignationName = designation.DesignationName;
                        existingDesignation.IsDeleted = designation.IsDeleted;
                        dbContext.Update(existingDesignation);
                       await dbContext.SaveChangesAsync();
                    }

                }
                else
                {
                    int designationCount =await dbContext.Designations.Where(c => c.DesignationName == designation.DesignationName && c.IsDeleted == false).CountAsync();
                    if (designationCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = designation.DesignationId,
                            message = "Designation already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    designation.IsDeleted = false;
                   await dbContext.Designations.AddAsync(designation);
                }
                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = designation.DesignationId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex.InnerException;
            }
        }

        public async Task<DesignationList> GetDesignationById(int DesignationId)
        {
            try
            {
                DesignationList designation =await dbContext.Designations.Select(d => new DesignationList { DesignationId = d.DesignationId, Designation1 = d.DesignationName, IsDeleted = d.IsDeleted })
               .FirstOrDefaultAsync(d => d.DesignationId == DesignationId && d.IsDeleted == false);
                return designation;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
