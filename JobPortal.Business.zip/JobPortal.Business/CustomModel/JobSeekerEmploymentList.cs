﻿using System;

namespace JobPortal.Business.CustomModel
{
    public class JobSeekerEmploymentList
    {
        public int EmployementDetailId { get; set; }
        public int? UserId { get; set; }
        public string OrganizationName { get; set; }
        public int? DesignationId { get; set; }
        public string DesignationName { get; set; }
        public bool? IsCurrentCompany { get; set; } 
        public bool? IsDeleted { get; set; }
        public DateTime? WorkingFrom { get; set; } 
        public DateTime? WorkingTo { get; set; }
        public string JobDescribtion { get; set; }
    }
}
