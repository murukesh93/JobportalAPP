﻿namespace JobPortal.Business.CustomModel
{
    public class VwGetReportStatus
    {
    }
}