﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class RecruitedJobSeekerDetail
    {
        public int RecruitedDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public int? UserId { get; set; }
        public int? AppointedBy { get; set; }
        public DateTime? JoinDate { get; set; }
        public decimal? SalaryPerMonth { get; set; }
        public int? CurrencyId { get; set; }
        public string AppoinmentCopy { get; set; }
        public string Comments { get; set; }
        public string TermsandConditions { get; set; }
        public string JobSeekerStatus { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime SelectedDate { get; set; }
        public int? SelectedLocationId { get; set; }

        public virtual User AppointedByNavigation { get; set; }
        public virtual Currency Currency { get; set; }
        public virtual JobDetail JobDetail { get; set; }
        public virtual City SelectedLocation { get; set; }
        public virtual User User { get; set; }
    }
}
