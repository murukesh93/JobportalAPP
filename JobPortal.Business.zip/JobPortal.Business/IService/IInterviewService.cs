﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IInterviewService
    {
       Task<CreateSuccessModel> UpsertInterview(ScheduleInterview scheduleInterview, string topic,int type,string schedule_For,string timezone,string agenda);
       Task<VwGetScheduleInterview> GetScheduleInterviewById(int scheduleId);
       Task<ScheduleInterviewList>GetInterviewDetails(int count, int offset, string jobTitle, int jobDetailId, string userName, int interviewRoundId, int userId, int interviewerId, int scheduleBy, string interviewStartDateTime, string interviewEndDateTime, string schedulerName, string interviewerName, string interviewStatus, int roundOrder, string roundName, string interviewResult, string communicationChannel);
       Task<CreateSuccessModel> UpdateInterviewStatus(ScheduleInterview scheduleInterview,int ScheduleId,string InterviewStatus,string InterviewResult,string Feedback);

    }
    
}  
