﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobInterviewRound
    {
        public JobInterviewRound()
        {
            ScheduleInterviews = new HashSet<ScheduleInterview>();
        }

        public int InterviewRoundId { get; set; }
        public int? JobDetailId { get; set; }
        public string RoundName { get; set; }
        public string RoundDescription { get; set; }
        public int? RoundOrder { get; set; }
        public bool? IsActive { get; set; }

        public virtual JobDetail JobDetail { get; set; }
        public virtual ICollection<ScheduleInterview> ScheduleInterviews { get; set; }
    }
}
