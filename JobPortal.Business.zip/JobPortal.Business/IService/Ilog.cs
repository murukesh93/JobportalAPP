﻿using JobPortal.Business.CustomModel;

namespace JobPortal.Business.IService
{

        public interface ILog
        {
        void Info(LogStatus logStatus);
        void Warning(string message);
        void Debug(string message);
        void Error(ErrorLogStatus logStatus);
    }
    
}
