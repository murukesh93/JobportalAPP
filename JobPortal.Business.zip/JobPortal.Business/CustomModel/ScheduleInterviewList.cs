﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class ScheduleInterviewList
    {
        public List<VwGetScheduleInterview> data { get; set; }
        public int count { get; set; }
        public bool isSelected { get; set; }
    }
}
