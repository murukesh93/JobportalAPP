using System.Configuration;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using JobPortal.Business.Common;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.Business.Service;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using NLog;

namespace JobPortal
{
    public class Startup
    {
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            LogManager.LoadConfiguration(System.String.Concat(Directory.GetCurrentDirectory(), "/nlog.config"));
            Configuration = configuration;
        }

       
        public IConfiguration Configuration { get; } 
     
        public void ConfigureServices(IServiceCollection services)
        {

            //Add Swagger relates setting  
            services.AddSwaggerGen(swagger =>
            {
                swagger.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Job Portal API",
                    Version = "v1.1",
                    Description = "Job Portal Web API",
                });

                // To Enable authorization using Swagger (JWT)  
                swagger.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                }); 

                swagger.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                          new OpenApiSecurityScheme
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {}
                    }
                });
            });


            services.AddAuthentication(option =>
            {
                option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = false,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"])) //Configuration["JwtToken:SecretKey"]  
                };
            });

           

            services.AddDbContext<JobPortalContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)); 
            services.AddTransient<ICommonService, CommonService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IKeySkillService, KeySkillCategoryService>();
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<IJobPreliminaryService, JobPreliminaryService>();
            services.AddTransient<IUploadService, UploadService>();
            services.AddTransient<IJobDetailService, JobDetailService>();
            services.AddTransient<IInterviewService, InterviewService> ();
            services.AddTransient<IJobSeekerService, JobSeekerService>();
            services.AddTransient<IStateService, StateService>();
            services.AddTransient<IDesignationService, DesignationService>();
            services.AddTransient<IDashboardService, DashboardService>();
            services.AddTransient<IReportService,ReportService>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient< IZoomService, ZoomService>();
            services.AddSingleton<ILog, LogNLog>();
            services.AddTransient<ICityService, CityService>();

            string[] Orgins = Configuration["Orgins"].ToString().Split(",");

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    builder =>
                    {
                        builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                    });

            });

            //services.AddCors(options =>
            //{
            //    options.AddPolicy(name: MyAllowSpecificOrigins,
            //                      builder =>
            //                      {
            //                          builder.WithOrigins(Orgins)
            //                          .AllowAnyHeader()
            //                          .AllowAnyMethod();
            //                      });
            //});

            services.AddControllers();
            services.AddTransient<ICompanyService, CompanyService>();
        } 
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.Use(async (context, next) => {
            string authHeader = context.Request.Headers["Authorization"];
                
                if (authHeader!=null && authHeader != "")
                {
                    authHeader = authHeader.Replace("Bearer ", "").Trim();
                    context.Request.Headers["Authorization"] = "Bearer "+Common.DecryptData(authHeader);
                }
               

                await next.Invoke();
         
        });
            if (env.IsDevelopment())
            {
                 app.UseDeveloperExceptionPage();
            }

            if (env.IsProduction())
            {
             
            }
            app.UseStatusCodePages(async context =>
            {
                if (context.HttpContext.Request.Path.StartsWithSegments("/api"))
                {
                    if (!context.HttpContext.Response.ContentLength.HasValue || context.HttpContext.Response.ContentLength == 0)
                    {
                        context.HttpContext.Response.StatusCode = 401;
                    }
                }
            });

            app.UseHttpsRedirection(); 
            app.UseRouting();

            //app.UseCors();
            app.UseCors("AllowAll");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Job Portal API");
            });
        }
    }
}
