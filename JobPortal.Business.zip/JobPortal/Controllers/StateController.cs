﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly IStateService stateService;
        private readonly ILog logger;
        public StateController(IStateService _stateService, ILog _log)
        {
            stateService = _stateService;
            logger = _log;
        }

        /// <summary>
        ///  To Save a State
        /// </summary>
        /// <param name="saveState"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveState")]
        public async Task<ActionResult> SaveState(SaveState saveState)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveState", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(saveState) };
                logger.Info(log);
                if (string.IsNullOrEmpty(saveState.StateName)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "stateName is Required!" }); }
                State stateModel = new State
                {
                    StateId = saveState.StateId,
                    StateName = saveState.StateName,
                    IsActive = saveState.IsActive,
                };
                CreateSuccessModel result =await stateService.SaveState(stateModel);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveState", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Get a StateById
        /// </summary>
        /// <param name="stateId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpGet]
        [ProducesResponseType(typeof(StateList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetStateById")]
        public async Task<ActionResult> GetStateById(int stateId)
        {
            try
            {

                var routeName = ControllerContext.ActionDescriptor.ActionName;
                if (stateId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "StateId is Required!" }); }
                StateList result =await stateService.GetStateById(stateId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel successModel = new SuccessModel { status = "Error", message = "No record found" };
                    return StatusCode((int)HttpStatusCode.Forbidden, successModel);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetStateById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
