﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwGetCandidateBySkillSet
    {
        public int JobSeekerId { get; set; }
        public int? UserId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? WorkExperience { get; set; }
        public string ResumeHeading { get; set; }
        public string ResumeUrl { get; set; }
        public decimal? CurrentCtc { get; set; }
        public int? DesignationId { get; set; }
        public int? NoticePeriod { get; set; }
        public string PersonalInfo { get; set; }
        public string Payslip { get; set; }
        public decimal? ExpectedCtc { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string UserStatus { get; set; }
        public string Gender { get; set; }
        public string ProjectDetails { get; set; }
        public string EducationDetails { get; set; }
        public string EmployementDetails { get; set; }
        public string KeySkills { get; set; }
        public string PreferedLocations { get; set; }
        public string DesignationName { get; set; }
        public string CurrencyName { get; set; }
    }
}
