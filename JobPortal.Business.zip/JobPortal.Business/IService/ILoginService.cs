﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface ILoginService
    {
        Task<LoginSuccess> Login(Login model);
        Task<LoginProviderSuccess> LoginProvider(LoginProvider login,string email,int roleId);

    }
}
