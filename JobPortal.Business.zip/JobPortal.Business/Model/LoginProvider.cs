﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class LoginProvider
    {
        public int LoginProviderId { get; set; }
        public string LoginProviderType { get; set; }
        public string LoginProviderKey { get; set; }
        public int? UserId { get; set; }

        public virtual User User { get; set; }
    }
}
