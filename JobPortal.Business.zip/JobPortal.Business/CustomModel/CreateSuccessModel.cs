﻿namespace JobPortal.Business.CustomModel
{
    public class CreateSuccessModel
    {
        public string message { get; set; }
        public int Id { get; set; } 
        public string Status { get; set; }
    }
}
