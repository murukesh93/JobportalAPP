﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using Newtonsoft.Json;
using NLog;

namespace JobPortal.Business.Service
{
    public class LogNLog : ILog
    {
        private static NLog.ILogger logger = LogManager.GetCurrentClassLogger();

        public LogNLog()
        {

        }

        public void Info(LogStatus logStatus)
        {
            var logResult = JsonConvert.SerializeObject(logStatus);
            logger.Info(logResult);
        }

        public void Warning(string message)
        {
            logger.Warn(message);
        }

        public void Debug(string message)
        {
            logger.Debug(message);
        }

        public void Error(ErrorLogStatus logStatus)
        {
            var logResult = JsonConvert.SerializeObject(logStatus);
            logger.Error(logResult);
        }
    }
}
