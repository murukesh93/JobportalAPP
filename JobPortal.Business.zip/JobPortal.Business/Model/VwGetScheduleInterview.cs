﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwGetScheduleInterview
    {
        public int ScheduleId { get; set; }
        public int? InterviewRoundId { get; set; }
        public int? UserId { get; set; }
        public string UserName { get; set; }
        public DateTime? InterviewStartDateTime { get; set; }
        public DateTime? InterviewEndDateTime { get; set; }
        public int? ScheduledBy { get; set; }
        public string SchedulerName { get; set; }
        public int? Interviewer { get; set; }
        public string InterviewerName { get; set; }
        public string CommunicationChannel { get; set; }
        public string InterviewStatus { get; set; }
        public int? JobDetailId { get; set; }
        public string MeetingId { get; set; }
        public string MeetingStatus { get; set; }
        public string MeetingUrl { get; set; }
        public int? ZoomMeetingId { get; set; }
        public string InterviewResult { get; set; }
        public string Feedback { get; set; }
        public string RoundName { get; set; }
        public string RoundDescription { get; set; }
        public int? RoundOrder { get; set; }
        public string CompanyName { get; set; }
        public int? CompanyId { get; set; }
        public string CityName { get; set; }
        public string CommunicationNumber { get; set; }
        public int IsSelected { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
    }
}
