﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Business.Service
{
   public class EmailService : IEmailService
    {
        private JobPortalContext dbContext;
        public EmailService(JobPortalContext _db)
        {
            dbContext = _db;
        }

        public async Task<SuccessModel> GenerateOtp(Otpvalue otpvalueModel, string email, string otpType)
        {
            try
            {
                SuccessModel result;
                int emailCount = await dbContext.Users.Where(u => u.Email == email && u.IsDeleted == false).CountAsync();
                if (emailCount <= 0)
                {
                    result = new SuccessModel
                    {

                        message = "Invalid User",
                        status = "Error"
                    };
                    return result;
                }
                Random value = new Random();
                string otpValue = (value.Next(10000, 99999)).ToString();
                string subject = "OTP ";
                string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\sendOTP.html";
                StreamReader str = new StreamReader(FilePath);
                string MailText = str.ReadToEnd();
                str.Close();
                MailText = MailText.Replace("[otp]", otpValue);
                var sendEmail =await Common.Common.SendEmail(email, subject, otpValue, MailText);
                if (sendEmail.status == "Success")
                {
                    otpvalueModel.OtpText = otpValue;
                    await dbContext.Otpvalues.AddAsync(otpvalueModel);
                    await dbContext.SaveChangesAsync();

                    result = new SuccessModel
                    {
                        message = "OTP sent successfully",
                        status = "Success"
                    };
                    return result;
                }
                else
                {
                    return sendEmail;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       
        public async Task<SuccessModel> UpdatePasswordByOtp(UpdatePasswordByOtp model, Otpvalue otpvalueMOdel, User userModel)
        {
            try
            {
                SuccessModel result;
                DateTime ExpriryDateTime = DateTime.Now;
                DateTime CurrentDBDateTime =await Common.Common.GetCurrentDBDateTime();
                Otpvalue exsitingOtp =await dbContext.Otpvalues.FirstOrDefaultAsync(u => u.OtpText == model.OTP && u.Source == model.Email && u.Status == "Sent" && u.OtpType == "Forget Password");
                if (exsitingOtp != null)
                {
                    ExpriryDateTime = exsitingOtp.CreatedDate.AddMinutes(10);
                }
                if (exsitingOtp == null)
                {
                    result = new SuccessModel
                    {
                        message = "Invalid OTP",
                        status = "Error"
                    };
                    return result;
                }
                else if (CurrentDBDateTime <= ExpriryDateTime)
                {
                    exsitingOtp.Status = "Verified";
                    dbContext.Update(exsitingOtp);
                    User exsistingUser = dbContext.Users.FirstOrDefault(u => u.Email == model.Email);
                    exsistingUser.Password = Common.Common.EncryptData(userModel.Password);
                    dbContext.Update(exsistingUser);
                    await dbContext.SaveChangesAsync();

                    result = new SuccessModel
                    {
                        message = "Password Changed Successfully",
                        status = "Success"
                    };

                    return result;

                }
                else
                {
                    result = new SuccessModel
                    {
                        message = "Your OTP is expired.Please try again",
                        status = "Error"
                    };
                    return result;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
 
        }

        public async Task<SuccessModel> PasswordByEmail(User user)
         {
            try
            {
                SuccessModel result;
                var appName = Common.Common.GetConnectionString("AppDetails", "AppName");
                var appUrl = Common.Common.GetConnectionString("AppDetails", "AppUrl");
                string subject = "New Account SignUp ";
                string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\signin.html";
                StreamReader str = new StreamReader(FilePath);
                string MailText = str.ReadToEnd();
                str.Close();
                MailText = MailText.Replace("{{{email}}}", user.Email).Replace("{{{password}}}", Common.Common.DecryptData(user.Password)).Replace("{{{account}}}", appName).Replace("{{{link}}}", appUrl);
                var sendEmail =await Common.Common.SendEmail(user.Email, subject, user.Password, MailText);
                if (sendEmail.status == "Success")
                {

                    result = new SuccessModel
                    {

                        message = "Password Sent Successfully",
                        status = "Success"
                    };
                    return result;
                }
                else
                {
                    return sendEmail;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> UserStatusEmail(string email, string userStatus , string comments)
        {
            try
            {
                SuccessModel result = null;
                var appName = Common.Common.GetConnectionString("AppDetails", "AppName");
                string subject = "New Status ";
                if (userStatus == "Rejected")
                {
                    string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\userStatusRejected.html";
                    StreamReader str = new StreamReader(FilePath);
                    string MailText = str.ReadToEnd();
                    str.Close();
                    MailText = MailText.Replace("{{{appName}}}", appName).Replace("{{{commentStatus}}}", userStatus);
                    var sendEmail =await Common.Common.SendEmail(email, subject, userStatus, MailText);
                    if (sendEmail.status == "Success")
                    {

                        result = new SuccessModel
                        {

                            message = "Status Mail Sent Successfully",
                            status = "Success"
                        };
                        return result;
                    }
                    else
                    {
                        return sendEmail;
                    }

                }
                else
                {
                    string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\userStatus.html";
                    StreamReader str = new StreamReader(FilePath);
                    string MailText = str.ReadToEnd();
                    str.Close();
                    MailText = MailText.Replace("{{{appName}}}", appName).Replace("{{{commentStatus}}}", comments);
                    var sendEmail =await Common.Common.SendEmail(email, subject, userStatus, MailText);
                    if (sendEmail.status == "Success")
                    {
                        result = new SuccessModel
                        {
                            message = "Status Mail Sent Successfully",
                            status = "Success"
                        };
                        return result;
                    }
                    else
                    {
                        return sendEmail;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<SuccessModel> ApplyJobMail(string createdBy, string jobTitle, string designationName)
        {
            try
            {
                SuccessModel result = null;
                var appName = Common.Common.GetConnectionString("AppDetails", "AppName");
                string subject = "New Status ";

                string FilePath = Directory.GetCurrentDirectory() + "\\EmailTemplates\\JobApply.html";
                StreamReader str = new StreamReader(FilePath);
                string MailText = str.ReadToEnd();
                str.Close();
                MailText = MailText.Replace("{{{jobName}}}", jobTitle).Replace("{{{Post}}}", designationName);
                var sendEmail =await Common.Common.SendEmail(createdBy, subject, jobTitle, MailText);
                if (sendEmail.status == "Success")
                {
                    result = new SuccessModel
                    {

                        message = "Status Mail Sent Successfully",
                        status = "Success"
                    };
                    return result;
                }
                else
                {
                    return sendEmail;
                }
            }
            catch (Exception ex)
            {
                throw ex; 
            }
           
         }
     }
 }


