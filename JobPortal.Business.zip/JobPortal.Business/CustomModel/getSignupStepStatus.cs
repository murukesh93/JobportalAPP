﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class GetSignupStepStatus
    {
        public Boolean ProfileInfo { get; set; }
        public Boolean EmployementInfo { get; set; }
        public Boolean EducationInfo { get; set; }
        public Boolean ProjectInfo { get; set; }
        public Boolean JobInfo { get; set; }
    }
} 
