﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.SwaggerModel
{
    public class UpdateInterviewStatus
    {
        public int ScheduleId { get; set; }
        public string InterviewStatus { get; set; }
        public string Feedback { get; set; }
        public string InterviewResult { get; set; }

    }
}
