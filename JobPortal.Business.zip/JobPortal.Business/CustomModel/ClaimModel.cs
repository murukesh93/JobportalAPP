﻿namespace JobPortal.Business.CustomModel
{
    public class ClaimModel
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
    }
}
