﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class JobSeekerController : ControllerBase
    {
        private readonly IJobSeekerService jobSeekerService;
        private readonly ILog logger;
        public JobSeekerController(IJobSeekerService _jobSeekerService, ILog _logger)
        {
            jobSeekerService = _jobSeekerService;
            logger = _logger;
        }
        /// <summary>
        /// To save a JobSeeker Details
        /// </summary>
        /// <param name="createJobSeeker"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobSeekerDetails")]
        public async Task<ActionResult> SaveJobSeekerDetails(CreateJobSeeker createJobSeeker)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobSeekerDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(createJobSeeker) };
                logger.Info(log);
                if (createJobSeeker.UserId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                if (createJobSeeker.DesignationId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Designation is required" }); }
                if (createJobSeeker.CurrencyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CurrencyId is required" }); }
                if (string.IsNullOrEmpty(createJobSeeker.ResumeUrl)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "ResumeUrl is required" }); }
                JobSeekerDetail jobSeekerDetail = new JobSeekerDetail
                {
                    JobSeekerId = 0,
                    UserId = createJobSeeker.UserId,
                    WorkExperience = createJobSeeker.WorkExperience,
                    ResumeUrl = createJobSeeker.ResumeUrl,
                    ResumeHeading = createJobSeeker.ResumeHeading,
                    CurrentCtc = createJobSeeker.CurrentCtc,
                    CurrencyId = createJobSeeker.CurrencyId,
                    NoticePeriod = createJobSeeker.NoticePeriod,
                    ExpectedCtc = createJobSeeker.ExpectedCtc,
                    PersonalInfo = createJobSeeker.PersonalInfo,
                    Payslip = createJobSeeker.Payslip,
                    DesignationId = createJobSeeker.DesignationId
                };
                CreateSuccessModel result =await jobSeekerService.SaveJobSeekerDetails(jobSeekerDetail);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobSeekerDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"),Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To save a Job seeker key skills
        /// </summary>
        /// <param name="jobSeekerKeySkills"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobSeekerKeySkills")]
        public async Task<ActionResult> SaveJobSeekerKeySkills(List<JobSeekerSkillList> jobSeekerKeySkills)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobSeekerKeySkills", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobSeekerKeySkills) };
                logger.Info(log);
                SuccessModel result = await jobSeekerService.SaveJobSeekerKeySkills(jobSeekerKeySkills);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobSeekerKeySkills", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To save a Jobseeker Employment details
        /// </summary>
        /// <param name="jobSeekerEmploymentLists"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobSeekerEmploymentDetails")]
        public async Task<ActionResult> SaveJobSeekerEmploymentDetails(List<JobSeekerEmploymentList> jobSeekerEmploymentLists)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobSeekerEmploymentDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobSeekerEmploymentLists) };
                logger.Info(log);
                SuccessModel result = await jobSeekerService.SaveJobSeekerEmploymentDetails(jobSeekerEmploymentLists);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobSeekerEmploymentDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To delete a JobSeeker Employment Details
        /// </summary>
        /// <param name="employementDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("DeleteSeekerEmploymentDetails")]
        public async Task<ActionResult> DeleteSeekerEmploymentDetails(int employementDetailId)
        {
            try
            {

                SuccessModel result = await jobSeekerService.DeleteSeekerEmploymentDetails(employementDetailId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteSeekerEmploymentDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To save a JobSeeker Education Details
        /// </summary>
        /// <param name="jobSeekerEducationLists"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobSeekerEducationDetails")]
        public async Task<ActionResult> SaveJobSeekerEducationDetails(List<JobSeekerEducationList> jobSeekerEducationLists)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobSeekerEducationDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobSeekerEducationLists) };
                logger.Info(log);
                SuccessModel result = await jobSeekerService.SaveJobSeekerEducationDetails(jobSeekerEducationLists);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobSeekerEducationDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To delete a JobSeeker Education Details
        /// </summary>
        /// <param name="educationDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("DeleteSeekerEducationDetails")]
        public async Task<ActionResult> DeleteSeekerEducationDetails(int educationDetailId)
        {
            try
            {
                SuccessModel result = await jobSeekerService.DeleteSeekerEducationDetails(educationDetailId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteSeekerEducationDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To save a JobSeeker project details
        /// </summary>
        /// <param name="jobSeekerProjectLists"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveJobSeekerProjectDetails")]
        public async Task<ActionResult> SaveJobSeekerProjectDetails(List<JobSeekerProjectList> jobSeekerProjectLists)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveJobSeekerProjectDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(jobSeekerProjectLists) };
                logger.Info(log);
                SuccessModel result = await jobSeekerService.SaveJobSeekerProjectDetails(jobSeekerProjectLists);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveJobSeekerProjectDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Delete a JobSeeker Project Details
        /// </summary>
        /// <param name="projectDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("DeleteSeekerProjectDetails")]
        public async Task<ActionResult> DeleteSeekerProjectDetails(int projectDetailId)
        {
            try
            {
                SuccessModel result = await jobSeekerService.DeleteSeekerProjectDetails(projectDetailId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteSeekerProjectDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Save a JobSeeker Prefered Work Locations
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        [Authorize(Roles = "4")]
        [HttpPost]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SavePreferedLocations")]
        public async Task<ActionResult> SavePreferedLocations(CreatePreferedLocation location)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SavePreferedLocations", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(location) };
                logger.Info(log);
                SuccessModel result = await jobSeekerService.SavePreferedLocations(location.cityId, location.userId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SavePreferedLocations", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a candidate details by userId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(CandidateList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetCandidateDetails")]
        public async Task<ActionResult> GetCandidateDetails(int userId)
        {
            try
            {
                if (userId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                CandidateList result =await jobSeekerService.GetCandidateDetails(userId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To save a Recruited JobSeeker Details
        /// </summary>
        /// <param name="recruitedDetails"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveRecruitedJobSeekerDetails")]
        public async Task<ActionResult> SaveRecruitedJobSeekerDetails(CreateRecruitedDetails recruitedDetails)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveRecruitedJobSeekerDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(recruitedDetails) };
                logger.Info(log);
                if (recruitedDetails.CurrencyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "CurrencyId is required" }); }
                if (recruitedDetails.AppointedBy == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "AppointedBy is required" }); }
                if (recruitedDetails.JobDetailId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobDetailId is required" }); }
                if (recruitedDetails.UserId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                RecruitedJobSeekerDetail recruitedJobSeekerDetail = new RecruitedJobSeekerDetail
                {
                    RecruitedDetailId = 0,
                    JobDetailId = recruitedDetails.JobDetailId,
                    UserId = recruitedDetails.UserId,
                    SelectedDate=recruitedDetails.SelectedDate,
                    AppoinmentCopy = recruitedDetails.AppoinmentCopy,
                    AppointedBy = recruitedDetails.AppointedBy,
                    JoinDate = recruitedDetails.JoinDate,
                    SalaryPerMonth = recruitedDetails.SalaryPerMonth,
                    CurrencyId = recruitedDetails.CurrencyId,
                    Comments = recruitedDetails.Comments,
                    TermsandConditions = recruitedDetails.TermsandConditions,
                    JobSeekerStatus = "New",
                    SelectedLocationId = recruitedDetails.SelectedLocationId,
                    IsDeleted = false
                };
                CreateSuccessModel result =await jobSeekerService.UpsertRecruitedDetails(recruitedJobSeekerDetail);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveRecruitedJobSeekerDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.InnerException.Message });
            }
        }

        /// <summary>
        /// To update a Recruited JobSeeker Details
        /// </summary>
        /// <param name="recruitedDetails"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("UpdateRecruitedDetails")]
        public async Task<ActionResult> UpdateRecruitedDetails(UpdateRecruitedDetails recruitedDetails)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateRecruitedDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(recruitedDetails) };
                logger.Info(log);
                if (recruitedDetails.RecruitedDetailId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "RecruitedDetailId is requrired" }); }
                RecruitedJobSeekerDetail recruitedJobSeekerDetail = new RecruitedJobSeekerDetail
                {
                    RecruitedDetailId = recruitedDetails.RecruitedDetailId,
                    UserId = recruitedDetails.UserId,
                    CurrencyId = recruitedDetails.CurrencyId,
                    SelectedDate = DateTime.Now,
                    AppoinmentCopy = recruitedDetails.AppoinmentCopy,
                    JobDetailId = recruitedDetails.JobDetailId,
                    JobSeekerStatus = recruitedDetails.JobSeekerStatus,
                    JoinDate = recruitedDetails.JoinDate, 
                    AppointedBy = recruitedDetails.AppointedBy,
                    SalaryPerMonth = recruitedDetails.SalaryPerMonth,
                    Comments = recruitedDetails.Comments,
                    TermsandConditions = recruitedDetails.TermsandConditions
                };
                CreateSuccessModel result =await jobSeekerService.UpsertRecruitedDetails(recruitedJobSeekerDetail);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateRecruitedDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error=ex.Message};
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.InnerException.Message });
            }
        }

        /// <summary>
        /// To get a Recruited JobSeeker DetailsById
        /// </summary>
        /// <param name="recruitedDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3,4")]
        [HttpGet]
        [ProducesResponseType(typeof(RecruitedJobSeekerList),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("GetRecruitedJobSeekerDetailsById")]
        public async Task<ActionResult> GetRecruitedJobSeekerDetailsById(int recruitedDetailId)
        {
            try
            {
                RecruitedJobSeekerList result = await jobSeekerService.GetRecruitedJobSeekerDetailsById(recruitedDetailId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetRecruitedJobSeekerDetailsById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Delete a Recruited Jobseeker Detailss
        /// </summary>
        /// <param name="recruitedDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("DeleteRecruitedJobSeekerDetails")]
        public async Task<ActionResult> DeleteRecruitedJobSeekerDetails(int recruitedDetailId)
        {
            try
            {
                SuccessModel result =await jobSeekerService.DeleteRecruitedJobSeekerDetails(recruitedDetailId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch(Exception ex)
            {

                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteRecruitedJobSeekerDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }


        /// <summary>
        /// To update a recruited user detail status
        /// </summary>
        /// <param name="RecruitedDetailId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3")]
        [HttpPut]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("UpdateRecruitedDetailStatus")]
        public async Task<ActionResult> UpdateRecruitedDetailStatus(UpdateRecruitedDetailStatus up)
        {
            try
            {
                if (up.RecruitedDetailId == 0 || up.RecruitedDetailId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "RecruitedDetailId is required" }); }
                if (string.IsNullOrEmpty(up.JobSeekerStatus)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "JobSeekerStatus is required" }); }
                SuccessModel result = await jobSeekerService.UpdateRecruitedDetailStatus(up.RecruitedDetailId, up.JobSeekerStatus,up.Comments);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "JobSeekerStatus", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
      
       /// <summary>
       /// to get user status in bit field
       /// </summary>
       /// <param name="userId"></param>
       /// <returns></returns>
        [Authorize]
        [HttpGet]
        [ProducesResponseType(typeof(GetSignupStepStatus), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("getSignupStepStatus")]
        public async Task<ActionResult> GetSignupStepStatus(int userId)
        {
            try
            {
                if (userId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "UserId is required" }); }
                GetSignupStepStatus result = await jobSeekerService.GetSignupStepStatus(userId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

    }
}

