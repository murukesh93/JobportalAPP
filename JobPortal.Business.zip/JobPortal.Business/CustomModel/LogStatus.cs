﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class LogStatus
    {
        public string FunctionName { get; set; }
        public string CreatedDate { get; set; }
        public string Data { get; set; }
    }
    public class ErrorLogStatus
    {
        public string FunctionName { get; set; }
        public string CreatedDate { get; set; }
        public string Error { get; set; }
    }

}
