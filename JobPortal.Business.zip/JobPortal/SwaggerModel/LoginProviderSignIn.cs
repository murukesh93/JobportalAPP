﻿namespace JobPortal.SwaggerModel
{
    public class LoginProviderSignIn
    {
        public string Email { get; set; }
        public int RoleId { get; set; }
        public string LoginProviderType { get; set; }
        public string LoginProviderKey { get; set; }
    }
}
 