﻿namespace JobPortal.Business.CustomModel
{
    public class JobSeekerSkillList
    {
        public int SeekerKeySkill { get; set; }
        public int? UserId { get; set; }
        public int? KeySkillId { get; set; }
        public string KeySkillName { get; set; }
        public string Description { get; set; }
        public string name { get; set; } 
        public bool? IsDeleted { get; set; } 
        public decimal? WorkExperience { get; set; }
    }
}
