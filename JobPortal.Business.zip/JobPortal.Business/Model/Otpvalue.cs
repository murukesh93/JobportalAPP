﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class Otpvalue
    {
        public int OtpId { get; set; }
        public string OtpText { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Status { get; set; }
        public string Source { get; set; }
        public string OtpType { get; set; }
    }
}
