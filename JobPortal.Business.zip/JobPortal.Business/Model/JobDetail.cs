﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobDetail
    {
        public JobDetail()
        {
            JobInterviewRounds = new HashSet<JobInterviewRound>();
            JobKeySkills = new HashSet<JobKeySkill>();
            JobLocations = new HashSet<JobLocation>();
            JobPreliminaryQuestions = new HashSet<JobPreliminaryQuestion>();
            PreliminaryRoundDetails = new HashSet<PreliminaryRoundDetail>();
            RecruitedJobSeekerDetails = new HashSet<RecruitedJobSeekerDetail>();
        }

        public int JobDetailId { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public string JobStatus { get; set; }
        public int? NumberOfResources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public int? DesignationId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public bool? IsDeleted { get; set; }
        public int? CompanyId { get; set; }

        public virtual CompanyDetail Company { get; set; }
        public virtual User CreatedByNavigation { get; set; }
        public virtual Currency Currency { get; set; }
        public virtual Designation Designation { get; set; }
        public virtual ICollection<JobInterviewRound> JobInterviewRounds { get; set; }
        public virtual ICollection<JobKeySkill> JobKeySkills { get; set; }
        public virtual ICollection<JobLocation> JobLocations { get; set; }
        public virtual ICollection<JobPreliminaryQuestion> JobPreliminaryQuestions { get; set; }
        public virtual ICollection<PreliminaryRoundDetail> PreliminaryRoundDetails { get; set; }
        public virtual ICollection<RecruitedJobSeekerDetail> RecruitedJobSeekerDetails { get; set; }
    }
}
