﻿namespace JobPortal.SwaggerModel
{
    public class UploadPreSignedUrl
    {
        public string fileUrl { get; set; }
    }
}
