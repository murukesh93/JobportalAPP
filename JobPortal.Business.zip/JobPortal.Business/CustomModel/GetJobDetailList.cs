﻿using JobPortal.Business.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace JobPortal.Business.CustomModel
{
    public class getJobDetailList
    {
       public VwGetJobDetail VwGetJobDetail { get; set; }
        public bool? IsActive { get; set; }

    }
}
