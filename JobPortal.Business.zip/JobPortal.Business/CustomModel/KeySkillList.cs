﻿namespace JobPortal.Business.CustomModel
{
    public class KeySkillList
    {
        public int KeySkillId { get; set; }
        public int? CategoryId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }
    }
}
