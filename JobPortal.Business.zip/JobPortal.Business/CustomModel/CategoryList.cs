﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class VWCompanyList
    {
        public VwCompanyDetail vwCompanyDetail { get; set; }
        public List<CategoryList> CategoryLists { get; set; }
    }
    public class CategoryList
    {
        public int CompanyId { get; set; }
        public string KeySkillName { get; set; }
        public int? CategoryId { get; set; }
    }
}

