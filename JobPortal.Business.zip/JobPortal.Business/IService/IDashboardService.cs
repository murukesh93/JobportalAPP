﻿using JobPortal.Business.CustomModel;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IDashboardService
    {
        public Task<SuperAdminDashboardList>  GetSuperAdminDashboard(); 
        public Task<AdminDashboardList> GetAdminDashboard(int companyId); 
        public Task<CandidateDashboardList> GetCandidateDashboard(int userId);
    }
}
