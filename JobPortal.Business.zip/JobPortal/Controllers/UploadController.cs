﻿using System;
using System.Net;
using System.Threading.Tasks;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using static JobPortal.Business.Common.Common;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadController : ControllerBase
    {
        private readonly IUploadService uploadService;
        private readonly ILog logger;
        public UploadController(IUploadService _uploadService,ILog _log)
        {
            uploadService = _uploadService;
            logger = _log;
        }

        /// <summary>
        /// 
        /// To upload a new file
        /// </summary> 
        [HttpPost]
        [Route("UploadFile")]
        [RequestSizeLimit(1000000000)]
        [RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
        [ProducesResponseType(typeof(FileUploadModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        public async Task<IActionResult> UploadFile(IFormFile file, FileAccess fileAccess)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UploadFile", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(file) };
                logger.Info(log);
                FileUploadModel result = await uploadService.UploadFile(file, fileAccess);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UploadFile", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To upload a new file
        /// </summary> 
        
        [HttpPost]
        [Route("GetUserDelegationSasBlob")] 
        [ProducesResponseType(typeof(FileUploadModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        public async Task<IActionResult> GetUserDelegationSasBlob(UploadPreSignedUrl filePath)
        { 
            try
            {
                LogStatus log = new LogStatus { FunctionName = "GetUserDelegationSasBlob", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = filePath.fileUrl };
                logger.Info(log);
                FileUploadModel result = await uploadService.GetUserDelegationSasBlob(filePath.fileUrl);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetUserDelegationSasBlob", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
