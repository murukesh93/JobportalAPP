﻿using JobPortal.Business.Model;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class ZoomApiList
    {

         [JsonProperty("Page_count")]
        public int Page_count { get; set; }
        [JsonProperty("Page_number")]
        public int  Page_number      {get;set;}
        [JsonProperty("Page_size")]
        public int  Page_size        {get;set;}
        [JsonProperty("Total_records")]
        public int  Total_records    {get;set;}
        [JsonProperty("Next_page_token")]
        public string  Next_page_token  { get; set; }

        [JsonProperty("Users")] 
        public IList<Userdata> Users { get; set; }
    } 
      
    public class Userdata
    {
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("First_name")]
        public string First_name { get; set; }
        [JsonProperty("Last_name")]
        public string Last_name { get; set; }
        [JsonProperty("Email")]
        public string Email { get; set; }
        [JsonProperty("Type")]
        public int Type { get; set; }
        [JsonProperty("Pmi")]
        public long Pmi { get; set; }
        [JsonProperty("Timezone")]
        public string Timezone { get; set; }
        [JsonProperty("Verified")]
        public string Verified { get; set; }
        [JsonProperty("Created_at")]
        public string Created_at { get; set; }
        [JsonProperty("Last_login_time")]
        public string Last_login_time { get; set; }
        [JsonProperty("Language")]
        public string Language { get; set; }
        [JsonProperty("Phone_number")]
        public string Phone_number { get; set; }
        [JsonProperty("Status")]
        public string Status { get; set; }
        [JsonProperty("Role_id")]
        public string Role_id { get; set; } 
    }

    public class ScheduledMeetingList
    {
        [JsonProperty("Page_size")]
        public int Page_size         {get;set;}
        [JsonProperty("Total_records")]
        public int Total_records     {get;set;}
        [JsonProperty("Next_page_token")]
        public string Next_page_token { get; set; }
        [JsonProperty("Meetings")]
        public IList<Meetings> Meetings { get; set; }
    }
     public class Meetings
     { 
            public string Uuid       {get;set;}
            public long Id           {get;set;}
            public string Host_id    {get;set;}
            public string Topic      {get;set;}
            public int Type          {get;set;}
            public string Start_time {get;set;}
            public int Duration      {get;set;}
            public string Timezone   {get;set;}
            public string Created_at {get;set;}
            public string Join_url { get; set; }
        }
    public class Custom_questions
    {
        public string Title { get; set; }
        public string Value { get; set; }
    }
    public class MeetingCreatedList
    {
     public string Uuid          {get;set;}       
     public string Id            {get;set;}
     public string Host_id       {get;set;}
     public string Host_email    {get;set;} 
     public string Topic         {get;set;}
     public string Type          {get;set;}
     public string Status        {get;set; }
     public string Start_time { get;set;}
     public int Duration { get; set; } 
     public string Timezone      {get;set;}
     public string Agenda        {get;set;}
     public string Created_at    {get;set;}
     public string Start_url     {get;set;}
     public string Join_url      {get;set;}
     public string Password      {get;set;}
     public string H323_password {get;set;}
     public string Pstn_password { get; set; }
     public string Encrypted_password { get; set; }
    }
    public class GetParticipantList
    {
        public int code { get; set; }
        public string message { get; set; }
        public string status { get; set; }
        public string create_time { get; set; }
        public  string join_url { get; set; }
    }
    public class AddParticipantsStatus
    {
        public string Code { get; set; }
        public string Message { get; set; } 
    }
    public class GetZoomTimeList
    {
        public List<ZoomTimeZones>   zoomTimeZones { get; set; }

    }

    public class ZoomTimeZones
    {
        public string zoomId { get; set; }
        public string Name { get; set; }
    }

    public class GetCalendorList
    {
        public List<VwGetCalendorView> Data { get; set; }
        public int Count { get; set; }
    }
}
 