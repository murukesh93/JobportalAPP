﻿namespace JobPortal.Business.CustomModel
{
    public class UpdatePassword
    {
        public int UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }
}
