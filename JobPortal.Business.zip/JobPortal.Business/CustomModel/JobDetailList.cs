﻿using JobPortal.Business.Model;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class JobDetailList
    {
        public List<VwGetJobDetail> data { get; set; }
        public int count { get; set; } 
    }
    public class SearchJobsList
    {
        public List<VwGetSearchJob> data { get; set; }
        public int count { get; set; }
    }
}
