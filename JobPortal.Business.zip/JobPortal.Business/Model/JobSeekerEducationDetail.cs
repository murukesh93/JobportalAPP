﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerEducationDetail
    {
        public int EducationDetailId { get; set; }
        public int? UserId { get; set; }
        public string Course { get; set; }
        public string Specialization { get; set; }
        public string Institute { get; set; }
        public int? YearOfPassing { get; set; }
        public decimal? Percentage { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual User User { get; set; }
    }
}
