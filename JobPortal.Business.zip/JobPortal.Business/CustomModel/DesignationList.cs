﻿namespace JobPortal.Business.CustomModel
{
    public class DesignationList
    {
        public int DesignationId { get; set; }
        public string Designation1 { get; set; }
        public bool? IsDeleted { get; set; }

    }
}
