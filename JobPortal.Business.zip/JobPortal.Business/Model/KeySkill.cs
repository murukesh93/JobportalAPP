﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class KeySkill
    {
        public KeySkill()
        {
            JobKeySkills = new HashSet<JobKeySkill>();
            JobSeekerKeySkills = new HashSet<JobSeekerKeySkill>();
        }

        public int KeySkillId { get; set; }
        public int? CategoryId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual KeySkillCategory Category { get; set; }
        public virtual ICollection<JobKeySkill> JobKeySkills { get; set; }
        public virtual ICollection<JobSeekerKeySkill> JobSeekerKeySkills { get; set; }
    }
}
