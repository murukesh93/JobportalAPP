﻿using System.Collections.Generic;

namespace JobPortal.SwaggerModel
{
    public class CreatePreferedLocation
    {
        public int userId { get; set; }
        public List<int> cityId { get; set; }
    }
}
