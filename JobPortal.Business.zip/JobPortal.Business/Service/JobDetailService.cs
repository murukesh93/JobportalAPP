﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class JobDetailService: IJobDetailService
    {
        private JobPortalContext dbContext;
        public JobDetailService(JobPortalContext _db)   
        {
            dbContext = _db;
        }
        public async Task<CreateSuccessModel> UpsertJobDetail(JobDetail job,List<int> CityId,List<int> KeySkillId)
        {
            CreateSuccessModel result=null; 

            await using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    if (job.JobDetailId > 0)
                    {
                        JobDetail existingJob =await dbContext.JobDetails.FirstOrDefaultAsync(j => j.JobDetailId == job.JobDetailId && j.IsDeleted == false);
                        existingJob.JobTitle = job.JobTitle;
                        existingJob.JobDescription = job.JobDescription;
                        existingJob.JobStatus = job.JobStatus;
                        existingJob.NumberOfResources = job.NumberOfResources;
                        existingJob.ExperienceFrom = job.ExperienceFrom;
                        existingJob.ExperienceTo = job.ExperienceTo;
                        existingJob.DesignationId = job.DesignationId;
                        existingJob.CurrencyId = job.CurrencyId;
                        existingJob.SalaryFrom = job.SalaryFrom;
                        existingJob.SalaryTo = job.SalaryTo;
                        dbContext.Update(existingJob);
                        await dbContext.SaveChangesAsync();
                        List<JobLocation> jobLocationLists =await dbContext.JobLocations.Where(a => a.JobDetailId == job.JobDetailId ).ToListAsync();
                        dbContext.RemoveRange(jobLocationLists); 
                        foreach (var city in CityId)
                        {
                          await  dbContext.JobLocations.AddAsync(new JobLocation { CityId = city, JobDetailId = job.JobDetailId });
                        }
                         await dbContext.SaveChangesAsync();
                        List<JobKeySkill> jobKeySkillsLists =await dbContext.JobKeySkills.Where(a => a.JobDetailId == job.JobDetailId ).ToListAsync();
                        dbContext.RemoveRange(jobKeySkillsLists);
                        foreach (var keySkill in KeySkillId)
                        {
                           await dbContext.JobKeySkills.AddAsync(new JobKeySkill { KeySkillId = keySkill, JobDetailId = job.JobDetailId });
                        }                        
                       await dbContext.SaveChangesAsync();                    
                    }
                    else
                    {
                        await dbContext.JobDetails.AddAsync(job);
                        await dbContext.SaveChangesAsync();
                        foreach (var city in CityId)
                        {   
                          await  dbContext.JobLocations.AddAsync(new JobLocation { CityId = city, JobDetailId = job.JobDetailId });
                        }
                        await dbContext.SaveChangesAsync ();
                        foreach (var keySkill in KeySkillId)
                        {
                            dbContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
                          await  dbContext.JobKeySkills.AddAsync(new JobKeySkill { KeySkillId = keySkill, JobDetailId = job.JobDetailId });
                        }
                      await dbContext.SaveChangesAsync();
                    }
                    await transaction.CommitAsync();
                    result = new CreateSuccessModel
                    {
                        Id = job.JobDetailId,
                        message = "Record Saved Successfully",
                        Status = "Success"
                    };
                    return result;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    result = new CreateSuccessModel
                    {
                        Id = 0,
                        message = ex.Message,
                        Status = "Error"
                    };
                    return result;
                }
            }
        }
        public async Task<SuccessModel> DeleteJobDetails(int jobDetailId)
        {
            try
            {
                SuccessModel result;
                JobDetail existingJob =await dbContext.JobDetails.FirstOrDefaultAsync(a => a.JobDetailId == jobDetailId);
                if (existingJob == null)
                {
                    result = new SuccessModel { message = "No record found", status = "Error" };
                }
                else
                {
                    int scheduledCount =await (from a in dbContext.ScheduleInterviews
                                          join i in dbContext.JobInterviewRounds on a.InterviewRoundId equals i.InterviewRoundId
                                          where i.JobDetailId == existingJob.JobDetailId && a.InterviewStatus == "New"
                                          && a.ScheduleDate > DateTime.Now
                                          select new ScheduleInterview
                                          {
                                              ScheduleId = a.ScheduleId
                                          }).CountAsync();

                    if (scheduledCount > 0)
                    {
                        result = new SuccessModel
                        {
                            status = "Error",
                            message = "Your Job Is Scheduled for Future Interviews.Please cancel it"
                        };
                    }
                    else
                    {
                        existingJob.IsDeleted = true;
                        dbContext.Update(existingJob);
                        await dbContext.SaveChangesAsync();
                        result = new SuccessModel { message = "Record deleted successfully", status = "Success" };
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<getJobDetailList> GetJobDetailList(int jobDetailId,int canditateId)
        {
            try
            {
                getJobDetailList getJobDetailList = new getJobDetailList();
                int existingAnswerCount = await dbContext.PreliminaryRoundDetails.CountAsync(a => a.UserId == canditateId && a.JobDetailId==jobDetailId);
                getJobDetailList.IsActive = ((existingAnswerCount > 0 && canditateId > 0) ? true : false);
                VwGetJobDetail existingJobDetail =await dbContext.VwGetJobDetails.FirstOrDefaultAsync(a => a.JobDetailId == jobDetailId);
                getJobDetailList.VwGetJobDetail = existingJobDetail;
                return getJobDetailList;
            }
            catch (Exception ex)
            {
                throw ex;
            } 
        }
        public async Task<JobDetailList> GetJobDetails(int count, int offset,int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@jobStatus", jobStatus));
                parameters.Add(new SqlParameter("@experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("@companyId", companyId));
                parameters.Add(new SqlParameter("@experienceTo", experienceTo));
                parameters.Add(new SqlParameter("@salaryFrom", salaryFrom));
                parameters.Add(new SqlParameter("@salaryTo", salaryTo));
                parameters.Add(new SqlParameter("@jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("@currencyId", curreyncyId));
                parameters.Add(new SqlParameter("@designationId", designationId));
                DataSet ds = Common.Common.GetResultSet("spGetJobDetails", parameters);
                List<VwGetJobDetail> output = Common.Common.ToListof<VwGetJobDetail>(ds.Tables[1]);
                JobDetailList jobDetailList = new JobDetailList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return jobDetailList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public  async Task<SearchJobsList> GetJobsBySearch(int count, int offset,string searchLocations,string searchSkills, int companyId, string jobTitle, string jobStatus, decimal experienceFrom, decimal experienceTo, decimal salaryFrom, decimal salaryTo, int jobDetailId, int designationId, int curreyncyId)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@jobTitle", jobTitle));
                parameters.Add(new SqlParameter("@jobStatus", jobStatus));
                parameters.Add(new SqlParameter("@experienceFrom", experienceFrom));
                parameters.Add(new SqlParameter("@companyId", companyId));
                parameters.Add(new SqlParameter("@experienceTo", experienceTo));
                parameters.Add(new SqlParameter("@searchLocations", searchLocations));
                parameters.Add(new SqlParameter("@searchSkills", searchSkills));
                parameters.Add(new SqlParameter("@salaryFrom", salaryFrom));
                parameters.Add(new SqlParameter("@salaryTo", salaryTo));
                parameters.Add(new SqlParameter("@jobDetailId", jobDetailId));
                parameters.Add(new SqlParameter("@currencyId", curreyncyId));
                parameters.Add(new SqlParameter("@designationId", designationId));
                DataSet ds = Common.Common.GetResultSet("spSearchJobs", parameters);
                List<VwGetSearchJob> output = Common.Common.ToListof<VwGetSearchJob>(ds.Tables[1]);
                SearchJobsList jobDetailList = new SearchJobsList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return jobDetailList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GetCandidateHistoryList> GetCandidateHistory(int userId)
        {
            try
            {
                GetCandidateHistoryList candidateHistoryList = new GetCandidateHistoryList();
                candidateHistoryList.CompanyInfo =await  (from a in dbContext.RecruitedJobSeekerDetails
                                                    join b in dbContext.Users on a.UserId equals b.UserId
                                                    join c in dbContext.JobDetails on a.JobDetailId equals c.JobDetailId
                                                    join d in dbContext.CompanyDetails on c.CompanyId equals d.CompanyId
                                                    join e in dbContext.States on d.StateId equals e.StateId
                                                    join f in dbContext.Cities on d.CityId equals f.CityId
                                                    where a.UserId == userId && e.IsActive == true && f.IsActive ==true
                                                    && a.IsDeleted==true && c.IsDeleted==false
                                                    orderby a.JoinDate descending
                                                    select new CompanyInfo
                                                    {
                                                        jobDetailedId = a.JobDetailId,
                                                        userId = a.UserId,
                                                        appointedBy = a.AppointedBy,
                                                        joinDate = a.JoinDate,
                                                        salaryPerMonth = a.SalaryPerMonth,
                                                        currencyId = a.CurrencyId,
                                                        comments = a.Comments,
                                                        jobSeekerStatus = a.JobSeekerStatus,
                                                        selectedDate = a.SelectedDate,
                                                        jobTitle = c.JobTitle,
                                                        jobDescription = c.JobDescription,
                                                        companyId = c.CompanyId,
                                                        companyName = d.CompanyName,
                                                        stateName=e.StateName,
                                                        cityName=f.CityName,
                                                        firstName = b.FirstName,
                                                        lastName = b.LastName,
                                                        email = b.Email,
                                                        phoneNumber = b.PhoneNumber,
                                                        address = b.Address,
                                                        panNumber = b.PanNumber,
                                                        profileImage = b.ProfileImage,
                                                        userStatus = b.UserStatus,
                                                        dob = b.Dob
                                                    }).ToListAsync();

                candidateHistoryList.JobAppliedHistory =await (from a in dbContext.PreliminaryRoundDetails
                                                          join b in dbContext.JobDetails on a.JobDetailId equals b.JobDetailId
                                                          join c in dbContext.Designations on b.DesignationId equals c.DesignationId
                                                          join d in dbContext.Users on a.UserId equals d.UserId
                                                          where a.UserId == userId && c.IsDeleted==false && d.IsDeleted==false
                                                          select new JobAppliedHistory
                                                          {
                                                              jobDetaildId = a.JobDetailId,
                                                              userId = a.UserId,
                                                              submitDate = a.SubmitDate,
                                                              roundStatus = a.RoundStatus,
                                                              actionBy = a.ActionBy,
                                                              comments = a.Comments,
                                                              jobTitle = b.JobTitle,
                                                              jobDescription = b.JobDescription,
                                                              jobStatus = b.JobStatus,
                                                              numberOfResources = b.NumberOfResources,
                                                              designationId = c.DesignationId,
                                                              designation = c.DesignationName,
                                                              firstName = d.FirstName,
                                                              lastName = d.LastName,
                                                              email = d.Email,
                                                              phoneNumber = d.PhoneNumber,
                                                              userStatus = d.UserStatus
                                                          }).ToListAsync();

                candidateHistoryList.InterviewDetails =await (from a in dbContext.ScheduleInterviews
                                                         join b in dbContext.JobInterviewRounds on a.InterviewRoundId equals b.InterviewRoundId
                                                         join c in dbContext.JobDetails on b.JobDetailId equals c.JobDetailId
                                                         join d in dbContext.Currencies on c.CurrencyId equals d.CurrencyId
                                                         join e in dbContext.Designations on c.DesignationId equals e.DesignationId
                                                         join f in dbContext.Users on a.UserId equals f.UserId
                                                         where a.UserId == userId && b.IsActive == true && e.IsDeleted==false
                                                         select new InterviewDetails
                                                         {
                                                             interviewRoundId = a.InterviewRoundId,
                                                             userId = a.UserId,
                                                             interviewStartDateTime = a.InterviewStartDateTime,
                                                             interviewEndDateTime = a.InterviewEndDateTime,
                                                             scheduledBy = a.ScheduledBy,
                                                             scheduleDate = a.ScheduleDate,
                                                             interviewer = a.Interviewer,
                                                             communicationChannel = a.CommunicationChannel,
                                                             interviewStatus = a.InterviewStatus,
                                                             interviewResult = a.InterviewResult,
                                                             feedback = a.Feedback,
                                                             roundName = b.RoundName,
                                                             roundDescription = b.RoundDescription,
                                                             roundOrder = b.RoundOrder,
                                                             jobTitle = c.JobTitle,
                                                             jobDescription = c.JobDescription,
                                                             jobStatus = c.JobStatus,
                                                             currencyName = d.CurrencyName,
                                                             currencyCode = d.CurrencyCode,
                                                             designation = e.DesignationName,
                                                             firstName = f.FirstName,
                                                             LastName = f.LastName,
                                                             email = f.Email,
                                                             address = f.Address,
                                                             userStatus = f.UserStatus,
                                                             phoneNumber = f.PhoneNumber
                                                         }).ToListAsync();
                return candidateHistoryList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GetCandidateInterviewHistoryList> GetCandidateRoundHistory(int candidateId, int jobDetailId)
        {
            try
            {
               
                    GetCandidateInterviewHistoryList candidateInterviewHistoryList = new GetCandidateInterviewHistoryList();
                    candidateInterviewHistoryList.CandidateInterviewHistory = await (from a in dbContext.JobInterviewRounds
                                                                                     join b in dbContext.ScheduleInterviews.Where(a => a.UserId == candidateId) on a.InterviewRoundId equals b.InterviewRoundId
                                                                                     into gx
                                                                                     from x in gx.DefaultIfEmpty()
                                                                                     join c in dbContext.Users on x.Interviewer equals c.UserId
                                                                                     into ux
                                                                                     from y in ux.DefaultIfEmpty()
                                                                                     where a.JobDetailId == jobDetailId && a.IsActive==true
                                                                                     select new CandidateInterviewHistory
                                                                                     {
                                                                                         jobDetailId = a.JobDetailId,
                                                                                         interviewRoundId = a.InterviewRoundId,
                                                                                         roundName = a.RoundName,
                                                                                         roundDescription = a.RoundDescription,
                                                                                         roundOrder = a.RoundOrder,
                                                                                         isActive = a.IsActive,
                                                                                         scheduleId = x.ScheduleId ,
                                                                                         userId = x.UserId,
                                                                                         interviewStartDateTime = x.InterviewStartDateTime,
                                                                                         interviewEndDateTime = x.InterviewEndDateTime,
                                                                                         scheduledBy = x.ScheduledBy,
                                                                                         scheduledDate = x.ScheduleDate,
                                                                                         interviewer = x.Interviewer,
                                                                                         communicationChannel = x.CommunicationChannel,
                                                                                         interviewStatus = x.InterviewStatus == null ? "Pending" : x.InterviewStatus,
                                                                                         interviewResult = x.InterviewResult,
                                                                                         interviewerName = y.FirstName + y.LastName
                                                                                     }).ToListAsync();
                return candidateInterviewHistoryList;
                

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<SuccessModel> UpdateJobStatus(int JobDetailId,string JobStatus)
        {
            try
            {
                SuccessModel result;
                JobDetail existingJobDetail = dbContext.JobDetails.FirstOrDefault(c => c.JobDetailId == JobDetailId);
                if (existingJobDetail !=null)
                {  
                    existingJobDetail.JobStatus = JobStatus; 
                    dbContext.Update(existingJobDetail);
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel
                    { 
                        message = "Record Saved Successfully",
                        status = "Success"
                    };
                    return result;
                }
                else
                {
                    result = new SuccessModel
                    {
                        message = "No record found",
                        status = "Error"
                    };
                    return result;
                }
              
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
