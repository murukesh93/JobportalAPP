﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class StateService: IStateService
    {
        private JobPortalContext dbContext;
        public StateService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<CreateSuccessModel> SaveState(State saveState)
        {
            try
            {
                CreateSuccessModel result;
                if (saveState.StateId > 0)
                {

                    State existingState = dbContext.States.FirstOrDefault(c => c.StateId == saveState.StateId && c.IsActive == true);
                    existingState.StateName = saveState.StateName;
                    existingState.IsActive = saveState.IsActive;
                    dbContext.Update(existingState);
                }
                else
                {
                    int stateCount =await dbContext.States.Where(c => c.IsActive == true && c.StateName == saveState.StateName).CountAsync();
                    if (stateCount > 0)
                    {
                        result = new CreateSuccessModel { Status = "Error", Id = 0, message = "State name already exists" };
                        return result;
                    }
                    saveState.IsActive = true;
                 await   dbContext.States.AddAsync(saveState);
                }
              await  dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = saveState.StateId,
                    message = "Record Saved Successful",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<StateList> GetStateById(int StateId)
        {
            try
            {
                StateList stateList =await dbContext.States.Select(s => new StateList { StateId = s.StateId, StateName = s.StateName, IsActive = s.IsActive })
    .FirstOrDefaultAsync(s => s.StateId == StateId && s.IsActive == true);
                return stateList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
