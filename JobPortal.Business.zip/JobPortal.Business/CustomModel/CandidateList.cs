﻿using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class CandidateList
    {
        public UserDataList userDataList { get; set; }
        public List<JobSeekerEmploymentList> jobSeekerEmploymentLists { get; set; }
        public List<JobSeekerSkillList> jobSeekerSkillList { get; set; }
        public List<JobSeekerEducationList> jobSeekerEducationLists { get; set; }
        public List<JobSeekerProjectList> jobSeekerProjectLists { get; set; }
        public JobSeekerList jobSeekerDetails { get; set; }
        public List<locationList> jobSeekerPreferredWorkLocations { get; set; }         
    }
}
