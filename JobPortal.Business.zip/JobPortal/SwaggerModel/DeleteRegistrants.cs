﻿namespace JobPortal.SwaggerModel
{
    public class DeleteRegistrants
    {
        public string RegistrantsId { get ; set ; }
        public string MeetingId { get ; set; }
        public string Email { get; set ; }
    }
}
