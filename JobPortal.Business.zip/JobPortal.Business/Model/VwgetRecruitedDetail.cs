﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwgetRecruitedDetail
    {
        public int RecruitedDetailId { get; set; }
        public int? JobDetailId { get; set; }
        public int? UserId { get; set; }
        public int? AppointedBy { get; set; }
        public DateTime? JoinDate { get; set; }
        public decimal? SalaryPerMonth { get; set; }
        public int? CurrencyId { get; set; }
        public string AppoinmentCopy { get; set; }
        public string Comments { get; set; }
        public string TermsandConditions { get; set; }
        public string JobSeekerStatus { get; set; }
        public string SelectedDate { get; set; }
        public string KeySkill { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public int? CreatedBy { get; set; }
        public string JobStatus { get; set; }
        public int? NumberOfResources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public int? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public string CompanyAddress { get; set; }
        public int? CompanyCreateby { get; set; }
        public string CompanyPhoneNumber { get; set; }
        public string CompanyEmail { get; set; }
        public string CompanySiteUrl { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserAddress { get; set; }
        public int RoleId { get; set; }
        public string UserStatus { get; set; }
        public DateTime? Dob { get; set; }
        public string PanNumber { get; set; }
        public string ProfileImage { get; set; }
        public string UserPhoneNumber { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string DesignationName { get; set; }
    }
}
