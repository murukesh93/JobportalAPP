﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]

    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService companyService;
        private readonly ILog logger;
        public CompanyController(ICompanyService _companyService, ILog _logger)
        {
            companyService = _companyService;
            logger = _logger;
        }

        /// <summary>
        /// To Create a New Company
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("CreateCompany")]
        public async Task<ActionResult> CreateCompany(CompanySignUp company)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "CreateCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(company) };
                logger.Info(log);
                if (string.IsNullOrEmpty(company.CompanyName)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "companyName is Required!" }); }
                if (string.IsNullOrEmpty(company.Email)) { return StatusCode((int)HttpStatusCode.Forbidden,new { status="Error",message="email is Required!"});}
                if (company.CreatedBy==0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "createdBy is Required!" }); }
                if (string.IsNullOrEmpty(company.PhoneNumber)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "phoneNumber is Required!" }); }
                if (company.CategoryId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Category ID Required!" }); }
                CompanyDetail companyModel = new CompanyDetail
                { 
                    CompanyId = 0, 
                    CompanyName = company.CompanyName,
                    CompanyLogo=company.CompanyLogo,
                    Address=company.Address,
                    CityId=company.CityId,
                    StateId=company.StateId,
                    PhoneNumber=company.PhoneNumber,
                    Email=company.Email,
                    IsDeleted=false,
                    CompanySiteUrl=company.CompanySiteUrl,
                    CreatedBy=company.CreatedBy,
                };

                CreateSuccessModel result =await companyService.UpsertCompany(companyModel,company.CategoryId);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "CreateCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"),Error=ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To update a existing Company 
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2")]
        [HttpPut]
        [ProducesResponseType(typeof(CreateSuccessModel),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [Route("UpdateCompany")] 
        public async Task<ActionResult> UpdateCompany(UpdateCompanyDetails company)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "UpdateCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(company) };
                logger.Info(log);
                if (company.CompanyId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "companyId is required" }); };
                CompanyDetail companyModel = new CompanyDetail
                {
                    CompanyId = company.CompanyId,
                    CompanyName = company.CompanyName,
                    CompanyLogo = company.CompanyLogo,
                    CompanySiteUrl = company.CompanySiteUrl,
                    PhoneNumber = company.PhoneNumber,
                    Address = company.Address,
                    StateId = company.StateId,
                    CityId = company.CityId
                };
                CreateSuccessModel result =await companyService.UpsertCompany(companyModel, company.CategoryId);
                if (result.Status == "Success")
                {
                    
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }

            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "UpdateCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.InnerException.Message });
            }
         }

        /// <summary>
        /// To delete a company details
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpDelete]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel),500)]
        [ProducesResponseType(typeof(SuccessModel),StatusCodes.Status404NotFound)]
        [Route("DeleteCompany")]
        public async Task<ActionResult> DeleteCompany(int companyId)
        {
            try
            {
                if (companyId == 0|| companyId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "companyId is required" }); }
                SuccessModel result =await companyService.DeleteCompanyDetails(companyId);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "DeleteCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a companyDetails by companyId
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        [Authorize(Roles = "1,2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(VWCompanyList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status404NotFound)]
        [Route("GetCompany")]
        public async Task<ActionResult> GetCompany(int companyId)
        {
            try
            {
                if (companyId == 0 || companyId == null) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "companyId is required" }); }
                VWCompanyList result =await companyService.GetCompanyDetailsById(companyId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    SuccessModel notFoundResult = new SuccessModel { status = "Error", message = "No record found" };
                    return NotFound(notFoundResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCompany", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a company list
        /// </summary>
        /// <returns></returns>
        
        [Authorize(Roles = "1,2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(CompanyList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetCompanyDetails")]
        public async Task<ActionResult> GetCompanyDetails(int offset, int count, int companyId,string companyName,string cityName, string stateName, string email,string phoneNumber)
        {
            try
            {
                if (offset == 0 || offset == null) { offset = 0; }
                if(count==0 || count == null) { count = 10; }
                CompanyList companyList =await companyService.GetCompanyDetails(offset, count, companyId, companyName, cityName, stateName, email, phoneNumber);
                return Ok(companyList);

            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCompanyDetails", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

    }  
}
