﻿namespace JobPortal.Business.CustomModel
{
    public class UpdatePasswordByOtp
    {
        public string Email { get; set; }
        public string OTP { get; set; }
        public string NewPassword { get; set; }
    }
}
