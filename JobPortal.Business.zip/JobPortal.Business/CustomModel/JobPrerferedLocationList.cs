﻿using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class JobPrerferedLocationList
    {
        public  List<int> cityId { get; set;  }
        public List<int> userId { get; set; }
    }
}
