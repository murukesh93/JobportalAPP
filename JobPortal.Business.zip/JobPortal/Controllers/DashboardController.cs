﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly IDashboardService dashboardService;
        private readonly ILog logger;
        public DashboardController(IDashboardService _dashboardService , ILog _log)
        {
            dashboardService = _dashboardService;
            logger = _log;
        }

        /// <summary>
        /// To get a SuperAdmin Dashboard 
        /// </summary>
        /// <returns></returns>
        
        [Authorize(Roles="1")]
        [HttpGet]
        [ProducesResponseType(typeof(SuperAdminDashboardList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetSuperAdminDashboard")]
        public async Task<ActionResult> GetSuperAdminDashboard()
        {
            try
            {
                SuperAdminDashboardList result =await dashboardService.GetSuperAdminDashboard();
                if (result != null)
                {
                    return Ok(result);
                }
                else
                { 
                    SuccessModel successModel = new SuccessModel { status = "Error", message = "No record found" };
                    return StatusCode((int)HttpStatusCode.Forbidden, successModel);
                }
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetSuperAdminDashboard", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To get a Admin Dashboard report
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "2,3")]
        [HttpGet]
        [ProducesResponseType(typeof(AdminDashboardList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetAdminDashboard")]
        public async Task<ActionResult> GetAdminDashboard(int companyId)
        {
            try
            {
                AdminDashboardList result = await dashboardService.GetAdminDashboard(companyId);
                return Ok(result);
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetAdminDashboard", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Get a Candidate Dashboard
        /// </summary>
        /// <returns></returns>

        [Authorize(Roles = "4")]
        [HttpGet]
        [ProducesResponseType(typeof(CandidateDashboardList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetCandidateDashboard")]
        public async Task<ActionResult> GetCandidateDashboard(int userId)
        {
            try
            {
                CandidateDashboardList result =await dashboardService.GetCandidateDashboard(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetCandidateDashboard", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
