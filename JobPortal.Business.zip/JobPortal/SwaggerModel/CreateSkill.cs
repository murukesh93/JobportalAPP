﻿namespace JobPortal.SwaggerModel
{
    public class CreateSkill
    {
        public int? CategoryId { get; set; }
        public string Name { get; set; }
    }
}
