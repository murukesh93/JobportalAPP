﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class PreliminaryQuestionAnswer
    {
        public int AnswerId { get; set; }
        public int? UserId { get; set; }
        public int? QuestionId { get; set; }
        public string UserAnswer { get; set; }

        public virtual JobPreliminaryQuestion Question { get; set; }
        public virtual User User { get; set; }
    }
}
