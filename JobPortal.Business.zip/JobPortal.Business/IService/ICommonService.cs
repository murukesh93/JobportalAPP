﻿using JobPortal.Business.CustomModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
   public interface ICommonService
    {
       public Task<List<RoleList>> GetRole();
       public Task<SuccessModel> UpdateRole(RoleList roleList);
       public Task<List<StateList>> GetState();
       public Task<List<CityList>> GetCity(int? stateId);
       public Task<List<CurrencyList>> GetCurrency();
       public Task<List<DesignationList>> GetDesignation();
    }
}
