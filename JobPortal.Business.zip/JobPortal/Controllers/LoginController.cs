﻿using System;
using System.Net;
using System.Threading.Tasks;
using JobPortal.Business.Common;
using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace JobPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginService loginService;
        public LoginController(ILoginService _loginService)
        {
            loginService = _loginService;
        }
        /// <summary>
        /// 
        /// To sign in a user
        /// </summary> 
        [HttpPost]
        [ProducesResponseType(typeof(LoginSuccess), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("Login")]
        public async Task<ActionResult> Login(Login user)
        {
            try
            {
                // Validation  
                if (string.IsNullOrEmpty(user.Email)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "email is required" }); }
                if (string.IsNullOrEmpty(user.Password)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "password is required" }); }
                LoginSuccess result =await loginService.Login(user);
                if (result.status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    ExceptionModel resultException = new ExceptionModel { message = result.message, status = result.status };
                    return StatusCode((int)HttpStatusCode.Forbidden, resultException);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
        /// <summary>
        /// To
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(LoginProviderSuccess), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ExceptionModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("LoginProvider")]
        public async Task<ActionResult> LoginProvider(LoginProviderSignIn login)
        {
            try
            {
                if (string.IsNullOrEmpty(login.LoginProviderKey)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Login providerkey is required" }); }
                if (string.IsNullOrEmpty(login.LoginProviderType)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "Login Providertype is required" }); }
                LoginProvider loginProvider = new LoginProvider
                {
                    LoginProviderKey=login.LoginProviderKey,
                    LoginProviderType=login.LoginProviderType,
                    UserId=0, 
                };
                LoginProviderSuccess result =await loginService.LoginProvider(loginProvider,login.Email,login.RoleId);
                return Ok(result);
            }
            catch(Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }
    }
}
