﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class VwpreliminaryRound
    {
        public int? UserId { get; set; }
        public int RoundDetailId { get; set; }
        public int JobDetailId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Dob { get; set; }
        public string PhoneNumber { get; set; }
        public string CountryCode { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public string CityName { get; set; }
        public int? StateId { get; set; }
        public string StateName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public int RoleId { get; set; }
        public string UserStatus { get; set; }
        public string PanNumber { get; set; }
        public string ProfileImage { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public string JobStatus { get; set; }
        public int? NumberOfResources { get; set; }
        public decimal? ExperienceFrom { get; set; }
        public decimal? ExperienceTo { get; set; }
        public int? DesignationId { get; set; }
        public int? CurrencyId { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public string CompanyName { get; set; }
        public int CompanyId { get; set; }
        public DateTime SubmitDate { get; set; }
        public string RoundStatus { get; set; }
        public int? ActionBy { get; set; }
        public string Comments { get; set; }
    }
}
