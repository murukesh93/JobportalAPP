﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface ICityService
    {
       public Task<CreateSuccessModel> SaveCity(City city);
        public Task<CityList> GetCityById(int cityId);
    }
}
