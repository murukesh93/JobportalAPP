﻿namespace JobPortal.Business.CustomModel
{
    public class CurrencyList
    {
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public string CurrencyCode { get; set; }
    }
}
