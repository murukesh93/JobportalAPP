﻿namespace JobPortal.Business.CustomModel
{
    public class JobSeekerProjectList
    {
        public int ProjectDetailId { get; set; }
        public int? UserId { get; set; }
        public string ProjectName { get; set; }
        public bool? IsDeleted { get; set; }
        public string ProjectDescription { get; set; }
        public decimal? Duration { get; set; }
        public string YourRole { get; set; }
    }
}
