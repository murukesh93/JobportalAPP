﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class City
    {
        public City()
        {
            JobLocations = new HashSet<JobLocation>();
            JobSeekerPreferredWorkLocations = new HashSet<JobSeekerPreferredWorkLocation>();
            RecruitedJobSeekerDetails = new HashSet<RecruitedJobSeekerDetail>();
            Users = new HashSet<User>();
        }

        public int CityId { get; set; }
        public string CityName { get; set; }
        public int? StateId { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<JobLocation> JobLocations { get; set; }
        public virtual ICollection<JobSeekerPreferredWorkLocation> JobSeekerPreferredWorkLocations { get; set; }
        public virtual ICollection<RecruitedJobSeekerDetail> RecruitedJobSeekerDetails { get; set; }
        public virtual ICollection<User> Users { get; set; }
    }
}
