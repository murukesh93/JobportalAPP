﻿namespace JobPortal.Business.CustomModel
{
    public class JobLocationList
    {
        public int JobDetailId { get; set; }
        public int CityId { get; set; }
        public int JobLocationsId { get; set; }
    }
}
