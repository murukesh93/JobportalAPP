﻿using JobPortal.Business.Model;
using JobPortal.Business.CustomModel;
using System.Linq;
using JobPortal.Business.IService;
using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Business.Service
{
   public class LoginService: ILoginService
    {
        private JobPortalContext dbContext;
        public LoginService(JobPortalContext _db)
        {
            dbContext = _db;
        }
        public async Task<LoginSuccess> Login(Login model)
        {
            try
            {
                LoginSuccess result;
                User existingUser = await dbContext.Users.FirstOrDefaultAsync(a => a.Email == model.Email && a.IsDeleted == false);
                if (existingUser == null)
                {
                    result = new LoginSuccess { status = "Error", message = "Invalid UserName" };
                }
                else if (existingUser.Password != Common.Common.EncryptData(model.Password))
                {
                    result = new LoginSuccess { status = "Error", message = "Your account or password is incorrect" };
                }
                else
                {
                    VwUser user = await dbContext.VwUsers.FirstOrDefaultAsync(a => a.UserId == existingUser.UserId);
                    string token = Common.Common.GenerateJSONWebToken(new ClaimModel { UserId = user.UserId.ToString(), RoleId = user.RoleId.ToString() });
                    result = new LoginSuccess { status = "Success", message = "Login Successfully", User = user, Token = token }; 
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<LoginProviderSuccess> LoginProvider(LoginProvider login,string Email,int RoleId)
        {
            LoginProviderSuccess result;
            using (var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    LoginProvider existingUser = await dbContext.LoginProviders
                        .FirstOrDefaultAsync(l => l.LoginProviderKey == login.LoginProviderKey && l.LoginProviderType == login.LoginProviderType);

                    if (existingUser != null)
                    {
                        VwUser user= await dbContext.VwUsers.FirstOrDefaultAsync(a => a.UserId == existingUser.UserId );
                        string token = Common.Common.GenerateJSONWebToken(new ClaimModel { UserId = user.UserId.ToString(), RoleId = user.RoleId.ToString() });
                        result = new LoginProviderSuccess { status = "Success", message = "Login Succesfully", IsNewEntry = false, User = user, Token = token };
                        return result;
                    }
                    else
                    {
                        User newUser = new User
                        {
                            FirstName = null,
                            LastName = null,
                            Email = Email,
                            Address = null,
                            CityId = null,
                            Password = null,
                            PanNumber = null,
                            StateId = null,
                            CreatedBy = null,
                            RoleId =RoleId,
                            UserStatus= "Not Verified", 
                            ProfileImage=null,
                            CountryCode=null,
                            IsDeleted=false,
                            Dob=null,
                            PhoneNumber=null
                        };
                        await dbContext.Users.AddAsync(newUser);
                        await dbContext.SaveChangesAsync();
                        login.UserId = newUser.UserId;
                        await dbContext.LoginProviders.AddAsync(login);
                        transaction.Commit();
                        await dbContext.SaveChangesAsync();
                        VwUser user = await dbContext.VwUsers.FirstOrDefaultAsync(a => a.UserId == newUser.UserId);
                        string token = Common.Common.GenerateJSONWebToken(new ClaimModel { UserId = user.UserId.ToString(), RoleId = user.RoleId.ToString() });
                        result = new LoginProviderSuccess { status = "Success", message = "Login Succesfully", IsNewEntry = true, User = user, Token = token };
                        return result;
                    }
                }
                catch(Exception ex)
                {
                    transaction.Rollback(); 
                    result = new LoginProviderSuccess
                    {
                        message = ex.Message,
                        status = "Error"
                    };
                    return result;
                }
            }
        }
    }
}
