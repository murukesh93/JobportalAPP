﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using JobPortal.SwaggerModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace JobPortal.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class DesignationController: ControllerBase
    {
        private readonly IDesignationService designationService;
        private readonly ILog logger;
        public DesignationController (IDesignationService _designationService , ILog _log)
        {
            designationService = _designationService;
            logger = _log;
        }

        /// <summary>
        /// To Save a Designation
        /// </summary>
        /// <param name="designation"></param>
        /// <returns></returns>
        [Authorize(Roles = "1")]
        [HttpPost]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateSuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("SaveDesignation")]
        public async Task<ActionResult> SaveDesignation(SaveDesignation designation)
        {
            try
            {
                LogStatus log = new LogStatus { FunctionName = "SaveDesignation", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Data = JsonConvert.SerializeObject(designation) };
                logger.Info(log);
                if (string.IsNullOrEmpty(designation.designation)) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "error", message = "desgination is Reguired!" }); }
                Designation designationModel = new Designation
                {
                    DesignationId = designation.designationid,
                    DesignationName=designation.designation,
                    IsDeleted=designation.isDeleted
                };
                CreateSuccessModel result =await designationService.SaveDesignation(designationModel);
                if (result.Status == "Success")
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden, result);
                }
            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "SaveDesignation", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }
        }

        /// <summary>
        /// To Get a Destinagtion By Id
        /// </summary>
        /// <param name="DesignationId"></param>
        /// <returns></returns>
        
        [HttpGet]
        [ProducesResponseType(typeof(DesignationList), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(SuccessModel), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ExceptionModel), 500)]
        [Route("GetDesignationById")]
        public async Task<ActionResult> GetDesignationById(int DesignationId)
        {
            try
            {
                if (DesignationId == 0) { return StatusCode((int)HttpStatusCode.Forbidden, new { status = "Error", message = "DesignationId is Required!" }); }
                DesignationList result =await designationService.GetDesignationById(DesignationId);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode((int)HttpStatusCode.Forbidden,new { status="Error", message="No Record Found"});
                }

            }
            catch(Exception ex)
            {
                ErrorLogStatus log = new ErrorLogStatus { FunctionName = "GetDesignationById", CreatedDate = DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), Error = ex.Message };
                logger.Error(log);
                return StatusCode((int)HttpStatusCode.InternalServerError, new { status = "Error", message = ex.Message });
            }

        }

    }
}
