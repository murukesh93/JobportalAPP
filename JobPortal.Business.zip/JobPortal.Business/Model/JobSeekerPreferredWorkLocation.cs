﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class JobSeekerPreferredWorkLocation
    {
        public int? UserId { get; set; }
        public int? CityId { get; set; }
        public int WorkLocationId { get; set; }

        public virtual City City { get; set; }
        public virtual User User { get; set; }
    }
}
