﻿using System;
using System.Collections.Generic;

namespace JobPortal.Business.CustomModel
{
    public class GetCandidateHistoryList
    {
        public List<CompanyInfo> CompanyInfo { get; set; }
        public List<JobAppliedHistory> JobAppliedHistory { get; set; }
        public List<InterviewDetails> InterviewDetails { get; set; }
    }
    public class CompanyInfo 
    {
        public int? jobDetailedId { get; set; }
        public int? userId { get; set; }
        public int? appointedBy { get; set; }
        public DateTime? joinDate { get; set; }
        public decimal? salaryPerMonth { get; set; }
        public int? currencyId { get; set; }
        public string comments { get; set; }
        public string jobSeekerStatus { get; set; }
        public DateTime? selectedDate { get; set; }
        public string jobTitle { get; set; }
        public string jobDescription { get; set; }
        public int? companyId { get; set; }
        public string companyName { get; set; }
        public string stateName { get; set; }
        public string cityName { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
        public string address { get; set; }
        public string panNumber { get; set; }
        public string profileImage { get; set; }
        public string userStatus { get; set; }
        public DateTime? dob { get; set; }
    }
    public class JobAppliedHistory
    {
        public int? jobDetaildId { get; set; }
        public int? userId { get; set; }
        public DateTime? submitDate { get; set; }
        public string roundStatus { get; set; }
        public int? actionBy { get; set; }
        public string comments { get; set; }
        public string jobTitle { get; set; }
        public string jobDescription { get; set; }
        public string jobStatus { get; set; }
        public int? numberOfResources { get; set; }
        public int? designationId { get; set; }
        public string designation { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
        public string userStatus { get; set; }

    }
    public class InterviewDetails
    {
        public int? interviewRoundId { get; set; }
        public int? userId { get; set; }
        public DateTime? interviewStartDateTime { get; set; }
        public DateTime? interviewEndDateTime { get; set; }
        public int? scheduledBy { get; set; }
        public DateTime? scheduleDate { get; set; }
        public int? interviewer { get; set; }
        public string communicationChannel { get; set; }
        public string communicationUrl { get; set; }
        public string interviewStatus { get; set; }
        public string interviewResult { get; set; }
        public string feedback { get; set; }
        public string roundName { get; set; }
        public string roundDescription { get; set; }
        public int? roundOrder { get; set; }
        public string jobTitle { get; set; }
        public string jobDescription { get; set; }
        public string jobStatus { get; set; }
        public string currencyName { get; set; }
        public string currencyCode { get; set; }
        public string designation { get; set; }
        public string firstName { get; set; }
        public string LastName { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public string userStatus { get; set; }
        public string phoneNumber { get; set; }
    }
}
