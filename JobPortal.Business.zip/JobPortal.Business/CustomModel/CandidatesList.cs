﻿namespace JobPortal.Business.CustomModel
{
    public class CandidatesList
    {
       public string firstName { get; set; }
        public string lastName { get; set; }
        public string profileImage { get; set; }
    }
}
