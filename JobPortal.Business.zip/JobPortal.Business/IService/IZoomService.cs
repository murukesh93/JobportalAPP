﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.Model;
using System.Threading.Tasks;

namespace JobPortal.Business.IService
{
    public interface IZoomService
    {
        public Task<ZoomApiList> GetUserHostingDetails();
        public Task<ScheduledMeetingList> ListScheduledMeetings(string hostId);
        public Task<MeetingCreatedList> GetMeetingById(string meetingId);
        public Task<SuccessModel> DeleteParticipant(DeleteRegirstrantsList regirstrantsList);
        public Task<SuccessModel> UpdateMeeting(UpdateMeetingList updateMeeting);
        public Task<MeetingCreatedList> CreateNewMeeting(CreateMeetingList createMeeting);
        public Task<SuccessModel> DeleteMeeting(string meetingId); 
        public Task<SuccessModel> UpdateMeetingStatus(string meetingId, string action);
        public Task<SuccessModel> AddNewParticipants(ZoomMeetingParticipant zoomMeeting);
        public Task<GetParticipantList> GetParticipant(long meetingId, string registrantId);
        public Task<GetZoomTimeList> GetZoomList();
        public Task<GetCalendorList> GetCalendorView(int count, int offset, int interviewerId, string email, string fromDate, string toDate, string meetingStatus, int userId);
    }
}
