﻿namespace JobPortal.SwaggerModel
{
    public class CreateKeySkillCategory
    {
        public string CategoryName { get; set; }
    }
}
