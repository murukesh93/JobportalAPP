﻿using System;
using System.Collections.Generic;

#nullable disable

namespace JobPortal.Business.Model
{
    public partial class User
    {
        public User()
        {
            CompanyDetails = new HashSet<CompanyDetail>();
            CompanyUsers = new HashSet<CompanyUser>();
            JobDetails = new HashSet<JobDetail>();
            JobSeekerDetails = new HashSet<JobSeekerDetail>();
            JobSeekerEducationDetails = new HashSet<JobSeekerEducationDetail>();
            JobSeekerEmployementDetails = new HashSet<JobSeekerEmployementDetail>();
            JobSeekerKeySkills = new HashSet<JobSeekerKeySkill>();
            JobSeekerPreferredWorkLocations = new HashSet<JobSeekerPreferredWorkLocation>();
            JobSeekerProjectDetails = new HashSet<JobSeekerProjectDetail>();
            LoginProviders = new HashSet<LoginProvider>();
            PreliminaryQuestionAnswers = new HashSet<PreliminaryQuestionAnswer>();
            PreliminaryRoundDetailActionByNavigations = new HashSet<PreliminaryRoundDetail>();
            PreliminaryRoundDetailUsers = new HashSet<PreliminaryRoundDetail>();
            RecruitedJobSeekerDetailAppointedByNavigations = new HashSet<RecruitedJobSeekerDetail>();
            RecruitedJobSeekerDetailUsers = new HashSet<RecruitedJobSeekerDetail>();
            ScheduleInterviewInterviewerNavigations = new HashSet<ScheduleInterview>();
            ScheduleInterviewScheduledByNavigations = new HashSet<ScheduleInterview>();
            ScheduleInterviewUsers = new HashSet<ScheduleInterview>();
        }

        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Address { get; set; }
        public int? CityId { get; set; }
        public int? StateId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public int RoleId { get; set; }
        public string UserStatus { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? Dob { get; set; }
        public string PanNumber { get; set; }
        public string ProfileImage { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Gender { get; set; }
        public string StatusComment { get; set; }

        public virtual City City { get; set; }
        public virtual Role Role { get; set; }
        public virtual State State { get; set; }
        public virtual ICollection<CompanyDetail> CompanyDetails { get; set; }
        public virtual ICollection<CompanyUser> CompanyUsers { get; set; }
        public virtual ICollection<JobDetail> JobDetails { get; set; }
        public virtual ICollection<JobSeekerDetail> JobSeekerDetails { get; set; }
        public virtual ICollection<JobSeekerEducationDetail> JobSeekerEducationDetails { get; set; }
        public virtual ICollection<JobSeekerEmployementDetail> JobSeekerEmployementDetails { get; set; }
        public virtual ICollection<JobSeekerKeySkill> JobSeekerKeySkills { get; set; }
        public virtual ICollection<JobSeekerPreferredWorkLocation> JobSeekerPreferredWorkLocations { get; set; }
        public virtual ICollection<JobSeekerProjectDetail> JobSeekerProjectDetails { get; set; }
        public virtual ICollection<LoginProvider> LoginProviders { get; set; }
        public virtual ICollection<PreliminaryQuestionAnswer> PreliminaryQuestionAnswers { get; set; }
        public virtual ICollection<PreliminaryRoundDetail> PreliminaryRoundDetailActionByNavigations { get; set; }
        public virtual ICollection<PreliminaryRoundDetail> PreliminaryRoundDetailUsers { get; set; }
        public virtual ICollection<RecruitedJobSeekerDetail> RecruitedJobSeekerDetailAppointedByNavigations { get; set; }
        public virtual ICollection<RecruitedJobSeekerDetail> RecruitedJobSeekerDetailUsers { get; set; }
        public virtual ICollection<ScheduleInterview> ScheduleInterviewInterviewerNavigations { get; set; }
        public virtual ICollection<ScheduleInterview> ScheduleInterviewScheduledByNavigations { get; set; }
        public virtual ICollection<ScheduleInterview> ScheduleInterviewUsers { get; set; }
    }
}
