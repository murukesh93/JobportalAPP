﻿using JobPortal.Business.CustomModel;
using JobPortal.Business.IService;
using JobPortal.Business.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JobPortal.Business.Service
{
    public class CompanyService : ICompanyService
    {
        private JobPortalContext dbContext;
        public CompanyService(JobPortalContext _db)
        {
            dbContext = _db;
        }

        public async Task<CreateSuccessModel> UpsertCompany(CompanyDetail company, List<int> CategoryId)
        {
            try
            {
                CreateSuccessModel result;
                if (company.CompanyId > 0)
                {
                    CompanyDetail existingCompany =await dbContext.CompanyDetails.FirstOrDefaultAsync(c => c.CompanyId == company.CompanyId);
                    existingCompany.CompanyName = company.CompanyName;
                    existingCompany.CompanyLogo = company.CompanyLogo;
                    existingCompany.CompanySiteUrl = company.CompanySiteUrl;
                    existingCompany.CityId = company.CityId;
                    existingCompany.Address = company.Address;
                    existingCompany.StateId = company.StateId;
                    existingCompany.PhoneNumber = company.PhoneNumber;
                    dbContext.Update(existingCompany);
                    await dbContext.SaveChangesAsync();
                    List<int?> data = await (dbContext.CompanyCategories.Where(a => a.CompanyId == company.CompanyId).Select(a => a.CategoryId).ToListAsync());
                    foreach (var id in CategoryId)
                    {
                        if (data.Contains(id))
                        {
                            CompanyCategory existingCompanyCategory =await dbContext.CompanyCategories.FirstOrDefaultAsync(c => c.CategoryId == id && c.CompanyId == company.CompanyId);
                            existingCompanyCategory.CategoryId = id;
                        }
                        else
                        {
                           await dbContext.CompanyCategories.AddAsync(new CompanyCategory { CategoryId = id, CompanyId = company.CompanyId });
                        }
                    }
                    await dbContext.SaveChangesAsync();
                    List<int?> deletedata =await (dbContext.CompanyCategories.Where(a => a.CompanyId == company.CompanyId).Select(a => a.CategoryId).ToListAsync());
                    foreach (var id in deletedata)
                    {
                        if (!CategoryId.Contains((int)id))
                        {
                            CompanyCategory existingCompanyCategory =await dbContext.CompanyCategories.FirstOrDefaultAsync(c => c.CategoryId == id && c.CompanyId == company.CompanyId);
                            dbContext.CompanyCategories.Remove(existingCompanyCategory);
                        }

                        await dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    int companySiteUrlCount =await dbContext.CompanyDetails.CountAsync(c => c.CompanySiteUrl == company.CompanySiteUrl && c.IsDeleted == false);
                    if (companySiteUrlCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "CompanySiteUrl already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    int emailCount =await dbContext.CompanyDetails.CountAsync(c => c.Email == company.Email && c.IsDeleted == false);
                    if (emailCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "CompanyEmail already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    int phoneNumberCount =await dbContext.CompanyDetails.CountAsync(c => c.PhoneNumber == company.PhoneNumber && c.IsDeleted == false);
                    if (phoneNumberCount > 0)
                    {
                        result = new CreateSuccessModel
                        {
                            Id = 0,
                            message = "PhoneNumber already exist",
                            Status = "Error"
                        };
                        return result;
                    }
                    company.IsDeleted = false;
                   await dbContext.CompanyDetails.AddAsync(company);
                   await dbContext.SaveChangesAsync();
                    CategoryId = CategoryId.Distinct().ToList();
                    foreach (var id in CategoryId)
                    {
                        await dbContext.CompanyCategories.AddAsync(new CompanyCategory { CategoryId = id, CompanyId = company.CompanyId });
                    }
                }
                await dbContext.SaveChangesAsync();
                result = new CreateSuccessModel
                {
                    Id = company.CompanyId,
                    message = "Record saved successfully",
                    Status = "Success"
                };
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<SuccessModel> DeleteCompanyDetails(int companyId)
        {
            try
            {
                SuccessModel result;
                CompanyDetail exisitingCompany =await dbContext.CompanyDetails.FirstOrDefaultAsync(c => c.CompanyId == companyId);
                if (exisitingCompany == null)
                {
                    return new SuccessModel { status = "Error", message = "No record found" };
                }
                else
                {
                    exisitingCompany.IsDeleted = true;
                    dbContext.Update(exisitingCompany);
                    await dbContext.SaveChangesAsync();
                    result = new SuccessModel { message = "Record deleted successfully", status = "Success" };
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<VWCompanyList> GetCompanyDetailsById(int companyId)
        {
            try
            {
                VWCompanyList companyList = new VWCompanyList();
                companyList.vwCompanyDetail =await dbContext.VwCompanyDetails.FirstOrDefaultAsync(c => c.CompanyId == companyId);
                companyList.CategoryLists = await (from a in dbContext.CompanyCategories
                                             join b in dbContext.KeySkillCategories on a.CategoryId equals b.CategoryId
                                             join c in dbContext.CompanyDetails on a.CompanyId equals c.CompanyId
                                             where a.CompanyId == companyId && c.IsDeleted == false
                                             select new CategoryList
                                             {
                                                 CompanyId = companyId,
                                                 KeySkillName = b.CategoryName,
                                                 CategoryId = b.CategoryId

                                             }).ToListAsync();
                return companyList;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<CompanyList> GetCompanyDetails(int offset, int count, int companyId, string companyName, string cityName, string stateName, string email, string phoneNumber)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@count", count));
                parameters.Add(new SqlParameter("@offset", offset));
                parameters.Add(new SqlParameter("@companyName", companyName));
                parameters.Add(new SqlParameter("@stateName", stateName));
                parameters.Add(new SqlParameter("@email", email));
                parameters.Add(new SqlParameter("@phoneNumber", phoneNumber));
                parameters.Add(new SqlParameter("@cityName", cityName));
                parameters.Add(new SqlParameter("@companyId", companyId));
                DataSet ds = Common.Common.GetResultSet("spGetCompanyDetails", parameters);
                List<VwCompanyDetail> output = Common.Common.ToListof<VwCompanyDetail>(ds.Tables[1]);
                CompanyList companyList = new CompanyList { data = output, count = (int?)ds.Tables[0].Rows[0][0] ?? 0 };
                return companyList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
